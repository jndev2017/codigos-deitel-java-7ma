// Fig. 19.15: Algoritmos2.java
// Uso de los algoritmos addAll, frequency y disjoint.
import java.util.List;
import java.util.Vector;
import java.util.Arrays;
import java.util.Collections;

public class Algoritmos2 
{
   private String[] colores = { "rojo", "blanco", "amarillo", "azul" };
   private List< String > lista;
   private Vector< String > vector = new Vector< String >();
   
   // crea objetos List y Vector 
   // y los manipula con m�todos de Collections
   public Algoritmos2()
   {
      // inicializa lista y vector
      lista = Arrays.asList( colores );
      vector.add( "negro" );
      vector.add( "rojo" );
      vector.add( "verde" );

      System.out.println( "Antes de addAll, el vector contiene:" );

      // muesta los elementos en el vector
      for ( String s : vector )
         System.out.printf( "%s ", s );

      // agrega los elementos en colores a lista
      Collections.addAll( vector, colores );

      System.out.println( "\n\nDespues de addAll, el vector contiene: " );

      // muestra los elementos en el vector
      for ( String s : vector )
         System.out.printf( "%s ", s );

      // obtiene la frecuencia de "rojo"
      int frecuencia = Collections.frequency( vector, "rojo" );
      System.out.printf( 
         "\n\nFrecuencia de rojo en el vector: %d\n", frecuencia );

      // comprueba si lista y vector tienen elementos en com�n
      boolean desunion = Collections.disjoint( lista, vector );

      System.out.printf( "\nlista y vector %s elementos en comun\n", 
         ( desunion ? "no tienen" : "tienen"  ) );
   } // fin del constructor de Algoritmos2

   public static void main( String args[] ) 
   {
      new Algoritmos2();
   } // fin de main
} // fin de la clase Algoritmos2

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/