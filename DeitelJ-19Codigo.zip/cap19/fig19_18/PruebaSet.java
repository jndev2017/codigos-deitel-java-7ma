// Fig. 19.18: PruebaSet.java
// Uso de un objeto HashSet para eliminar duplicados.
import java.util.List;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.Collection;

public class PruebaSet 
{
   private static final String colores[] = { "rojo", "blanco", "azul",
      "verde", "gris", "naranja", "carne", "blanco", "cyan",
      "durazno", "gris", "naranja" };
                  
   // crea e imprime un objeto ArrayList
   public PruebaSet()
   {
      List< String > lista = Arrays.asList( colores );
      System.out.printf( "ArrayList: %s\n", lista );
      imprimirSinDuplicados( lista );
   } // fin del constructor de PruebaSet

   // crea conjunto a partir del arreglo para eliminar duplicados
   private void imprimirSinDuplicados( Collection< String > coleccion )
   {
      // crea un objeto HashSet 
      Set< String > conjunto = new HashSet< String >( coleccion );   

      System.out.println( "\nLos valores sin duplicados son: " );

      for ( String s : conjunto )
         System.out.printf( "%s ", s );

      System.out.println();
   } // fin del m�todo imprimirSinDuplicados

   public static void main( String args[] )
   {
      new PruebaSet();
   } // fin de main 
} // fin de la clase PruebaSet


/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/