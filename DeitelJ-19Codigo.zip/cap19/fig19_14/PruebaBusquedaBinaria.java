// Fig. 19.14: PruebaBusquedaBinaria.java
// Uso del algoritmo binarySearch.
import java.util.List;
import java.util.Arrays;
import java.util.Collections;
import java.util.ArrayList;

public class PruebaBusquedaBinaria 
{
   private static final String colores[] = { "rojo", "blanco",  
      "azul", "negro", "amarillo", "morado", "carne", "rosa" };
   private List< String > lista; // referencia ArrayList

   // crea, ordena e imprime la lista
   public PruebaBusquedaBinaria()
   {
      lista = new ArrayList< String >( Arrays.asList( colores ) );  
      Collections.sort( lista ); // ordena el objeto ArrayList
      System.out.printf( "ArrayList ordenado: %s\n", lista );
   } // fin del constructor de PruebaBusquedaBinaria

   // busca varios valores en la lista
   private void buscar()
   {
      imprimirResultadosBusqueda( colores[ 3 ] ); // primer elemento
      imprimirResultadosBusqueda( colores[ 0 ] ); // elemento medio
      imprimirResultadosBusqueda( colores[ 7 ] ); // �ltimo elemento
      imprimirResultadosBusqueda( "aqua" ); // debajo del menor
      imprimirResultadosBusqueda( "gris" ); // no existe
      imprimirResultadosBusqueda( "verdeazulado" ); // no existe
   } // fin del m�todo buscar

   // m�todo ayudante para realizar b�squedas
   private void imprimirResultadosBusqueda( String clave )
   {
      int resultado = 0;

      System.out.printf( "\nBuscando: %s\n", clave );
      resultado = Collections.binarySearch( lista, clave );
      
      if ( resultado >= 0 )
         System.out.printf( "Se encontro en el indice %d\n", resultado );
      else
         System.out.printf( "No se encontro (%d)\n",resultado );
   } // fin del m�todo imprimirResultadosBusqueda

   public static void main( String args[] )
   {
      PruebaBusquedaBinaria pruebaBusquedaBinaria = new PruebaBusquedaBinaria();
      pruebaBusquedaBinaria.buscar();
   } // fin de main     
} // fin de la clase PruebaBusquedaBinaria

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/