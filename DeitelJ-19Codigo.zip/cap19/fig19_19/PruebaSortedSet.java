// Fig. 19.19: PruebaSortedSet.java
// Uso de TreeSet y SortedSet.
import java.util.Arrays;
import java.util.SortedSet;
import java.util.TreeSet;

public class PruebaSortedSet 
{
   private static final String nombres[] = { "amarillo", "verde",
       "negro", "carne", "gris", "blanco", "naranja", "rojo", "verde" };
   
   // crea un conjunto ordenado con TreeSet, y despu�s lo manipula
   public PruebaSortedSet()
   {
      // crea objeto TreeSet
      SortedSet< String > arbol = 
         new TreeSet< String >( Arrays.asList( nombres ) );

      System.out.println( "conjunto ordenado: " );
      imprimirConjunto( arbol ); // imprime el contenido del arbol

      // obtiene subconjunto mediante headSet, con base en "naranja"
      System.out.print( "\nheadSet (\"naranja\"):  " );
      imprimirConjunto( arbol.headSet( "naranja" ) );

      // obtiene subconjunto mediante tailSet, con base en "naranja"
      System.out.print( "tailSet (\"naranja\"):  " );
      imprimirConjunto( arbol.tailSet( "naranja" ) );

      // obtiene los elementos primero y �ltimo
      System.out.printf( "primero: %s\n", arbol.first() );
      System.out.printf( "ultimo : %s\n", arbol.last() );
   } // fin del constructor de PruebaSortedSet

   // imprime el conjunto en pantalla
   private void imprimirConjunto( SortedSet< String > conjunto )
   {
      for ( String s : conjunto )
         System.out.print( s + " " );

      System.out.println();
   } // fin del m�todo imprimirConjunto

   public static void main( String args[] )
   {
      new PruebaSortedSet();
   } // fin de main
} // fin de la clase PruebaSortedSet

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
