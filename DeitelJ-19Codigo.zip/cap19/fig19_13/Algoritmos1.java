// Fig. 19.13: Algoritmos1.java
// Uso de los algoritmos reverse, fill, copy, min y max.
import java.util.List;
import java.util.Arrays;
import java.util.Collections;

public class Algoritmos1 
{
   private Character[] letras = { 'P', 'C', 'M' };
   private Character[] copiaLetras;
   private List< Character > lista;
   private List< Character > copiaLista;

   // crea un objeto List y lo manipula con los m�todos de Collections
   public Algoritmos1()
   {
      lista = Arrays.asList( letras ); // obtiene el objeto List
      copiaLetras = new Character[ 3 ]; 
      copiaLista = Arrays.asList( copiaLetras ); // vista List de copiaLetras

      System.out.println( "Lista inicial: " );
      imprimir( lista );

      Collections.reverse( lista ); // invierte el orden
      System.out.println( "\nDespues de llamar a reverse: " );
      imprimir( lista );

      Collections.copy( copiaLista, lista ); // copia el objeto List
      System.out.println( "\nDespues de copy: " );
      imprimir( copiaLista );

      Collections.fill( lista, 'R' ); // llena la lista con Rs
      System.out.println( "\nDespues de llamar a fill: " );
      imprimir( lista );
   } // fin del constructor de Algoritmos1

   // imprime la informaci�n del objeto List
   private void imprimir( List< Character > refLista )
   {
      System.out.print( "La lista es: " );

      for ( Character elemento : refLista )
         System.out.printf( "%s ", elemento );

      System.out.printf( "\nMax: %s", Collections.max( refLista ) );
      System.out.printf( "  Min: %s\n", Collections.min( refLista ) );
   } // fin del m�todo imprimir

   public static void main( String args[] )
   {
      new Algoritmos1();
   } // fin de main
} // fin de la clase Algoritmos1

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/