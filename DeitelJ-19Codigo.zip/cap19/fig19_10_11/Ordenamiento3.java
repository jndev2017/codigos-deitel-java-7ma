// Fig. 19.11: Ordenamiento3.java
// Ordena una lista usando la clase Comparator personalizada ComparadorTiempo.
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class Ordenamiento3 
{
   public void imprimirElementos()
   {
      List< Tiempo2 > lista = new ArrayList< Tiempo2 >(); // crea objeto List

      lista.add( new Tiempo2(  6, 24, 34 ) );
      lista.add( new Tiempo2( 18, 14, 58 ) );
      lista.add( new Tiempo2(  6, 05, 34 ) );
      lista.add( new Tiempo2( 12, 14, 58 ) );
      lista.add( new Tiempo2(  6, 24, 22 ) );
      
      // imprime los elementos del objeto List
      System.out.printf( "Elementos del arreglo desordenados:\n%s\n", lista );

      // ordena usando un comparador
      Collections.sort( lista, new ComparadorTiempo() ); 

      // imprime los elementos del objeto List
      System.out.printf( "Elementos de la lista ordenados:\n%s\n", lista );
   } // fin del m�todo imprimirElementos
 
   public static void main( String args[] )
   {
      Ordenamiento3 ordenamiento3 = new Ordenamiento3();
      ordenamiento3.imprimirElementos();
   } // fin de main
} // fin de la clase Ordenamiento3


/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
