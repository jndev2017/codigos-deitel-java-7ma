// Fig. 19.10: ComparadorTiempo.java
// Clase Comparator personalizada que compara dos objetos Tiempo2.
import java.util.Comparator;

public class ComparadorTiempo implements Comparator< Tiempo2 > 
{
   public int compare( Tiempo2 tiempo1, Tiempo2 tiempo2 )
   {
      int compararHora = tiempo1.obtenerHora() - tiempo2.obtenerHora(); // compara la hora
         
      // eval�a la hora primero
      if ( compararHora != 0 )
         return compararHora;
         
      int comparaMinuto = 
         tiempo1.obtenerMinuto() - tiempo2.obtenerMinuto(); // compara el minuto
         
      // despu�s eval�a el minuto
      if ( comparaMinuto != 0 )
         return comparaMinuto;
         
      int compararSegundo = 
         tiempo1.obtenerSegundo() - tiempo2.obtenerSegundo(); // compara el segundo

      return compararSegundo; // devuelve el resultado de comparar los segundos
   } // fin del m�todo compare
} // fin de la clase ComparadorTiempo

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
