// Fig. 19.21: PruebaProperties.java
// Demuestra la clase Properties del paquete java.util.
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Set;

public class PruebaProperties  
{
   private Properties tabla;

   // establece la GUI para probar la tabla Properties
   public PruebaProperties()
   {
      tabla = new Properties(); // crea la tabla Properties

      // establece las propiedades
      tabla.setProperty( "color", "azul" );
      tabla.setProperty( "anchura", "200" );

      System.out.println( "Despues de establecer propiedades" );
      listarPropiedades(); // muestra los valores de las propiedades

      // reemplaza el valor de una propiedad
      tabla.setProperty( "color", "rojo" );

      System.out.println( "Despues de reemplazar propiedades" );
      listarPropiedades(); // muestra los valores de las propiedades

      guardarPropiedades(); // guarda las propiedades

      tabla.clear(); // vacia la tabla

      System.out.println( "Despues de borrar propiedades" );
      listarPropiedades(); // muestra los valores de las propiedades
      
      cargarPropiedades(); // carga las propiedades

      // obtiene el valor de la propiedad color
      Object valor = tabla.getProperty( "color" );

      // comprueba si el valor est� en la tabla
      if ( valor != null )
         System.out.printf( "El valor de la propiedad color es %s\n", valor );
      else
         System.out.println( "La propiedad color no est� en la tabla" );
   } // fin del constructor de PruebaProperties

   // guarda las propiedades en un archivo
   public void guardarPropiedades()
   {
      // guarda el contenido de la tabla
      try
      {
         FileOutputStream salida = new FileOutputStream( "props.dat" );
         tabla.store( salida, "Propiedades de ejemplo" ); // guarda las propiedades
         salida.close();
         System.out.println( "Despues de guardar las propiedades" );
         listarPropiedades(); // muestra los valores de las propiedades
      } // fin de try
      catch ( IOException ioException )
      {
         ioException.printStackTrace();
      } // fin de catch
   } // fin del m�todo guardarPropiedades

   // carga las propiedades de un archivo
   public void cargarPropiedades()
   {
      // carga el contenido de la tabla
      try
      {
         FileInputStream entrada = new FileInputStream( "props.dat" );
         tabla.load( entrada ); // carga las propiedades
         entrada.close();
         System.out.println( "Despu�s de cargar las propiedades" );
         listarPropiedades(); // muestra los valores de las propiedades
      } // fin de try
      catch ( IOException ioException )
      {
         ioException.printStackTrace();
      } // fin de catch
   } // fin del m�todo cargarPropiedades

   // imprime los valores de las propiedades
   public void listarPropiedades()
   {
      Set< Object > claves = tabla.keySet(); // obtiene los nombres de las propiedades
 
      // imprime los pares nombre/valor
      for ( Object clave : claves )
      {
         System.out.printf( 
            "%s\t%s\n", clave, tabla.getProperty( ( String ) clave ) );
      } // fin de for

      System.out.println();
   } // fin del m�todo listarPropiedades

   public static void main( String args[] )
   {
      new PruebaProperties();
   } // fin de main
} // fin de la clase PruebaProperties

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
