// Fig. 19.5: UsoToArray.java
// Uso del m�todo toArray.
import java.util.LinkedList;
import java.util.Arrays;

public class UsoToArray 
{
   // el constructor crea un objeto LinkedList, le agrega elementos y lo convierte en arreglo
   public UsoToArray()
   {
      String colores[] = { "negro", "azul", "amarillo" };

      LinkedList< String > enlaces = 
         new LinkedList< String >( Arrays.asList( colores ) );

      enlaces.addLast( "rojo" );   // lo agrega como �ltimo elemento
      enlaces.add( "rosa" );      // lo agrega al final
      enlaces.add( 3, "verde" );  // lo agrega en el 3er �ndice
      enlaces.addFirst( "cyan" ); // lo agrega como primer elemento 

      // obtiene los elementos de LinkedList como un arreglo 
      colores = enlaces.toArray( new String[ enlaces.size() ] );

      System.out.println( "colores: " );

      for ( String color : colores )
         System.out.println( color );
   } // fin del constructor de UsoToArray

   public static void main( String args[] )
   {
      new UsoToArray();
   } // fin de main 
} // fin de la clase UsoToArray


/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/