// Fig. 19.6: PruebaVector.java
// Uso de la clase Vector.
import java.util.Vector;
import java.util.NoSuchElementException;

public class PruebaVector 
{
   private static final String colores[] = { "rojo", "blanco", "azul" };

   public PruebaVector()
   {
      Vector< String > vector = new Vector< String >();
      imprimirVector( vector ); // imprime el vector

      // agrega elementos al vector
      for ( String color : colores )
         vector.add( color );   

      imprimirVector( vector ); // imprime el vector
      
      // imprime los elementos primero y �ltimo
      try 
      {
         System.out.printf( "Primer elemento: %s\n", vector.firstElement());
         System.out.printf( "Ultimo elemento: %s\n", vector.lastElement() );
      } // fin de try
      // atrapa la excepci�n si el vector est� vac�o
      catch ( NoSuchElementException excepcion ) 
      {
         excepcion.printStackTrace();
      } // fin de catch
      
      // �el vector contiene "rojo"?
      if ( vector.contains( "rojo" ) )
         System.out.printf( "\nse encontro \"rojo\" en el indice %d\n\n", 
            vector.indexOf( "rojo" ) );
      else
         System.out.println( "\nno se encontro \"rojo\"\n" );
      
      vector.remove( "rojo" ); // elimina la cadena "rojo"
      System.out.println( "se elimino \"rojo\"" );
      imprimirVector( vector ); // imprime el vector
      
      // �el vector contiene "rojo" despu�s de la operaci�n de eliminaci�n?
      if ( vector.contains( "rojo" ) )
         System.out.printf( 
            "se encontro \"rojo\" en el indice %d\n", vector.indexOf( "rojo" ) );
      else
         System.out.println( "no se encontro \"rojo\"" );
      
      // imprime el tama�o y la capacidad del vector
      System.out.printf( "\nTamanio: %d\nCapacidad: %d\n", vector.size(), 
         vector.capacity() );
   } // fin del constructor de PruebaVector
   
   private void imprimirVector( Vector< String > vectorAImprimir )
   {
      if ( vectorAImprimir.isEmpty() ) 
         System.out.print( "el vector esta vacio" ); // vectorAImprimir est� vac�o
      else  // itera a trav�s de los elementos
      { 
         System.out.print( "el vector contiene: " );      

         // imprime los elementos
         for ( String elemento : vectorAImprimir )
            System.out.printf( "%s ", elemento );
      } // fin de else
      
      System.out.println( "\n" ); 
   } // fin del m�todo imprimirVector

   public static void main( String args[] )
   {
      new PruebaVector(); // crea objeto y llama a su constructor
   } // fin de main
} // fin de la clase PruebaVector

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/