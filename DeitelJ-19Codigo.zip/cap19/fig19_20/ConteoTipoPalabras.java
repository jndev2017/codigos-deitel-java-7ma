// Fig. 19.20: ConteoTipoPalabras.java
// Programa que cuenta el n�mero de ocurrencias de cada palabra en una cadena
import java.util.StringTokenizer;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.TreeSet;
import java.util.Scanner;

public class ConteoTipoPalabras
{
   private Map< String, Integer > mapa;
   private Scanner scanner;

   public ConteoTipoPalabras()
   {
      mapa = new HashMap< String, Integer >(); // crea objeto HashMap
      scanner = new Scanner( System.in ); // crea objeto scanner
      crearMap(); // crea un mapa con base en la entrada del usuario
      mostrarMap(); // muestra el contenido del mapa
   } // fin del constructor de ConteoTipoPalabras
   
   // crea mapa a partir de la entrada del usuario
   private void crearMap() 
   {
      System.out.println( "Escriba una cadena:" ); // pide la entrada del usuario
      String entrada = scanner.nextLine();

      // crea objeto StringTokenizer para los datos de entrada
      StringTokenizer tokenizer = new StringTokenizer( entrada );
               
      // procesamiento del texto de entrada 
      while ( tokenizer.hasMoreTokens() ) // mientras haya m�s entrada 
      {
         String palabra = tokenizer.nextToken().toLowerCase(); // obtiene una palabra
                  
         // si el mapa contiene la palabra
         if ( mapa.containsKey( palabra ) ) // esta la palabra en el mapa?
         {
            int cuenta = mapa.get( palabra ); // obtiene la cuenta actual
            mapa.put( palabra, cuenta + 1 );  // incrementa la cuenta
         } // fin de if
         else 
            mapa.put( palabra, 1 ); // agrega una nueva palabra con una cuenta de 1 al mapa
       } // fin de while
   } // fin del m�todo crearMap
   
   // muestra el contenido del mapa
   private void mostrarMap() 
   {      
      Set< String > claves = mapa.keySet(); // obtiene las claves

      // ordena las claves
      TreeSet< String > clavesOrdenadas = new TreeSet< String >( claves );

      System.out.println( "El mapa contiene:\nClave\t\tValor" );

      // genera la salida para cada clave en el mapa
      for ( String clave : clavesOrdenadas )
         System.out.printf( "%-10s%10s\n", clave, mapa.get( clave ) );
      
      System.out.printf( 
         "\nsize:%d\nisEmpty:%b\n", mapa.size(), mapa.isEmpty() );
   } // fin del m�todo mostrarMap

   public static void main( String args[] )
   {
      new ConteoTipoPalabras();
   } // fin de main
} // fin de la clase ConteoTipoPalabras


/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
