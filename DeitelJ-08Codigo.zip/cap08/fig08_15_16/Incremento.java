// Fig. 8.15: Incremento.java
// variable de instancia final en una clase.

public class Incremento 
{
   private int total = 0; // el total de todos los incrementos
   private final int INCREMENTO; // variable constante (sin inicializar)

   // el constructor inicializa la variable de instancia final INCREMENTO
   public Incremento( int valorIncremento )
   {
      INCREMENTO = valorIncremento; // inicializa la variable constante (una vez)
   } // fin del constructor de Incremento

   // suma INCREMENTO al total
   public void sumarIncrementoATotal()
   {
      total += INCREMENTO;
   } // fin del m�todo sumarIncrementoATotal 

   // devuelve representaci�n String de los datos de un objeto Incremento
   public String toString()
   {
      return String.format( "total = %d", total );
   } // fin del m�todo toString
} // fin de la clase Incremento


/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/