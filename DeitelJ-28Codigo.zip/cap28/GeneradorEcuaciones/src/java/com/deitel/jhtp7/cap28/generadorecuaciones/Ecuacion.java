// Fig. 22.20: Ecuacion.java
// Clase Ecuacion que contiene informaci�n acerca de una ecuaci�n
package com.deitel.jhtp7.cap28.generadorecuaciones;

public class Ecuacion
{
   private int operandoIzq;
   private int operandoDer;
   private int valorResultado;
   private String tipoOperacion;
   
   // constructor sin argumentos requerido
   public Ecuacion()
   {
      this( 0, 0, "+" ); 
   } // fin del constructor sin argumentos
   
   public Ecuacion( int valorIzq, int valorDer, String tipo )
   {
      operandoIzq = valorIzq;
      operandoDer = valorDer;
      tipoOperacion = tipo;
      
      // determina valorResultado
      if ( tipoOperacion.equals( "+" ) ) // suma
         valorResultado = operandoIzq + operandoDer;
      else if ( tipoOperacion.equals( "-" ) ) // resta
         valorResultado = operandoIzq - operandoDer;
      else // multiplicaci�n
         valorResultado = operandoIzq * operandoDer;
   } // fin del constructor con tres argumentos
   
   // devuelve una representaci�n String de una Ecuacion
   public String toString()
   {
      return operandoIzq + " " + tipoOperacion + " " +
         operandoDer + " = " + valorResultado; 
   } // fin del m�todo toString
   
   // devuelve el lado izquierdo de la ecuaci�n como un objeto String
   public String getLadoIzq()
   {
      return operandoIzq + " " + tipoOperacion + " " + operandoDer;
   } // fin del m�todo getLadoIzq
   
   // devuelve el lado derecho de la ecuaci�n como un objeto String
   public String getLadoDer()
   {
      return "" + valorResultado;
   } // fin del m�todo getLadoDer

   // obtiene el operandoIzq
   public int getOperandoIzq()
   {
      return operandoIzq;
   } // fin del m�todo getOperandoIzq
   
   // obtiene el operandoDer
   public int getOperandoDer()
   {
      return operandoDer;
   } // fin del m�todo getOperandoDer
   
   // obtiene el valorResultado
   public int getValorRetorno()
   {
      return valorResultado;
   } // fin del m�todo getValorRetorno
   
   // obtiene el tipoOperacion
   public String getTipoOperacion()
   {
      return tipoOperacion;
   } // end method getTipoOperacion 
   
   // m�todo set requerido
   public void setLadoIzq( String value )
   {
      // cuerpo vac�o
   } // fin del m�todo setLadoIzq
   
   // m�todo set requerido
   public void setLadoDer( String value )
   {
      // cuerpo vac�o
   } // fin del m�todo setLadoDer
   
   // m�todo set requerido
   public void setOperandoIzq( int value )
   {
      // cuerpo vac�o
   } // fin del m�todo setOperandoIzq
   
   // m�todo set requerido
   public void setOperandoDer( int value )
   {
      // cuerpo vac�o
   } // fin del m�todo setOperandoDer
   
   // m�todo set requerido
   public void setValorRetorno( int value )
   {
      // cuerpo vac�o
   } // fin del m�todo setValorRetorno
   
   // m�todo set requerido
   public void setTipoOperacion( String value )
   {
      // cuerpo vac�o
   } // fin del m�todo setTipoOperacion
} // fin de la clase Ecuacion