// Fig. 28.14: JuegoBlackjackJFrame.java
// Juego de Blackjack que utiliza el servicio Web Blackjack
package com.deitel.jhtp7.ch28.clienteblackjack;

import java.awt.Color;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.xml.ws.BindingProvider;
import com.deitel.jhtp7.cap28.clienteblackjack.Blackjack;
import com.deitel.jhtp7.cap28.clienteblackjack.ServicioBlackjack;

public class JuegoBlackjackJFrame extends javax.swing.JFrame
{   
   private String cartasJugador;
   private String cartasRepartidor;
   private ArrayList< JLabel > naipes; // lista de objetos JLabel con im�genes de las cartas
   private int cartaActualJugador; // n�mero de carta actual del jugador
   private int cartaActualRepartidor; // n�mero de carta actual de proxyBlackjack
   private ServicioBlackjack servicioBlackjack; // se utiliza para obtener el proxy
   private Blackjack proxyBlackjack; // se utiliza para acceder al servicio Web

   // enumeraci�n de estados del juego
   private enum EstadoJuego 
   { 
      EMPATE, // el juego termina en un empate
      PIERDE, // el jugador pierde
      GANA, // el jugador gana
      BLACKJACK // el jugador tiene blackjack
   } // fin de enum EstadoJuego
   
   // constructor sin argumentos
   public JuegoBlackjackJFrame()
   {
      initComponents();
      
      // debido a un error en Netbeans, debemos cambiar el color de fondo
      // del objeto JFrame aqu�, en vez de hacerlo en el dise�ador
      getContentPane().setBackground( new Color( 0, 180, 0 ) );
      
      // inicializa el proxy blackjack
      try 
      {
         // crea los objetos para acceder al servicio Web Blackjack
         servicioBlackjack = new ServicioBlackjack();
         proxyBlackjack = servicioBlackjack.getBlackjackPort();
         
         // habilita el rastreo de sesiones
         ( ( BindingProvider ) proxyBlackjack ).getRequestContext().put(
            BindingProvider.SESSION_MAINTAIN_PROPERTY, true );
      } // fin de try
      catch ( Exception e )
      {
         e.printStackTrace();
      } // fin de catch
      
      // agrega componentes JLabel al objeto ArrayList naipes para manipularlo mediante programaci�n
      naipes = new ArrayList< JLabel >();
      
      naipes.add( carta1RepartidorJLabel );
      naipes.add( carta2RepartidorJLabel );
      naipes.add( carta3RepartidorJLabel );   
      naipes.add( carta4RepartidorJLabel );   
      naipes.add( carta5RepartidorJLabel );   
      naipes.add( carta6RepartidorJLabel );   
      naipes.add( carta7RepartidorJLabel );   
      naipes.add( carta8RepartidorJLabel );   
      naipes.add( carta9RepartidorJLabel );   
      naipes.add( carta10RepartidorJLabel );   
      naipes.add( carta11RepartidorJLabel );   
      naipes.add( carta1JugadorJLabel );   
      naipes.add( carta2JugadorJLabel );   
      naipes.add( carta3JugadorJLabel );   
      naipes.add( carta4JugadorJLabel );   
      naipes.add( carta5JugadorJLabel );   
      naipes.add( carta6JugadorJLabel );   
      naipes.add( carta7JugadorJLabel );   
      naipes.add( carta8JugadorJLabel );   
      naipes.add( carta9JugadorJLabel );   
      naipes.add( carta10JugadorJLabel );   
      naipes.add( carta11JugadorJLabel );       
   } // fin del constructor sin argumentos
   
   // juega la mano del repartidor
   private void juegoRepartidor()
   {  
      try
      {
         // mientras el valor de la mano del repartidor sea menor a 17
         // el repartidor debe seguir tomando cartas
         String[] cartas = cartasRepartidor.split( "\t" );
      
         // muestra las cartas del repartidor
         for ( int i = 0; i < cartas.length; i++ )
            mostrarCarta( i, cartas[ i ] );
         
         while ( proxyBlackjack.obtenerValorMano( cartasRepartidor ) < 17 )
         {
            String nuevaCarta = proxyBlackjack.repartirCarta(); // reparte una nueva carta
            cartasRepartidor += "\t" + nuevaCarta; // reparte una nueva carta 
            mostrarCarta( cartaActualRepartidor, nuevaCarta );
            ++cartaActualRepartidor;
            JOptionPane.showMessageDialog( this, "El repartidor toma una carta",
               "Turno del repartidor", JOptionPane.PLAIN_MESSAGE );
         } // end while
      
         int totalRepartidor = proxyBlackjack.obtenerValorMano( cartasRepartidor );
         int totalJugador = proxyBlackjack.obtenerValorMano( cartasJugador );
      
         // si el repartidor se pas�, el jugador gana
         if ( totalRepartidor > 21 )
         {
            finDelJuego( EstadoJuego.GANA );
            return;
         } // fin de if
      
         // si el repartidor y el jugador tienen menos de 21
         // la mayor puntuaci�n gana, si tienen igual puntuaci�n es un empate
         if ( totalRepartidor > totalJugador )
            finDelJuego( EstadoJuego.PIERDE );
         else if (totalRepartidor < totalJugador )
            finDelJuego( EstadoJuego.GANA );
         else
            finDelJuego( EstadoJuego.EMPATE );
      } // fin de try
      catch ( Exception e )
      {
         e.printStackTrace();
      } // fin de catch
   } // fin del m�todo juegoRepartidor
   
   // muestra la carta representada por valorCarta en el objeto JLabel especificado
   public void mostrarCarta( int carta, String valorCarta )
   {
      try
      {
         // obtiene el objeto JLabel correcto de naipes
         JLabel mostrarEtiqueta = naipes.get( carta );
         
         // si la cadena que representa a carta est� vac�a, muestra la parte posterior de la carta
         if ( valorCarta.equals( "" ) )
         {
            mostrarEtiqueta.setIcon( new ImageIcon( getClass().getResource(
               "/com/deitel/jhtp7/cap28/clienteblackjack/" + 
               "blackjack_imagenes/cartpost.png" ) ) ) ;
            return;
         } // fin de if

         // obtiene el valor de la cara de la carta
         String cara = valorCarta.substring( 0, valorCarta.indexOf( " " ) );

         // obtiene el palo de la carta
         String palo = 
            valorCarta.substring( valorCarta. indexOf( " " ) + 1 );

         char letraPalo; // letra del palo que se usa para formar el archivo de imagen

         switch ( Integer.parseInt( palo ) )
         {
            case 0: // corazones
               letraPalo = 'c';
               break;
            case 1: // diamantes
               letraPalo = 'd';
               break;
            case 2: // bastos
               letraPalo = 'b';
               break;
            default: // espadas
               letraPalo = 'e';
               break;
         } // fin de switch

         // establece la imagen para mostrarEtiqueta
         mostrarEtiqueta.setIcon( new ImageIcon( getClass().getResource(
            "/com/deitel/jhtp7/cap28/clienteblackjack/blackjack_imagenes/" +
            cara + letraPalo + ".png" ) ) );
      } // fin de try
      catch ( Exception e )
      {
         e.printStackTrace();
      } // fin de catch
   } // fin del m�todo mostrarCarta
   
   // muestra todas las cartas del jugador y el mensaje apropiado
   public void finDelJuego( EstadoJuego ganador )
   {
      String[] cartas = cartasRepartidor.split( "\t" );
      
      // muestra las cartas de proxyBlackjack
      for ( int i = 0; i < cartas.length; i++ )
         mostrarCarta( i, cartas[ i ]);
      
      // muestra la imagen del estado apropiado
      if ( ganador == EstadoJuego.GANA )
         estadoJLabel.setText( "Usted gana!" );
      else if ( ganador == EstadoJuego.PIERDE )
         estadoJLabel.setText( "Usted pierde." );
      else if ( ganador == EstadoJuego.EMPATE )
         estadoJLabel.setText( "Es un empate." );
      else // blackjack
         estadoJLabel.setText( "Blackjack!" );
      
      // muestra las puntuaciones finales
      int totalRepartidor = proxyBlackjack.obtenerValorMano( cartasRepartidor );
      int totalJugador = proxyBlackjack.obtenerValorMano( cartasJugador );      
      totalRepartidorJLabel.setText( "Repartidor: " +  totalRepartidor );
      totalJugadorJLabel.setText( "Jugador: " + totalJugador );
      
      // restablece para nuevo juego
      pasarJButton.setEnabled( false );
      pedirJButton.setEnabled( false );
      repartirJButton.setEnabled( true );
   } // fin del m�todo finDelJuego
   
   // El m�todo initComponents es generado autom�ticamente por Netbeans y se llama
   // desde el constructor para inicializar la GUI. No mostraremos aqu� este m�todo
   // para ahorrar espacio. Abra JuegoBlackjackJFrame.java en la carpeta de 
   // este ejemplo para ver el c�digo generado completo (l�neas 221 a 530) 
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        repartidorJLabel = new javax.swing.JLabel();
        carta1RepartidorJLabel = new javax.swing.JLabel();
        carta2RepartidorJLabel = new javax.swing.JLabel();
        carta3RepartidorJLabel = new javax.swing.JLabel();
        carta4RepartidorJLabel = new javax.swing.JLabel();
        carta5RepartidorJLabel = new javax.swing.JLabel();
        carta6RepartidorJLabel = new javax.swing.JLabel();
        carta7RepartidorJLabel = new javax.swing.JLabel();
        carta8RepartidorJLabel = new javax.swing.JLabel();
        carta9RepartidorJLabel = new javax.swing.JLabel();
        carta10RepartidorJLabel = new javax.swing.JLabel();
        carta11RepartidorJLabel = new javax.swing.JLabel();
        repartirJButton = new javax.swing.JButton();
        pedirJButton = new javax.swing.JButton();
        pasarJButton = new javax.swing.JButton();
        jugadorJLabel = new javax.swing.JLabel();
        carta1JugadorJLabel = new javax.swing.JLabel();
        carta2JugadorJLabel = new javax.swing.JLabel();
        carta3JugadorJLabel = new javax.swing.JLabel();
        carta4JugadorJLabel = new javax.swing.JLabel();
        carta5JugadorJLabel = new javax.swing.JLabel();
        carta6JugadorJLabel = new javax.swing.JLabel();
        carta7JugadorJLabel = new javax.swing.JLabel();
        carta8JugadorJLabel = new javax.swing.JLabel();
        carta9JugadorJLabel = new javax.swing.JLabel();
        carta10JugadorJLabel = new javax.swing.JLabel();
        carta11JugadorJLabel = new javax.swing.JLabel();
        estadoJLabel = new javax.swing.JLabel();
        totalRepartidorJLabel = new javax.swing.JLabel();
        totalJugadorJLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Blackjack");
        repartidorJLabel.setFont(new java.awt.Font("Tahoma", 1, 18));
        repartidorJLabel.setForeground(new java.awt.Color(255, 255, 255));
        repartidorJLabel.setText("Mano del repartidor:");

        carta1RepartidorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta1RepartidorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta1RepartidorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta2RepartidorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta2RepartidorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta2RepartidorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta3RepartidorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta3RepartidorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta3RepartidorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta4RepartidorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta4RepartidorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta4RepartidorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta5RepartidorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta5RepartidorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta5RepartidorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta6RepartidorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta6RepartidorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta6RepartidorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta7RepartidorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta7RepartidorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta7RepartidorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta8RepartidorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta8RepartidorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta8RepartidorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta9RepartidorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta9RepartidorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta9RepartidorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta10RepartidorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta10RepartidorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta10RepartidorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta11RepartidorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta11RepartidorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta11RepartidorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        repartirJButton.setFont(new java.awt.Font("Tahoma", 1, 14));
        repartirJButton.setText("Repartir");
        repartirJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                repartirJButtonActionPerformed(evt);
            }
        });

        pedirJButton.setFont(new java.awt.Font("Tahoma", 1, 14));
        pedirJButton.setText("Pedir");
        pedirJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pedirJButtonActionPerformed(evt);
            }
        });

        pasarJButton.setFont(new java.awt.Font("Tahoma", 1, 14));
        pasarJButton.setText("Pasar");
        pasarJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasarJButtonActionPerformed(evt);
            }
        });

        jugadorJLabel.setFont(new java.awt.Font("Tahoma", 1, 18));
        jugadorJLabel.setForeground(new java.awt.Color(255, 255, 255));
        jugadorJLabel.setText("Player's hand:");

        carta1JugadorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta1JugadorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta1JugadorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta2JugadorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta2JugadorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta2JugadorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta3JugadorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta3JugadorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta3JugadorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta4JugadorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta4JugadorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta4JugadorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta5JugadorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta5JugadorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta5JugadorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta6JugadorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta6JugadorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta6JugadorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta7JugadorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta7JugadorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta7JugadorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta8JugadorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta8JugadorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta8JugadorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta9JugadorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta9JugadorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta9JugadorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta10JugadorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta10JugadorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta10JugadorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        carta11JugadorJLabel.setMaximumSize(new java.awt.Dimension(65, 87));
        carta11JugadorJLabel.setMinimumSize(new java.awt.Dimension(65, 87));
        carta11JugadorJLabel.setPreferredSize(new java.awt.Dimension(65, 87));

        estadoJLabel.setFont(new java.awt.Font("Tahoma", 1, 14));
        estadoJLabel.setForeground(new java.awt.Color(255, 255, 255));
        estadoJLabel.setText(" ");

        totalRepartidorJLabel.setFont(new java.awt.Font("Tahoma", 1, 14));
        totalRepartidorJLabel.setForeground(new java.awt.Color(255, 255, 255));
        totalRepartidorJLabel.setText(" ");

        totalJugadorJLabel.setFont(new java.awt.Font("Tahoma", 1, 14));
        totalJugadorJLabel.setForeground(new java.awt.Color(255, 255, 255));
        totalJugadorJLabel.setText(" ");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(repartidorJLabel))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(carta1RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(carta7RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(carta2RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(carta8RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(carta3RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(carta9RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(carta4RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(carta10RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(carta5RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(carta6RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(28, 28, 28)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(repartirJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(pedirJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(carta11RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 99, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(estadoJLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(pasarJButton, javax.swing.GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jugadorJLabel))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(carta1JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(carta2JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(carta3JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(carta4JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(carta5JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(carta6JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(28, 28, 28)
                                .addComponent(totalRepartidorJLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(totalJugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(carta7JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(carta8JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(carta9JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(carta10JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(carta11JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(repartidorJLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(repartirJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(pedirJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(carta6RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(carta5RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(carta4RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(carta3RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(carta1RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(carta2RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(carta7RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(carta8RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(carta9RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(carta10RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(carta11RepartidorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(pasarJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jugadorJLabel)
                                    .addComponent(estadoJLabel))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(carta1JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(carta2JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(carta3JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(carta4JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(carta5JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(totalRepartidorJLabel)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(totalJugadorJLabel))
                        .addComponent(carta6JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(carta7JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(carta8JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(carta9JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(carta10JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(carta11JugadorJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pack();
    }// </editor-fold>//GEN-END:initComponents

   // maneja el clic del objeto pasarJButton
   private void pasarJButtonActionPerformed(
      java.awt.event.ActionEvent evt ) 
   {
      pasarJButton.setEnabled( false );
      pedirJButton.setEnabled( false );
      repartirJButton.setEnabled( true );
      juegoRepartidor();
   } // fin del m�todo pasarJButtonActionPerformed

   // maneja el clic del objeto pedirJButton
   private void pedirJButtonActionPerformed(
      java.awt.event.ActionEvent evt ) 
   {
      // obtiene otra carta para el jugador
      String carta = proxyBlackjack.repartirCarta(); // reparte una nueva carta
      cartasJugador += "\t" + carta; // agrega la carta a la mano
      
      // actualiza la GUI para mostrar una nueva carta
      mostrarCarta( cartaActualJugador, carta );
      ++cartaActualJugador;
      
      // determina el nuevo valor de la mano del jugador
      int total = proxyBlackjack.obtenerValorMano( cartasJugador );
      
      if ( total > 21 ) // el jugador se pasa
         finDelJuego( EstadoJuego.PIERDE );
      if ( total == 21 ) // el jugador no puede tomar m�s cartas
      {
         pedirJButton.setEnabled( false );
         juegoRepartidor();
      } // fin de if
   } // fin del m�todo pedirJButtonActionPerformed

   // maneja el clic del objeto repartirJButton
   private void repartirJButtonActionPerformed(
      java.awt.event.ActionEvent evt ) 
   {
      String carta; // almacena una carta temporalmente hasta que se agrega a una mano
      
      // borra las im�genes de las cartas
      for ( int i = 0; i < naipes.size(); i++ )
         naipes.get( i ).setIcon( null );
      
      estadoJLabel.setText( "" );
      totalRepartidorJLabel.setText( "" );
      totalJugadorJLabel.setText( "" );
      
      // crea un nuevo mazo barajado en un equipo remoto
      proxyBlackjack.barajar();
      
      // reparte dos cartas al jugador
      cartasJugador = proxyBlackjack.repartirCarta(); // agrega la primera carta a la mano
      mostrarCarta( 11, cartasJugador ); // muestra la primera carta
      carta = proxyBlackjack.repartirCarta(); // reparte la segunda carta
      mostrarCarta( 12, carta ); // muestra la segunda carta
      cartasJugador += "\t" + carta; // agrega la segunda carta a la mano
      
      // reparte dos cartas a proxyBlackjack, pero s�lo muestra la primera
      cartasRepartidor = proxyBlackjack.repartirCarta(); // agrega la primera carta a la mano
      mostrarCarta( 0, cartasRepartidor ); // muestra la primera carta
      carta = proxyBlackjack.repartirCarta(); // reparte la segunda carta
      mostrarCarta( 1, "" ); // muestra la parte posterior de la carta
      cartasRepartidor += "\t" + carta; // agrega la segunda carta a la mano
      
      pasarJButton.setEnabled( true );
      pedirJButton.setEnabled( true );
      repartirJButton.setEnabled( false );
      
      // determina el valor de las dos manos
      int totalRepartidor = proxyBlackjack.obtenerValorMano( cartasRepartidor );
      int totalJugador = proxyBlackjack.obtenerValorMano( cartasJugador );
      
      // si ambas manos son iguales a 21, es un empate
      if ( totalJugador == totalRepartidor && totalJugador == 21 )
         finDelJuego( EstadoJuego.EMPATE );
      else if (totalRepartidor == 21 ) // proxyBlackjack tiene blackjack
         finDelJuego( EstadoJuego.PIERDE );
      else if (totalJugador == 21 ) // blackjack
         finDelJuego( EstadoJuego.BLACKJACK );
      
      // la siguiente carta para proxyBlackjack tiene el �ndice 2
      cartaActualRepartidor = 2;
      
      // la siguente carta para el jugador tiene el �ndice 13
      cartaActualJugador = 13;
   } // fin del m�todo repartirJButtonActionPerformed
   
   // empieza la ejecuci�n de la aplicaci�n
   public static void main( String args[] )
   {
      java.awt.EventQueue.invokeLater( 
         new Runnable()
         {
            public void run()
            {
               new JuegoBlackjackJFrame().setVisible(true);
            }
         }
      ); // fin de la llamada a java.awt.EventQueue.invokeLater
   } // fin del m�todo main
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel carta10JugadorJLabel;
    private javax.swing.JLabel carta10RepartidorJLabel;
    private javax.swing.JLabel carta11JugadorJLabel;
    private javax.swing.JLabel carta11RepartidorJLabel;
    private javax.swing.JLabel carta1JugadorJLabel;
    private javax.swing.JLabel carta1RepartidorJLabel;
    private javax.swing.JLabel carta2JugadorJLabel;
    private javax.swing.JLabel carta2RepartidorJLabel;
    private javax.swing.JLabel carta3JugadorJLabel;
    private javax.swing.JLabel carta3RepartidorJLabel;
    private javax.swing.JLabel carta4JugadorJLabel;
    private javax.swing.JLabel carta4RepartidorJLabel;
    private javax.swing.JLabel carta5JugadorJLabel;
    private javax.swing.JLabel carta5RepartidorJLabel;
    private javax.swing.JLabel carta6JugadorJLabel;
    private javax.swing.JLabel carta6RepartidorJLabel;
    private javax.swing.JLabel carta7JugadorJLabel;
    private javax.swing.JLabel carta7RepartidorJLabel;
    private javax.swing.JLabel carta8JugadorJLabel;
    private javax.swing.JLabel carta8RepartidorJLabel;
    private javax.swing.JLabel carta9JugadorJLabel;
    private javax.swing.JLabel carta9RepartidorJLabel;
    private javax.swing.JLabel estadoJLabel;
    private javax.swing.JLabel jugadorJLabel;
    private javax.swing.JButton pasarJButton;
    private javax.swing.JButton pedirJButton;
    private javax.swing.JLabel repartidorJLabel;
    private javax.swing.JButton repartirJButton;
    private javax.swing.JLabel totalJugadorJLabel;
    private javax.swing.JLabel totalRepartidorJLabel;
    // End of variables declaration//GEN-END:variables
} // fin de la clase JuegoBlackjackJFrame


/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/



