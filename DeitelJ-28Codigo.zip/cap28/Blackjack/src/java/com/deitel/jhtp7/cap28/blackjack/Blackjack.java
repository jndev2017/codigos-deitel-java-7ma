// Fig. 28.13: Blackjack.java
// Servicio Web Blackjack que reparte cartas y eval�a manos
package com.deitel.jhtp7.ch28.blackjack;

import java.util.ArrayList;
import java.util.Random;
import javax.annotation.Resource;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;

@WebService( name = "Blackjack", serviceName = "ServicioBlackjack" )
public class Blackjack
{
   // usa @Resource para crear un objeto WebServiceContext para rastrear sesiones
   private @Resource WebServiceContext contextoServicioWeb; 
   private MessageContext contextoMensaje; // se utiliza en el rastreo de sesiones
   private HttpSession sesion; // almacena los atributos de la sesi�n
   
   // reparte una carta
   @WebMethod( operationName = "repartirCarta" )
   public String repartirCarta()
   {
      String carta = "";
      
      ArrayList< String > mazo = 
         ( ArrayList< String > ) sesion.getAttribute( "mazo" );
      
      carta = mazo.get( 0 ); // obtiene la carta superior del mazo
      mazo.remove( 0 ); // elimina la carta superior del mazo
      
      return carta; 
   } // fin del M�todo Web repartirCarta
   
   // baraja el mazo
   @WebMethod( operationName = "barajar" )
   public void barajar()
   {
      // obtiene el objeto HttpSession para almacenar el mazo para el cliente actual
      contextoMensaje = contextoServicioWeb.getMessageContext();
      sesion = ( ( HttpServletRequest ) contextoMensaje.get( 
         MessageContext.SERVLET_REQUEST ) ).getSession();
      
      // llena el mazo de cartas
      ArrayList< String > mazo = new ArrayList< String >();
      
      for ( int cara = 1; cara <= 13; cara++ ) // itera a trav�s de las caras
         for ( int palo = 0; palo <= 3; palo++ ) // itera a trav�s de los palos
            mazo.add( cara + " " + palo ); // agrega cada carta al mazo
      
      String cartaTemp; // guarda la carta temporalmente durante el intercambio
      Random objetoAleatorio = new Random(); // genera n�meros aleatorios
      int indice; // �ndice la carta seleccionada al azar

      for ( int i = 0; i < mazo.size() ; i++ ) // baraja
      {
         indice = objetoAleatorio.nextInt( mazo.size() - 1 );
         
         // intercambia la carta en la posici�n i con la carta seleccionada al azar
         cartaTemp = mazo.get( i ); 
         mazo.set( i, mazo.get( indice ) ); 
         mazo.set( indice, cartaTemp ); 
      } // fin de for
      
      // agrega este mazo a la sesi�n del usuario
      sesion.setAttribute( "mazo", mazo );
   } // fin del M�todo Web barajar
   
   // determina el valor de una mano
   @WebMethod( operationName = "obtenerValorMano" )
   public int obtenerValorMano( @WebParam( name = "mano" ) String mano )
   {
      // divide la mano en cartas
      String[] cartas = mano.split( "\t" );
      int total = 0; // valor total de las cartas en la mano
      int cara; // cara de la carta actual
      int cuentaAses = 0; // n�mero de ases en la mano
      
      for ( int i = 0; i < cartas.length; i++ )
      {
         // analiza la cadena y obtiene el primer int en el objeto String
         cara = Integer.parseInt( 
            cartas[ i ].substring( 0, cartas[ i ].indexOf( " " ) ) );
         
         switch ( cara )
         {
            case 1: // en as, incrementa cuentaAses
               ++cuentaAses;
               break;
            case 11: // joto
            case 12: // reina
            case 13: // rey
               total += 10;
               break;
            default: // en cualquier otro caso, suma la cara
               total += cara;
               break;
         } // fin de switch
      } // fin de for
      
      // calcula el uso �ptimo de los ases
      if ( cuentaAses > 0 )
      {
         // si es posible, cuenta un as como 11
         if ( total + 11 + cuentaAses - 1 <= 21 )
            total += 11 + cuentaAses - 1;
         else // en cualquier otro caso, cuenta todos los ases como 1
            total += cuentaAses;
       } // fin de if
      
      return total;
   } // fin del M�todo Web obtenerValorMano
} // fin de la clase Blackjack


/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/