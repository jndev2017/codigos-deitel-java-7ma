// Fig. 28.19: Reservar.java
// Clase de bean de soporte con �mbito de p�gina para el cliente de reservaci�n de asientos
package com.deitel.jhtp7.cap28.clientereservacion;

import com.sun.rave.web.ui.appbase.AbstractPageBean;
import com.sun.rave.web.ui.component.Body;
import com.sun.rave.web.ui.component.Form;
import com.sun.rave.web.ui.component.Head;
import com.sun.rave.web.ui.component.Html;
import com.sun.rave.web.ui.component.Link;
import com.sun.rave.web.ui.component.Page;
import javax.faces.FacesException;
import com.sun.rave.web.ui.component.Label;
import com.sun.rave.web.ui.component.DropDown;
import com.sun.rave.web.ui.model.SingleSelectOptionsList;
import com.sun.rave.web.ui.component.Button;
import com.sun.rave.web.ui.component.StaticText;
import webservice.servicioreservacion.
        servicioreservacion1.ServicioReservacion1Client;
import javax.faces.event.ValueChangeEvent;

public class Reservar extends AbstractPageBean {
    // <editor-fold defaultstate="collapsed" desc="Creator-managed Component Definition">
    private int __placeholder;
    
    /**
     * <p>Automatically managed component initialization.  <strong>WARNING:</strong>
     * This method is automatically generated, so any user-specified code inserted
     * here is subject to being replaced.</p>
     */
    private void _init() throws Exception {
        tipoAsientoListaDesplegableDefaultOptions.setOptions(new com.sun.rave.web.ui.model.Option[] {new com.sun.rave.web.ui.model.Option("Ventana", "Ventana"), new com.sun.rave.web.ui.model.Option("Centro", "Centro"), new com.sun.rave.web.ui.model.Option("Pasillo", "Pasillo")});
        claseListaDesplegableDefaultOptions.setOptions(new com.sun.rave.web.ui.model.Option[] {new com.sun.rave.web.ui.model.Option("Primera", "Primera"), new com.sun.rave.web.ui.model.Option("Economica", "Economica")});
    }
    
    private Page page1 = new Page();
    
    public Page getPage1() {
        return page1;
    }
    
    public void setPage1(Page p) {
        this.page1 = p;
    }
    
    private Html html1 = new Html();
    
    public Html getHtml1() {
        return html1;
    }
    
    public void setHtml1(Html h) {
        this.html1 = h;
    }
    
    private Head head1 = new Head();
    
    public Head getHead1() {
        return head1;
    }
    
    public void setHead1(Head h) {
        this.head1 = h;
    }
    
    private Link link1 = new Link();
    
    public Link getLink1() {
        return link1;
    }
    
    public void setLink1(Link l) {
        this.link1 = l;
    }
    
    private Body body1 = new Body();
    
    public Body getBody1() {
        return body1;
    }
    
    public void setBody1(Body b) {
        this.body1 = b;
    }
    
    private Form form1 = new Form();
    
    public Form getForm1() {
        return form1;
    }
    
    public void setForm1(Form f) {
        this.form1 = f;
    }

    private Label instruccionesEtiqueta = new Label();

    public Label getInstruccionesEtiqueta() {
        return instruccionesEtiqueta;
    }

    public void setInstruccionesEtiqueta(Label l) {
        this.instruccionesEtiqueta = l;
    }

    private DropDown tipoAsientoListaDesplegable = new DropDown();

    public DropDown getTipoAsientoListaDesplegable() {
        return tipoAsientoListaDesplegable;
    }

    public void setTipoAsientoListaDesplegable(DropDown dd) {
        this.tipoAsientoListaDesplegable = dd;
    }

    private SingleSelectOptionsList tipoAsientoListaDesplegableDefaultOptions = new SingleSelectOptionsList();

    public SingleSelectOptionsList getTipoAsientoListaDesplegableDefaultOptions() {
        return tipoAsientoListaDesplegableDefaultOptions;
    }

    public void setTipoAsientoListaDesplegableDefaultOptions(SingleSelectOptionsList ssol) {
        this.tipoAsientoListaDesplegableDefaultOptions = ssol;
    }

    private DropDown claseListaDesplegable = new DropDown();

    public DropDown getClaseListaDesplegable() {
        return claseListaDesplegable;
    }

    public void setClaseListaDesplegable(DropDown dd) {
        this.claseListaDesplegable = dd;
    }

    private SingleSelectOptionsList claseListaDesplegableDefaultOptions = new SingleSelectOptionsList();

    public SingleSelectOptionsList getClaseListaDesplegableDefaultOptions() {
        return claseListaDesplegableDefaultOptions;
    }

    public void setClaseListaDesplegableDefaultOptions(SingleSelectOptionsList ssol) {
        this.claseListaDesplegableDefaultOptions = ssol;
    }

    private Button reservarBoton = new Button();

    public Button getReservarBoton() {
        return reservarBoton;
    }

    public void setReservarBoton(Button b) {
        this.reservarBoton = b;
    }

    private Label exitoEtiqueta = new Label();

    public Label getExitoEtiqueta() {
        return exitoEtiqueta;
    }

    public void setExitoEtiqueta(Label l) {
        this.exitoEtiqueta = l;
    }

    private Label errorEtiqueta = new Label();

    public Label getErrorEtiqueta() {
        return errorEtiqueta;
    }

    public void setErrorEtiqueta(Label l) {
        this.errorEtiqueta = l;
    }

    private ServicioReservacion1Client servicioReservacion1Client1 = new ServicioReservacion1Client();

    public ServicioReservacion1Client getServicioReservacion1Client1() {
        return servicioReservacion1Client1;
    }

    public void setServicioReservacion1Client1(ServicioReservacion1Client src) {
        this.servicioReservacion1Client1 = src;
    }
    
    // </editor-fold>

    /** 
     * <p>Construir una instancia de bean de p�gina.</p>
     */
    public Reservar() {
    }

    /** 
     * <p>Devolver una referencia al bean de datos con �mbito.</p>
     */
    protected RequestBean1 getRequestBean1() {
        return (RequestBean1)getBean("RequestBean1");
    }

    /** 
     * <p>Devolver una referencia al bean de datos con �mbito.</p>
     */
    protected ApplicationBean1 getApplicationBean1() {
        return (ApplicationBean1)getBean("ApplicationBean1");
    }

    /** 
     * <p>Devolver una referencia al bean de datos con �mbito.</p>
     */
    protected SessionBean1 getSessionBean1() {
        return (SessionBean1)getBean("SessionBean1");
    }


    /** 
     * <p>M�todo de devoluci�n de llamada al que se llama cuando se navega hasta esta p�gina,
     * ya sea directamente mediante un URL o de manera indirecta a trav�s de la navegaci�n de p�ginas.
     * Puede personalizar este m�todo para adquirir recursos que se necesitar�n
     * para los controladores de eventos y m�todos del proceso, sin tener en cuenta si esta
     * p�gina realiza procesamiento de devoluci�n de env�os.</p>
     * 
     * <p>Tenga en cuenta que si la petici�n actual es una devoluci�n de env�o, los valores
     * de propiedad de los componentes <strong>no</strong> representan ning�n
     * valor enviado con esta petici�n.  En su lugar, representan los
     * valores de propiedades que se guardaron para esta vista cuando se proces�.</p>
     */
    public void init() {
        // Realizar iniciaciones heredadas de la superclase
        super.init();
        // Realizar inicio de aplicaci�n que debe finalizar
        // *antes* de que se inicien los componentes administrados
        // TODO - Agregar c�digo de inicio propio aqu�

        // <editor-fold defaultstate="collapsed" desc="Inicio de componente administrado por el programa">
        // Iniciar componentes administrados autom�ticamente
        // *Nota* - esta l�gica NO debe modificarse
        try {
            _init();
        } catch (Exception e) {
            log("Page1 Initialization Failure", e);
            throw e instanceof FacesException ? (FacesException) e: new FacesException(e);
        }
        // </editor-fold>
        // Realizar inicio de aplicaci�n que debe finalizar
        // *despu�s* de que se inicien los componentes administrados
        // TODO - Agregar c�digo de inicio propio aqu�

    }

    /** 
     * <p>M�todo de devoluci�n de llamada al que se llama cuando el �rbol de componentes se ha
     * restaurado, pero antes de que se produzca el procesamiento de cualquier evento.  Este m�todo
     * <strong>s�lo</strong> se llamar� en una petici�n de devoluci�n de env�o que
     * est� procesando el env�o de un formulario.  Puede personalizar este m�todo para asignar
     * recursos necesarios para los controladores de eventos.</p>
     */
    public void preprocess() {
    }

    /** 
     * <p>M�todo de devoluci�n de llamada al que se llama justo antes del procesamiento.
     * <strong>S�lo</strong> se llamar� a este m�todo en la p�gina que
     * se procesa, no se llamar�, por ejemplo, en una p�gina que
     * ha procesado una devoluci�n de env�o y a continuaci�n ha navegado hasta otra p�gina.  Puede personalizar
     * este m�todo para asignar recursos necesarios para procesar
     * esta p�gina.</p>
     */
    public void prerender() {
    }

    /** 
     * <p>M�todo de devoluci�n de llamada al que se llama cuando se completa el procesamiento de
     * esta petici�n, si se llam� al m�todo <code>init()</code> (sin tener en cuenta
     * si se trata de la p�gina que se ha procesado o no).  Puede personalizar este
     * m�todo para liberar los recursos adquiridos en los m�todos <code>init()</code>,
     * <code>preprocess()</code> o <code>prerender()</code> (o
     * durante la ejecuci�n de un controlador de eventos).</p>
     */
    public void destroy() {
    }


    // m�todo que invoca al servicio Web cuando el usuario hace clic en el bot�n Reservar
    public String reservarBoton_action() 
    {
      try
      {
         ServicioReservacion1Client cliente = getServicioReservacion1Client1();
         boolean reservado =  
            cliente.reservar( getSessionBean1().getTipoAsiento(), 
               getSessionBean1().getTipoClase() );
         
         if ( reservado )
         {
            instruccionesEtiqueta.setVisible( false );
            tipoAsientoListaDesplegable.setVisible( false );
            claseListaDesplegable.setVisible( false );
            reservarBoton.setVisible( false );
            exitoEtiqueta.setVisible( true );
            errorEtiqueta.setVisible( false );            
         } // fin de if
         else 
         {
            instruccionesEtiqueta.setVisible( true );
            tipoAsientoListaDesplegable.setVisible( true );
            claseListaDesplegable.setVisible( true );
            reservarBoton.setVisible( true );
            exitoEtiqueta.setVisible( false );
            errorEtiqueta.setVisible( true );            
         } // fin de else
      } // fin de try
      catch ( Exception e )
      {
         e.printStackTrace();
      } // fin de catch
        
      return null;
   } // fin del m�todo reservarBoton_action

   // almacena el tipo de asiento seleccionado en el bean de sesi�n
    public void tipoAsientoListaDesplegable_processValueChange(
            ValueChangeEvent event) 
    {
      getSessionBean1().setTipoAsiento( 
         ( String ) tipoAsientoListaDesplegable.getSelected() );       
    } // fin del m�todo tipoAsientoListaDesplegable_processValueChange

    // almacena la clase seleccionada en el bean de sesi�n
    public void claseListaDesplegable_processValueChange(
            ValueChangeEvent event) 
    {
      getSessionBean1().setTipoClase( 
         ( String ) claseListaDesplegable.getSelected() );        
    } //fin del m�todo claseListaDesplegable_processValueChange
} // fin de la clase Reservar

