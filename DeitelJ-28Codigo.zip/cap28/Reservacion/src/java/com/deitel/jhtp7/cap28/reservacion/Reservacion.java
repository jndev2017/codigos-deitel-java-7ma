// Fig. 28.17: Reservacion.java
// Servicio Web de reservaciones de una aerol�nea.
package com.deitel.jhtp7.cap28.reservacion;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService( name = "Reservacion", serviceName = "ServicioReservacion" )
public class Reservacion
{
   private static final String URL_BASEDATOS =
      "jdbc:derby://localhost:1527/Reservacion";
   private static final String USUARIO = "jhtp7";
   private static final String CONTRASENIA = "jhtp7";
   private Connection conexion;
   private Statement instruccion;
   
   // un M�todo Web que puede reservar un asiento
   @WebMethod( operationName = "reservar" )
   public boolean reserve( @WebParam( name = "tipoAsiento" ) String tipoAsiento,
      @WebParam( name = "tipoClase" ) String tipoClase )
   {
      try
      {
         conexion = DriverManager.getConnection( 
            URL_BASEDATOS, USUARIO, CONTRASENIA );
         instruccion = conexion.createStatement();
         ResultSet conjuntoResultados = instruccion.executeQuery(
            "SELECT \"Numero\" FROM \"Asientos\"" +
            "WHERE (\"Reservado\" = 0) AND (\"Ubicacion\" = '" + tipoAsiento + 
            "') AND (\"Clase\" = '" + tipoClase + "')" );
         
         // si el asiento solicitado est� disponible, lo reserva
         if ( conjuntoResultados.next() )
         {
            int asiento = conjuntoResultados.getInt( 1 );
            instruccion.executeUpdate( "UPDATE \"Asientos\" " +
               "SET \"Reservado\" = 1 WHERE \"Numero\" = " + asiento );
            return true;
         } // fin de if
         
         return false;
      } // fin de try
      catch ( SQLException e )
      {
         e.printStackTrace();
         return false;
      } // fin de catch
      catch ( Exception e )
      {
         e.printStackTrace();  
         return false;
      } // fin de catch
      finally
      {
         try
         {
            instruccion.close();
            conexion.close();
         } // fin de try
         catch ( Exception e )
         {
            e.printStackTrace();
            return false;
         } // fin de catch
      } // fin de finally
   } // fin del M�todo Web reservar
} // fin de la clase Reservacion


/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/