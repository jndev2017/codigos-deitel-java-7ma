// Fig. 28.23: ClienteGeneradorEcuacionesJFrame.java
// Programa tutor de matem�ticas que usa servicios Web para generar ecuaciones
package com.deitel.jhtp7.cap28.clientegeneradorecuaciones;

import javax.swing.JOptionPane;

public class ClienteGeneradorEcuacionesJFrame extends javax.swing.JFrame
{
   private ServicioGeneradorEcuaciones servicio; // se utiliza para obtener el proxy
   private GeneradorEcuaciones proxy; // se utiliza para acceder al servicio Web
   private Ecuacion ecuacion; // representa una ecuaci�n
   private int respuesta; // la respuesta del usuario a la pregunta
   private String operacion = "+"; // operaci�n matem�tica +, - o *
   private int dificultad = 1; // 1, 2 o 3 d�gitos en cada n�mero
   
   // constructor sin argumentos
   public ClienteGeneradorEcuacionesJFrame()
   {
      initComponents();
      
      try
      { 
         // crea los objetos para acceder al servicio GeneradorEcuaciones
         servicio = new ServicioGeneradorEcuaciones();
         proxy = servicio.getGeneradorEcuacionesPort();
      } // fin de try
      catch ( Exception ex )
      {
         ex.printStackTrace();
      } // fin de catch
   } // fin de constructores sin argumentos
   
   // El m�todo initComponents se genera autom�ticamente por Netbeans y se llama
   // desde el constructor para inicializar la GUI. Aqu� no se muestra este
   // m�todo para ahorrar espacio. Abra ClienteGeneradorEcuacionesJFrame.java en la 
   // carpeta de este ejemplo para ver el c�digo generado completo (l�neas 37 a 155).
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        operacionJLabel = new javax.swing.JLabel();
        operacionJComboBox = new javax.swing.JComboBox();
        nivelJLabel = new javax.swing.JLabel();
        nivelJComboBox = new javax.swing.JComboBox();
        generarJButton = new javax.swing.JButton();
        preguntaJLabel = new javax.swing.JLabel();
        respuestaJLabel = new javax.swing.JLabel();
        ecuacionJLabel = new javax.swing.JLabel();
        respuestaJTextField = new javax.swing.JTextField();
        comprobarRespuestaJButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Tutor de matem\u00e1ticas");
        operacionJLabel.setText("Elija la operaci\u00f3n:");

        operacionJComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Suma", "Resta", "Multiplicacion" }));
        operacionJComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                operacionJComboBoxItemStateChanged(evt);
            }
        });

        nivelJLabel.setText("Elija el nivel:");

        nivelJComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Numeros de un digito", "Numeros de dos digitos", "Numeros de tres digitos" }));
        nivelJComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                nivelJComboBoxItemStateChanged(evt);
            }
        });

        generarJButton.setText("Generar ecuaci\u00f3n");
        generarJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generarJButtonActionPerformed(evt);
            }
        });

        preguntaJLabel.setText("Pregunta:");

        respuestaJLabel.setText("Respuesta:");

        ecuacionJLabel.setFont(new java.awt.Font("Tahoma", 1, 11));
        ecuacionJLabel.setText(" ");

        comprobarRespuestaJButton.setText("Comprobar respuesta");
        comprobarRespuestaJButton.setEnabled(false);
        comprobarRespuestaJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comprobarRespuestaJButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(comprobarRespuestaJButton, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 226, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(generarJButton, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(operacionJLabel)
                                .addComponent(nivelJLabel))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(operacionJComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(nivelJComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(preguntaJLabel)
                            .addComponent(ecuacionJLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(7, 7, 7)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(respuestaJTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE)
                            .addComponent(respuestaJLabel))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(operacionJLabel)
                    .addComponent(operacionJComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nivelJLabel)
                    .addComponent(nivelJComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(generarJButton)
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(preguntaJLabel)
                    .addComponent(respuestaJLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ecuacionJLabel)
                    .addComponent(respuestaJTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(comprobarRespuestaJButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pack();
    }// </editor-fold>//GEN-END:initComponents

   // obtiene el nivel de dificultad seleccionado por el usuario
   private void nivelJComboBoxItemStateChanged(//GEN-FIRST:event_nivelJComboBoxItemStateChanged
           java.awt.event.ItemEvent evt ) {//GEN-HEADEREND:event_nivelJComboBoxItemStateChanged
      // los �ndices empiezan en 0, por lo que se suma 1 para obtener el nivel de dificultad
      dificultad = nivelJComboBox.getSelectedIndex() + 1;
   }//GEN-LAST:event_nivelJComboBoxItemStateChanged

   // obtiene la operaci�n matem�tica seleccionada por el usuario
   private void operacionJComboBoxItemStateChanged(//GEN-FIRST:event_operacionJComboBoxItemStateChanged
           java.awt.event.ItemEvent evt ) {//GEN-HEADEREND:event_operacionJComboBoxItemStateChanged
      String elemento = ( String ) operacionJComboBox.getSelectedItem();
      
      if ( elemento.equals( "Suma" ) )
         operacion = "+"; // el usuario seleccion� suma
      else if ( elemento.equals( "Resta" ) )
         operacion = "-"; // el usuario seleccion� resta
      else 
         operacion = "*"; // el usuario seleccion� multiplicaci�n
   }//GEN-LAST:event_operacionJComboBoxItemStateChanged

   // comprueba la respuesta del usuario
   private void comprobarRespuestaJButtonActionPerformed(//GEN-FIRST:event_comprobarRespuestaJButtonActionPerformed
           java.awt.event.ActionEvent evt ) {//GEN-HEADEREND:event_comprobarRespuestaJButtonActionPerformed
      if ( respuestaJTextField.getText().equals( "" ) )
      {
         JOptionPane.showMessageDialog( 
            this, "Escriba su respuesta." );
      } // fin de if
      
      int respuestaUsuario = Integer.parseInt( respuestaJTextField.getText() );
      
      if ( respuestaUsuario == respuesta )
      {
         ecuacionJLabel.setText( "" );
         respuestaJTextField.setText( "" );
         comprobarRespuestaJButton.setEnabled( false );
         JOptionPane.showMessageDialog( this, "Correcto! Bien hecho!",
             "Correcto", JOptionPane.PLAIN_MESSAGE );
      } // fin de if
      else
      {
         JOptionPane.showMessageDialog( this, "Incorrecto. Intente de nuevo.",
            "Incorrecto", JOptionPane.PLAIN_MESSAGE );
      } // fin de else
   }//GEN-LAST:event_comprobarRespuestaJButtonActionPerformed

   // genera un nuevo objeto Ecuacion con base en las selecciones del usuario
   private void generarJButtonActionPerformed(//GEN-FIRST:event_generarJButtonActionPerformed
           java.awt.event.ActionEvent evt ) {//GEN-HEADEREND:event_generarJButtonActionPerformed
      try
      {
         ecuacion = proxy.generarEcuacion( operacion, dificultad );
         respuesta = ecuacion.getValorRetorno();
         ecuacionJLabel.setText( ecuacion.getLadoIzq() + " =" );
         comprobarRespuestaJButton.setEnabled( true );
      } // fin de try
      catch ( Exception e )
      {
         e.printStackTrace();
      } // fin de catch      
   }//GEN-LAST:event_generarJButtonActionPerformed
   
   // empieza la ejecuci�n del programa
   public static void main( String args[] )
   {
      java.awt.EventQueue.invokeLater(
         new Runnable()
         {
            public void run()
            {
               new ClienteGeneradorEcuacionesJFrame().setVisible( true );
            } // fin del m�todo run
         } // fin de la clase interna an�nima
      ); // fin de la llamada a java.awt.EventQueue.invokeLater
   } // fin del m�todo main
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton comprobarRespuestaJButton;
    private javax.swing.JLabel ecuacionJLabel;
    private javax.swing.JButton generarJButton;
    private javax.swing.JComboBox nivelJComboBox;
    private javax.swing.JLabel nivelJLabel;
    private javax.swing.JComboBox operacionJComboBox;
    private javax.swing.JLabel operacionJLabel;
    private javax.swing.JLabel preguntaJLabel;
    private javax.swing.JLabel respuestaJLabel;
    private javax.swing.JTextField respuestaJTextField;
    // End of variables declaration//GEN-END:variables
} // fin de la clase ClienteGeneradorEcuacionesJFrame


/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/


