// Fig. 28.11: UsoEnteroEnormeJFrame.java
// Aplicaci�n de escritorio cliente para el servicio Web EnteroEnorme.
package com.deitel.jhtp7.cap28.clienteenteroenorme;

// importa las clases para acceder al proxy del servicio Web EnteroEnorme
import com.deitel.jhtp7.cap28.clienteenteroenorme.EnteroEnorme;
import com.deitel.jhtp7.cap28.clienteenteroenorme.ServicioEnteroEnorme;

import javax.swing.JOptionPane; // se utiliza para mostrar errores al usuario

public class UsoEnteroEnormeJFrame extends javax.swing.JFrame
{
   private ServicioEnteroEnorme servicioEnteroEnorme; // se usa para obtener el proxy
   private EnteroEnorme proxyEnteroEnorme; // se usa para acceder al servicio Web
   
   // constructor sin argumentos
   public UsoEnteroEnormeJFrame()
   {
      initComponents();
      
      try
      { 
         // crea los objetos para acceder al servicio Web EnteroEnorme
         servicioEnteroEnorme = new ServicioEnteroEnorme();
         proxyEnteroEnorme = servicioEnteroEnorme.getEnteroEnormePort();
      }
      catch ( Exception excepcion )
      {
         excepcion.printStackTrace();
      }        
   } // fin del constructor de UsoEnteroEnormeJFrame
   
   // El m�todo initComponents se genera autom�ticamente por Netbeans y se llama
   // desde el constructor para inicializar la GUI. No mostraremos aqu� este m�todo
   // para ahorrar espacio. Abra UsoEnteroEnormeJFrame.java en la carpeta 
   // de este ejemplo para ver el c�digo generado completo. 
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        indicacionesJLabel = new javax.swing.JLabel();
        primeroJTextField = new javax.swing.JTextField();
        segundoJTextField = new javax.swing.JTextField();
        sumarJButton = new javax.swing.JButton();
        restarJButton = new javax.swing.JButton();
        mayorJButton = new javax.swing.JButton();
        menorJButton = new javax.swing.JButton();
        igualJButton = new javax.swing.JButton();
        resultadosJScrollPane = new javax.swing.JScrollPane();
        resultadosJTextArea = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Uso del servicio Web EnteroEnorme");
        indicacionesJLabel.setText("Escriba dos enteros positivos, de hasta 100 d\u00edgitos cada uno:");

        sumarJButton.setText("Sumar");
        sumarJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sumarJButtonActionPerformed(evt);
            }
        });

        restarJButton.setText("Restar");
        restarJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                restarJButtonActionPerformed(evt);
            }
        });

        mayorJButton.setText("Mayor que");
        mayorJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mayorJButtonActionPerformed(evt);
            }
        });

        menorJButton.setText("Menor que");
        menorJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menorJButtonActionPerformed(evt);
            }
        });

        igualJButton.setText("Igual a");
        igualJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                igualJButtonActionPerformed(evt);
            }
        });

        resultadosJScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        resultadosJTextArea.setColumns(20);
        resultadosJTextArea.setRows(5);
        resultadosJScrollPane.setViewportView(resultadosJTextArea);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, resultadosJScrollPane, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 744, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, primeroJTextField, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 744, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, indicacionesJLabel)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, segundoJTextField, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 744, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                        .add(sumarJButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 144, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(restarJButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 105, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(mayorJButton)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(menorJButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 119, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(igualJButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 109, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        layout.linkSize(new java.awt.Component[] {igualJButton, mayorJButton, menorJButton, restarJButton, sumarJButton}, org.jdesktop.layout.GroupLayout.HORIZONTAL);

        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(indicacionesJLabel)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(primeroJTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(segundoJTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(restarJButton)
                    .add(mayorJButton)
                    .add(menorJButton)
                    .add(igualJButton)
                    .add(sumarJButton))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(resultadosJScrollPane, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 50, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pack();
    }// </editor-fold>//GEN-END:initComponents

   // invoca al m�todo sumar del servicio Web EnteroEnorme para sumar objetos EnteroEnorme
   private void sumarJButtonActionPerformed(
      java.awt.event.ActionEvent evt ) 
   {
      String primerNumero = primeroJTextField.getText();
      String segundoNumero = segundoJTextField.getText();

      if ( esValido( primerNumero ) && esValido( segundoNumero ) )
      {
         try
         {
            resultadosJTextArea.setText( 
               proxyEnteroEnorme.sumar( primerNumero, segundoNumero ) );
         } // fin de try
         catch ( Exception e )
         {
            JOptionPane.showMessageDialog( this, e.toString(), 
               "Error en el metodo Sumar", JOptionPane.ERROR_MESSAGE );
            e.printStackTrace();
         } // fin de catch
      } // fin de if
   } // fin del m�todo sumarJButtonActionPerformed

   // invoca al m�todo restar del servicio Web EnteroEnorme para restar el 
   // segundo EnteroEnorme del primero
   private void restarJButtonActionPerformed(                                                 
      java.awt.event.ActionEvent evt )
   {                                                    
      String primerNumero = primeroJTextField.getText();
      String segundoNumero = segundoJTextField.getText();

      if ( esValido( primerNumero ) && esValido( segundoNumero ) )
      {
         try
         {
            resultadosJTextArea.setText( 
               proxyEnteroEnorme.restar( primerNumero, segundoNumero ) );
         } // fin de try
         catch ( Exception e )
         {
            JOptionPane.showMessageDialog( this, e.toString(), 
               "Error en el metodo Restar", JOptionPane.ERROR_MESSAGE );
            e.printStackTrace();
         } // fin de catch
      } // fin de if
   } // fin del m�todo restarJButtonActionPerformed                                               

   // invoca al m�todo mayor del servicio Web EnteroEnorme para determinar si
   // el primer EnteroEnorme es mayor que el segundo
   private void mayorJButtonActionPerformed(
      java.awt.event.ActionEvent evt )
   {
      String primerNumero = primeroJTextField.getText();
      String segundoNumero = segundoJTextField.getText();

      if ( esValido( primerNumero ) && esValido( segundoNumero ) )
      {
         try
         {
            boolean result = 
               proxyEnteroEnorme.mayor( primerNumero, segundoNumero );
            resultadosJTextArea.setText( String.format( "%s %s %s %s", 
               primerNumero, ( result ? "es" : "no es" ), "mayor que", 
               segundoNumero ) );
         } // fin de try 
         catch ( Exception e )
         {
            JOptionPane.showMessageDialog( this, e.toString(), 
               "Error en metodo Mayor", JOptionPane.ERROR_MESSAGE );
            e.printStackTrace();
         } // fin de catch
      } // fin de if
   } // fin del m�todo mayorJButtonActionPerformed

   // invoca al m�todo menor del servicio Web EnteroEnorme para determinar
   // si el primer EnteroEnorme es menor que el segundo
   private void menorJButtonActionPerformed(
      java.awt.event.ActionEvent evt ) 
   {
      String primerNumero = primeroJTextField.getText();
      String segundoNumero = segundoJTextField.getText();

      if ( esValido( primerNumero ) && esValido( segundoNumero ) )
      {
         try
         {
            boolean resultado = 
               proxyEnteroEnorme.menor( primerNumero, segundoNumero );
            resultadosJTextArea.setText( String.format( "%s %s %s %s", 
               primerNumero, ( resultado ? "es" : "no es" ), "menor que", 
               segundoNumero ) );
         } // fin de try 
         catch ( Exception e )
         {
            JOptionPane.showMessageDialog( this, e.toString(), 
               "Error en metodo Menor", JOptionPane.ERROR_MESSAGE );
            e.printStackTrace();
         } // fin de catch
      } // fin de if
   }// fin del m�todo menorJButtonActionPerformed

   // invoca al m�todo igual del servicio Web EnteroEnorme para determinar si
   // el primer EnteroEnorme es igual al segundo
   private void igualJButtonActionPerformed(
      java.awt.event.ActionEvent evt ) 
   {
      String primerNumero = primeroJTextField.getText();
      String segundoNumero = segundoJTextField.getText();

      if ( esValido( primerNumero ) && esValido( segundoNumero ) )
      {
         try
         {
            boolean resultado = 
               proxyEnteroEnorme.igual( primerNumero, segundoNumero );
            resultadosJTextArea.setText( String.format( "%s %s %s %s", 
               primerNumero, ( resultado ? "es" : "no es" ), "igual a", 
               segundoNumero ) );
         } // fin de try 
         catch ( Exception e )
         {
            JOptionPane.showMessageDialog( this, e.toString(), 
               "Error en el metodo Igual", JOptionPane.ERROR_MESSAGE );
            e.printStackTrace();
         } // fin de catch
      } // fin de if
   } // fin del m�todo igualJButtonActionPerformed

   // comprueba el tama�o de un objeto String para asegurar que no sea demasiado grande
   // como para usarlo como un EnteroEnorme; asegura que s�lo haya d�gitos en el String
   private boolean esValido( String numero )
   {
      // comprueba la longitud del objeto String
      if ( numero.length() > 100 )
      {
         JOptionPane.showMessageDialog( this,
            "Los EnterosEnormes deben ser <= 100 digitos.", "Desbordamiento de EnteroEnorme", 
            JOptionPane.ERROR_MESSAGE );
         return false;
      } // fin de if
      
      // busca caracteres que no sean d�gitos en el objeto String
      for ( char c : numero.toCharArray() )
      {
         if ( !Character.isDigit( c ) )
         {
            JOptionPane.showMessageDialog( this,
               "Hay caracteres que no son digitos en el objeto String", 
               "EnteroEnorme contiene caracteres que no son digitos", 
               JOptionPane.ERROR_MESSAGE );
            return false;         
         } // fin de if  
      } // fin de for
   
      return true; // el n�mero se puede usar como un EnteroEnorme
   } // fin del m�todo de validaci�n
   
   // el m�todo main empieza la ejecuci�n
   public static void main( String args[] )
   {
      java.awt.EventQueue.invokeLater( 
         new Runnable()
         {
            public void run()
            {
               new UsoEnteroEnormeJFrame().setVisible( true );
            } // fin del m�todo run
         } // fin de la clase interna an�nima 
      ); // fin de la llamada a java.awt.EventQueue.invokeLater
   } // fin del m�todo main
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton igualJButton;
    private javax.swing.JLabel indicacionesJLabel;
    private javax.swing.JButton mayorJButton;
    private javax.swing.JButton menorJButton;
    private javax.swing.JTextField primeroJTextField;
    private javax.swing.JButton restarJButton;
    private javax.swing.JScrollPane resultadosJScrollPane;
    private javax.swing.JTextArea resultadosJTextArea;
    private javax.swing.JTextField segundoJTextField;
    private javax.swing.JButton sumarJButton;
    // End of variables declaration//GEN-END:variables
} // fin de la clase UsoEnteroEnormeJFrame



/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
