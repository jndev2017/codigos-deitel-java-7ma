// Fig. 28.2: EnteroEnorme.java
// Servicio Web EnteroEnorme que realiza operaciones con enteros grandes.
package com.deitel.jhtp7.cap28.enteroenorme;

import javax.jws.WebService; // el programa usa la anotaci�n @WebService
import javax.jws.WebMethod; // el programa usa la anotaci�n @WebMethod
import javax.jws.WebParam; // el programa usa la anotaci�n @WebParam

@WebService( // anota la clase como un servicio Web
   name = "EnteroEnorme", // establece el nombre de la clase
   serviceName = "ServicioEnteroEnorme" ) // establece el nombre del servicio
public class EnteroEnorme
{
   private final static int MAXIMO = 100; // m�ximo n�mero de d�gitos
   public int[] numero = new int[ MAXIMO ]; // almacena el entero enorme
  
   // devuelve una representaci�n String de un EnteroEnorme
   public String toString()
   {
      String valor = "";
      
      // convierte EnteroEnorme en un objeto String
      for ( int digito : numero )
         valor = digito + valor; // coloca el siguente digito al principio del valor
      
      // localiza la posici�n del primer d�gito distinto de cero
      int longitud = valor.length();
      int posicion = -1;
      
      for ( int i = 0; i < longitud; i++ ) 
      {
         if ( valor.charAt( i ) != '0' ) 
         {
            posicion = i; // primer d�gito distinto de cero
            break;
         }
      } // fin de for
         
      return ( posicion != -1 ? valor.substring( posicion ) : "0" );
   } // fin del m�todo toString
   
   // crea un objeto EnteroEnorme a partir de un objeto String
   public static EnteroEnorme analizarEnteroEnorme( String s )
   {
      EnteroEnorme temp = new EnteroEnorme();
      int tamanio = s.length();
      
      for ( int i = 0; i < tamanio; i++ )
         temp.numero[ i ] = s.charAt( tamanio - i - 1 ) - '0';
      
      return temp;
   } // fin del m�todo analizarEnteroEnorme
   
   // M�todo Web que suma enteros enormes representados por argumentos String
   @WebMethod( operationName = "sumar" ) 
   public String sumar( @WebParam( name = "primero" ) String primero,
      @WebParam( name = "segundo" ) String segundo ) 
   {
      int acarreo = 0; // el valor que se va a acarrear
      EnteroEnorme operando1 = EnteroEnorme.analizarEnteroEnorme( primero );
      EnteroEnorme operando2 = EnteroEnorme.analizarEnteroEnorme( segundo );
      EnteroEnorme resultado = new EnteroEnorme(); // almacena el resultado de la suma
      
      // realiza la suma en cada d�gito
      for ( int i = 0; i < MAXIMO; i++ )
      {
         // suma los d�gitos correspondientes en cada n�mero y el valor acarreado;
         // almacena el resultado en la columna correspondiente del resultado EnteroEnorme
         resultado.numero[ i ] = 
            ( operando1.numero[ i ] + operando2.numero[ i ] + acarreo ) % 10;
         
         // establece el acarreo para la siguiente columna
         acarreo = 
            ( operando1.numero[ i ] + operando2.numero[ i ] + acarreo ) / 10;
      } // fin de for
      
      return resultado.toString();
   } // fin del M�todo Web sumar
   
   // M�todo Web que resta los enteros representados por argumentos String
   @WebMethod( operationName = "restar" ) 
   public String restar( @WebParam( name = "primero" ) String primero,
      @WebParam( name = "segundo" ) String segundo )
   {
      EnteroEnorme operando1 = EnteroEnorme.analizarEnteroEnorme( primero );
      EnteroEnorme operando2 = EnteroEnorme.analizarEnteroEnorme( segundo );
      EnteroEnorme resultado = new EnteroEnorme(); // almacena la diferencia
      
      // resta el d�gito inferior del d�gito superior
      for ( int i = 0; i < MAXIMO; i++ )
      {
         // si el d�gito en operando1 es menor que el correspondiente 
         // d�gito en operando2, pide prestado al siguiente d�gito
         if ( operando1.numero[ i ] < operando2.numero[ i ] )
            operando1.pedirprestado( i );
         
         // resta los d�gitos
         resultado.numero[ i ] = operando1.numero[ i ] - operando2.numero[ i ];
      } // fin de for
      
      return resultado.toString();
   } // fin del M�todo Web restar
   
   // pide prestado 1 del siguiente d�gito
   private void pedirprestado( int lugar )
   {
      if ( lugar >= MAXIMO )
         throw new IndexOutOfBoundsException();
      else if ( numero[ lugar + 1 ] == 0 ) // si el siguiente d�gito es cero
         pedirprestado( lugar + 1 ); // pide prestado del siguiente d�gito
      
      numero[ lugar ] += 10; // suma 10 al d�gito que prest�
      --numero[ lugar + 1 ]; // resta uno al d�gito de la izquierda
   } // fin del m�todo pedirprestado
   
   // M�todo Web que devuelve true si el primer entero es mayor que el segundo
   @WebMethod( operationName = "mayor" ) 
   public boolean mayor( @WebParam( name = "primero" ) String primero,
      @WebParam( name = "segundo" ) String segundo )
   {
      try // trata de restar el primer n�mero del segundo
      {
         String diferencia = restar( primero, segundo );      
         return !diferencia.matches( "^[0]+$" ); 
      } // fin de try
      catch ( IndexOutOfBoundsException e ) // primero es menor que segundo
      {
         return false;
      } // fin de catch
   } // fin del M�todo Web mayor
   
   // M�todo Web que devuelve true si el primer entero es menor que el segundo
   @WebMethod( operationName = "menor" ) 
   public boolean menor( @WebParam( name = "primero" ) String primero,
      @WebParam( name = "segundo" ) String segundo )
   {
      return mayor( segundo, primero );
   } // fin del M�todo Web menor
   
   // M�todo Web que devuelve true si el primer entero es igual al segundo
   @WebMethod( operationName = "igual" ) 
   public boolean igual( @WebParam( name = "primero" ) String primero,
      @WebParam( name = "segundo" ) String segundo )
   {
      return !( mayor( primero, segundo ) || menor( primero, segundo ) ); 
   } // fin del M�todo Web igual
} // fin de la clase EnteroEnorme


/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/