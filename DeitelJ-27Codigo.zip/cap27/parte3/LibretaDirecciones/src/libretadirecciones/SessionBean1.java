// Fig. 27.7: SessionBean1.java
// Bean de sesi�n que inicializa el origen de datos para la
// base de datos LibretaDirecciones.
package libretadirecciones;

import com.sun.rave.web.ui.appbase.AbstractSessionBean;
import javax.faces.FacesException;
import com.sun.sql.rowset.CachedRowSetXImpl;

public class SessionBean1 extends AbstractSessionBean 
{
    private int __placeholder;
    
    private void _init() throws Exception 
    {
        addressesRowSet.setDataSourceName(
                "java:comp/env/jdbc/LibretaDirecciones");
        addressesRowSet.setCommand(
                "SELECT ALL JHTP7.ADDRESSES.FIRSTNAME,\nJHTP7.ADDRESSES.LASTNAME,\nJHTP7.ADDRESSES.STREET,\nJHTP7.ADDRESSES.CITY,\nJHTP7.ADDRESSES.STATE,\nJHTP7.ADDRESSES.ZIP\nFROM JHTP7.ADDRESSES\nORDER BY JHTP7.ADDRESSES.LASTNAME ASC,\nJHTP7.ADDRESSES.FIRSTNAME ASC "
                ) ;
                addressesRowSet.setTableName("ADDRESSES");
        busquedaDirecciones.setDataSourceName("java:comp/env/jdbc/LibretaDirecciones");
        busquedaDirecciones.setCommand("SELECT ALL JHTP7.ADDRESSES.FIRSTNAME, \n                    JHTP7.ADDRESSES.LASTNAME, \n                    JHTP7.ADDRESSES.STREET, \n                    JHTP7.ADDRESSES.CITY, \n                    JHTP7.ADDRESSES.STATE, \n                    JHTP7.ADDRESSES.ZIP \nFROM JHTP7.ADDRESSES\nWHERE JHTP7.ADDRESSES.FIRSTNAME = ?\n          AND JHTP7.ADDRESSES.LASTNAME = ? ");
        busquedaDirecciones.setTableName("ADDRESSES");
    } // fin del m�todo _init

    private CachedRowSetXImpl addressesRowSet = new CachedRowSetXImpl();

    public CachedRowSetXImpl getAddressesRowSet() 
    {
        return addressesRowSet;
    }

    public void setAddressesRowSet(CachedRowSetXImpl crsxi) 
    {
        this.addressesRowSet = crsxi;
    }

    private CachedRowSetXImpl busquedaDirecciones = new CachedRowSetXImpl();

    public CachedRowSetXImpl getBusquedaDirecciones() {
        return busquedaDirecciones;
    }

    public void setBusquedaDirecciones(CachedRowSetXImpl crsxi) {
        this.busquedaDirecciones = crsxi;
    }
    
    /** 
     * <p>Construir una instancia de bean de datos de la sesi�n.</p>
     */
    public SessionBean1() {
    }

    /** 
     * <p>Devolver una referencia al bean de datos con �mbito.</p>
     */
    protected ApplicationBean1 getApplicationBean1() {
        return (ApplicationBean1)getBean("ApplicationBean1");
    }


    /** 
     * <p>Se llama a este m�todo al agregar este bean al
     * �mbito de la sesi�n.  Normalmente, esto ocurre como resultado de la evaluaci�n
     * de una expresi�n de enlace de valores o de m�todos, que utiliza la
     * funci�n de bean administrado para crear una instancia de este bean y almacenarla en el
     * �mbito de la sesi�n.</p>
     * 
     * <p>Puede personalizar este m�todo para inicializar y almacenar en cach� los valores
     * o recursos necesarios para el ciclo de duraci�n de una
     * sesi�n de usuario en particular.</p>
     */
    public void init() {
        // Realizar iniciaciones heredadas de la superclase
        super.init();
        // Realizar inicio de aplicaci�n que debe finalizar
        // *antes* de que se inicien los componentes administrados
        // TODO - Agregar c�digo de inicio propio aqu�

        // <editor-fold defaultstate="collapsed" desc="Inicio de componente administrado por el programa">
        // Iniciar componentes administrados autom�ticamente
        // *Nota* - esta l�gica NO debe modificarse
        try {
            _init();
        } catch (Exception e) {
            log("SessionBean1 Initialization Failure", e);
            throw e instanceof FacesException ? (FacesException) e: new FacesException(e);
        }
        // </editor-fold>
        // Realizar inicio de aplicaci�n que debe finalizar
        // *despu�s* de que se inicien los componentes administrados
        // TODO - Agregar c�digo de inicio propio aqu�

    }

    /** 
     * <p>Se llama a este m�todo cuando la sesi�n que lo contiene est� apunto de
     * configurarse en modo pasivo.  Normalmente, esto ocurre en un contenedor de servlet distribuido
     * cuando la sesi�n est� apunto de transferirse a otra
     * instancia de contenedor, despu�s de la cual se llamar� al m�todo <code>activate()</code>
     * para indicar que la transferencia se ha completado.</p>
     * 
     * <p>Puede personalizar este m�todo para liberar las referencias a datos
     * o recursos de sesi�n que no pueden serializarse con la propia sesi�n.</p>
     */
    public void passivate() {
    }

    /** 
     * <p>Se llama a este m�todo cuando la sesi�n que lo contiene se
     * reactiva.</p>
     * 
     * <p>Puede personalizar este m�todo para volver a adquirir las referencias a
     * datos o recursos de la sesi�n que no pudieron serializarse con la
     * propia sesi�n.</p>
     */
    public void activate() {
    }

    /** 
     * <p>Se llama a este m�todo al eliminar este bean del
     * �mbito de la sesi�n.  Normalmente, esto ocurre cuando
     * se supera el tiempo de espera de la sesi�n o la aplicaci�n la finaliza.</p>
     * 
     * <p>Puede personalizar este m�todo para limpiar los recursos asignados
     * durante la ejecuci�n del m�todo <code>init()</code> o
     * m�s adelante durante el ciclo de vida de la aplicaci�n.</p>
     */
    public void destroy() {
    }
}
