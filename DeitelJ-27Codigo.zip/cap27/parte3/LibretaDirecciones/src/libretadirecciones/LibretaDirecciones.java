// Fig. 27.16: LibretaDirecciones.java
// Bean de p�gina para agregar un contacto a la liberta de direcciones.
package libretadirecciones;

import com.sun.data.provider.RowKey;
import com.sun.rave.web.ui.appbase.AbstractPageBean;
import com.sun.rave.web.ui.component.Body;
import com.sun.rave.web.ui.component.Form;
import com.sun.rave.web.ui.component.Head;
import com.sun.rave.web.ui.component.Html;
import com.sun.rave.web.ui.component.Link;
import com.sun.rave.web.ui.component.Page;
import javax.faces.FacesException;
import com.sun.rave.web.ui.component.StaticText;
import com.sun.rave.web.ui.component.TextField;
import com.sun.rave.web.ui.component.Label;
import com.sun.rave.web.ui.component.Button;
import com.sun.rave.web.ui.component.Table;
import com.sun.rave.web.ui.component.TableRowGroup;
import com.sun.rave.web.ui.component.TableColumn;
import com.sun.data.provider.impl.CachedRowSetDataProvider;
import com.sun.rave.web.ui.component.MessageGroup;
import com.sun.j2ee.blueprints.ui.autocomplete.AutoCompleteComponent;
import com.sun.j2ee.blueprints.ui.autocomplete.CompletionResult;
import javax.faces.context.FacesContext;
import com.sun.j2ee.blueprints.ui.mapviewer.MapComponent;
import com.sun.j2ee.blueprints.ui.mapviewer.MapPoint;
import com.sun.j2ee.blueprints.ui.geocoder.GeoCoder;
import com.sun.j2ee.blueprints.ui.geocoder.GeoPoint;
import com.sun.j2ee.blueprints.ui.mapviewer.MapMarker;

public class LibretaDirecciones extends AbstractPageBean 
{
    private int __placeholder;
    
    private void _init() throws Exception 
    {
        addressesDataProvider.setCachedRowSet(
                (javax.sql.rowset.CachedRowSet)
                    getValue("#{SessionBean1.addressesRowSet}"));
        direccionesTabla.setInternalVirtualForm(true);
        busquedaDireccionesDataProvider.setCachedRowSet(
                (javax.sql.rowset.CachedRowSet)
                    getValue("#{SessionBean1.busquedaDirecciones}"));
        mapViewer.setRendered(false);
    } // fin del m�todo _init

    private Page page1 = new Page();
    
    public Page getPage1() 
    {
        return page1;
    }
    
    public void setPage1(Page p) 
    {
        this.page1 = p;
    }
    
    private Html html1 = new Html();
    
    public Html getHtml1() 
    {
        return html1;
    }
    
    public void setHtml1(Html h) 
    {
        this.html1 = h;
    }
    
    private Head head1 = new Head();
    
    public Head getHead1() 
    {
        return head1;
    }
    
    public void setHead1(Head h) 
    {
        this.head1 = h;
    }
    
    private Link link1 = new Link();
    
    public Link getLink1() 
    {
        return link1;
    }
    
    public void setLink1(Link l) 
    {
        this.link1 = l;
    }
    
    private Body body1 = new Body();
    
    public Body getBody1() 
    {
        return body1;
    }
    
    public void setBody1(Body b) 
    {
        this.body1 = b;
    }
    
    private Form form1 = new Form();
    
    public Form getForm1() 
    {
        return form1;
    }
    
    public void setForm1(Form f) 
    {
        this.form1 = f;
    }

    private StaticText staticText1 = new StaticText();

    public StaticText getStaticText1() 
    {
        return staticText1;
    }

    public void setStaticText1(StaticText st) 
    {
        this.staticText1 = st;
    }

    private TextField pnombreCampoTexto = new TextField();

    public TextField getPnombreCampoTexto() 
    {
        return pnombreCampoTexto;
    }

    public void setPnombreCampoTexto(TextField tf) 
    {
        this.pnombreCampoTexto = tf;
    }

    private TextField apaternoCampoTexto = new TextField();

    public TextField getApaternoCampoTexto() 
    {
        return apaternoCampoTexto;
    }

    public void setApaternoCampoTexto(TextField tf) 
    {
        this.apaternoCampoTexto = tf;
    }

    private TextField calleCampoTexto = new TextField();

    public TextField getCalleCampoTexto() 
    {
        return calleCampoTexto;
    }

    public void setCalleCampoTexto(TextField tf) 
    {
        this.calleCampoTexto = tf;
    }

    private TextField ciudadCampoTexto = new TextField();

    public TextField getCiudadCampoTexto() 
    {
        return ciudadCampoTexto;
    }

    public void setCiudadCampoTexto(TextField tf) 
    {
        this.ciudadCampoTexto = tf;
    }

    private TextField estadoCampoTexto = new TextField();

    public TextField getEstadoCampoTexto() 
    {
        return estadoCampoTexto;
    }

    public void setEstadoCampoTexto(TextField tf) 
    {
        this.estadoCampoTexto = tf;
    }

    private TextField cpCampoTexto = new TextField();

    public TextField getCpCampoTexto() 
    {
        return cpCampoTexto;
    }

    public void setCpCampoTexto(TextField tf) 
    {
        this.cpCampoTexto = tf;
    }

    private Label pnombreEtiqueta = new Label();

    public Label getPnombreEtiqueta() 
    {
        return pnombreEtiqueta;
    }

    public void setPnombreEtiqueta(Label l) 
    {
        this.pnombreEtiqueta = l;
    }

    private Label apaternoEtiqueta = new Label();

    public Label getApaternoEtiqueta() 
    {
        return apaternoEtiqueta;
    }

    public void setApaternoEtiqueta(Label l) 
    {
        this.apaternoEtiqueta = l;
    }

    private Label calleEtiqueta = new Label();

    public Label getCalleEtiqueta() 
    {
        return calleEtiqueta;
    }

    public void setCalleEtiqueta(Label l) 
    {
        this.calleEtiqueta = l;
    }

    private Label ciudadEtiqueta = new Label();

    public Label getCiudadEtiqueta() 
    {
        return ciudadEtiqueta;
    }

    public void setCiudadEtiqueta(Label l) 
    {
        this.ciudadEtiqueta = l;
    }

    private Label estadoEtiqueta = new Label();

    public Label getEstadoEtiqueta() 
    {
        return estadoEtiqueta;
    }

    public void setEstadoEtiqueta(Label l) 
    {
        this.estadoEtiqueta = l;
    }

    private Label cpEtiqueta = new Label();

    public Label getCpEtiqueta() 
    {
        return cpEtiqueta;
    }

    public void setCpEtiqueta(Label l) 
    {
        this.cpEtiqueta = l;
    }

    private Button enviarBoton = new Button();

    public Button getEnviarBoton() 
    {
        return enviarBoton;
    }

    public void setEnviarBoton(Button b) 
    {
        this.enviarBoton = b;
    }

    private Button borrarBoton = new Button();

    public Button getBorrarBoton() 
    {
        return borrarBoton;
    }

    public void setBorrarBoton(Button b) 
    {
        this.borrarBoton = b;
    }

    private Table direccionesTabla = new Table();

    public Table getDireccionesTabla() 
    {
        return direccionesTabla;
    }

    public void setDireccionesTabla(Table t) 
    {
        this.direccionesTabla = t;
    }

    private TableRowGroup tableRowGroup1 = new TableRowGroup();

    public TableRowGroup getTableRowGroup1() 
    {
        return tableRowGroup1;
    }

    public void setTableRowGroup1(TableRowGroup trg) 
    {
        this.tableRowGroup1 = trg;
    }

    private CachedRowSetDataProvider addressesDataProvider = 
            new CachedRowSetDataProvider();

    public CachedRowSetDataProvider getAddressesDataProvider() 
    {
        return addressesDataProvider;
    }

    public void setAddressesDataProvider(CachedRowSetDataProvider crsdp) 
    {
        this.addressesDataProvider = crsdp;
    }

    private TableColumn pnombreColumna = new TableColumn();

    public TableColumn getPnombreColumna() 
    {
        return pnombreColumna;
    }

    public void setPnombreColumna(TableColumn tc) 
    {
        this.pnombreColumna = tc;
    }

    private StaticText staticText2 = new StaticText();

    public StaticText getStaticText2() 
    {
        return staticText2;
    }

    public void setStaticText2(StaticText st) 
    {
        this.staticText2 = st;
    }

    private TableColumn apaternoColumna = new TableColumn();

    public TableColumn getApaternoColumna() 
    {
        return apaternoColumna;
    }

    public void setApaternoColumna(TableColumn tc) 
    {
        this.apaternoColumna = tc;
    }

    private StaticText staticText3 = new StaticText();

    public StaticText getStaticText3() 
    {
        return staticText3;
    }

    public void setStaticText3(StaticText st) 
    {
        this.staticText3 = st;
    }

    private TableColumn calleColumna = new TableColumn();

    public TableColumn getCalleColumna() 
    {
        return calleColumna;
    }

    public void setCalleColumna(TableColumn tc) 
    {
        this.calleColumna = tc;
    }

    private StaticText staticText4 = new StaticText();

    public StaticText getStaticText4() 
    {
        return staticText4;
    }

    public void setStaticText4(StaticText st) 
    {
        this.staticText4 = st;
    }

    private TableColumn ciudadColumna = new TableColumn();

    public TableColumn getCiudadColumna() 
    {
        return ciudadColumna;
    }

    public void setCiudadColumna(TableColumn tc) 
    {
        this.ciudadColumna = tc;
    }

    private StaticText staticText5 = new StaticText();

    public StaticText getStaticText5() 
    {
        return staticText5;
    }

    public void setStaticText5(StaticText st) 
    {
        this.staticText5 = st;
    }

    private TableColumn estadoColumna = new TableColumn();

    public TableColumn getEstadoColumna() 
    {
        return estadoColumna;
    }

    public void setEstadoColumna(TableColumn tc) 
    {
        this.estadoColumna = tc;
    }

    private StaticText staticText6 = new StaticText();

    public StaticText getStaticText6() 
    {
        return staticText6;
    }

    public void setStaticText6(StaticText st) 
    {
        this.staticText6 = st;
    }

    private TableColumn cpColumna = new TableColumn();

    public TableColumn getCpColumna() 
    {
        return cpColumna;
    }

    public void setCpColumna(TableColumn tc) 
    {
        this.cpColumna = tc;
    }

    private StaticText staticText7 = new StaticText();

    public StaticText getStaticText7() 
    {
        return staticText7;
    }

    public void setStaticText7(StaticText st) 
    {
        this.staticText7 = st;
    }

    private MessageGroup messageGroup1 = new MessageGroup();

    public MessageGroup getMessageGroup1() 
    {
        return messageGroup1;
    }

    public void setMessageGroup1(MessageGroup mg) 
    {
        this.messageGroup1 = mg;
    }

    private StaticText encabezadoBusqueda = new StaticText();

    public StaticText getEncabezadoBusqueda() 
    {
        return encabezadoBusqueda;
    }

    public void setEncabezadoBusqueda(StaticText st) 
    {
        this.encabezadoBusqueda = st;
    }

    private AutoCompleteComponent nombreAutoComplete = 
            new AutoCompleteComponent();

    public AutoCompleteComponent getNombreAutoComplete() 
    {
        return nombreAutoComplete;
    }

    public void setNombreAutoComplete(AutoCompleteComponent acc) 
    {
        this.nombreAutoComplete = acc;
    }

    private Label buscarNombreEtiqueta = new Label();

    public Label getBuscarNombreEtiqueta() 
    {
        return buscarNombreEtiqueta;
    }

    public void setBuscarNombreEtiqueta(Label l) 
    {
        this.buscarNombreEtiqueta = l;
    }

    private Button buscarBoton = new Button();

    public Button getBuscarBoton() 
    {
        return buscarBoton;
    }

    public void setBuscarBoton(Button b) 
    {
        this.buscarBoton = b;
    }

    private MapComponent mapViewer = new MapComponent();

    public MapComponent getMapViewer() 
    {
        return mapViewer;
    }

    public void setMapViewer(MapComponent mc) 
    {
        this.mapViewer = mc;
    }

    private MapPoint mapViewer_center = new MapPoint();

    public MapPoint getMapViewer_center() 
    {
        return mapViewer_center;
    }

    public void setMapViewer_center(MapPoint mp) 
    {
        this.mapViewer_center = mp;
    }

    private MapMarker mapMarker = new MapMarker();

    public MapMarker getMapMarker() 
    {
        return mapMarker;
    }

    public void setMapMarker(MapMarker mm) 
    {
        this.mapMarker = mm;
    }

    private GeoCoder geoCoder = new GeoCoder();

    public GeoCoder getGeoCoder() 
    {
        return geoCoder;
    }

    public void setGeoCoder(GeoCoder gc) 
    {
        this.geoCoder = gc;
    }

    private CachedRowSetDataProvider busquedaDireccionesDataProvider = 
            new CachedRowSetDataProvider();

    public CachedRowSetDataProvider getBusquedaDireccionesDataProvider() 
    {
        return busquedaDireccionesDataProvider;
    }

    public void setBusquedaDireccionesDataProvider(
            CachedRowSetDataProvider crsdp) 
    {
        this.busquedaDireccionesDataProvider = crsdp;
    }
    
    public LibretaDirecciones() {
    }

    protected RequestBean1 getRequestBean1() 
    {
        return (RequestBean1)getBean("RequestBean1");
    }


    protected ApplicationBean1 getApplicationBean1() 
    {
        return (ApplicationBean1)getBean("ApplicationBean1");
    }


    protected SessionBean1 getSessionBean1() 
    {
        return (SessionBean1)getBean("SessionBean1");
    }


    public void init() 
    {
        // Realizar iniciaciones heredadas de la superclase
        super.init();
        try 
        {
            _init();
        } catch (Exception e) 
        {
            log("Page1 Initialization Failure", e);
            throw e instanceof FacesException ? (FacesException) e: 
                new FacesException(e);
        }
    }

    public void preprocess() 
    {
    } // fin del m�todo preprocess

    
    public void prerender() 
    {
        addressesDataProvider.refresh();
    } // fin del m�todo prerender

    public void destroy() 
    {
        busquedaDireccionesDataProvider.close();
        addressesDataProvider.close();
    } // fin del m�todo destroy

    // manejador de acciones que agrega un contacto a la base de datos LibretaDirecciones
    // cuando el usuario hace clic en el bot�n Enviar
    public String enviarBoton_action() 
    {
       if ( addressesDataProvider.canAppendRow() ) 
      {
         try 
         {
            RowKey rk = addressesDataProvider.appendRow();
            addressesDataProvider.setCursorRow(rk);
            
            addressesDataProvider.setValue( "ADDRESSES.FIRSTNAME",
               pnombreCampoTexto.getValue() );
            addressesDataProvider.setValue( "ADDRESSES.LASTNAME",
               apaternoCampoTexto.getValue() );
            addressesDataProvider.setValue( "ADDRESSES.STREET",
               calleCampoTexto.getValue() );
            addressesDataProvider.setValue( "ADDRESSES.CITY",
               ciudadCampoTexto.getValue() );
            addressesDataProvider.setValue( "ADDRESSES.STATE",
               estadoCampoTexto.getValue() );
            addressesDataProvider.setValue( "ADDRESSES.ZIP",
               cpCampoTexto.getValue());
            addressesDataProvider.commitChanges();
            
            // restablece los campos de texto
            apaternoCampoTexto.setValue( "" );
            pnombreCampoTexto.setValue( "" );
            calleCampoTexto.setValue( "" );
            ciudadCampoTexto.setValue( "" );
            estadoCampoTexto.setValue( "" );
            cpCampoTexto.setValue( "" );
         } // fin de try
         catch ( Exception ex ) 
         {
            error( "No se actualizo la libreta de direcciones.  " +
               ex.getMessage() );
         } // fin de catch
      } // fin de if
       
        return null;
    } // fin del m�todo enviarBoton_action
    
    // manejador de acciones para el cuadro autocompletar que obtiene los nombres
    // de la libreta de direcciones, cuyos prefijos coincidan con las letras escritas
    // hasta un momento dado, y los muestra en una lista de sugerencias.
    public void nombreAutoComplete_complete( FacesContext context, String
      prefix, CompletionResult result )
    {
        try
        {
            boolean tieneElSiguiente = addressesDataProvider.cursorFirst();

         while ( tieneElSiguiente )
         {
            // obtiene un nombre de la base de datos
            String nombre =
               (String) addressesDataProvider.getValue( 
               "ADDRESSES.LASTNAME" ) + ", " +
               (String) addressesDataProvider.getValue(
               "ADDRESSES.FIRSTNAME" ) ;
            
            // si el nombre en la base de datos empieza con el prefijo, se
            // agrega a la lista de sugerencias
            if ( nombre.toLowerCase().startsWith( prefix.toLowerCase() ) )
            {
               result.addItem( nombre );
            } // fin de if
            else
            {
               // termina el ciclo si el resto de los nombres son 
               // alfab�ticamente menores que el prefijo
               if ( prefix.compareTo( nombre ) < 0 )
               {
                  break;
               } // fin de if
            } // fin de else
            
            // desplaza el cursor a la siguiente fila de la base de datos
            tieneElSiguiente = addressesDataProvider.cursorNext();
         } // fin de while
      } // fin de try
      catch ( Exception ex )
      {
         result.addItem( "Excepcion al obtener nombres que coincidan." );
      } // fin de catch
   } // fin del m�todo nombreAutoComplete_complete

   // manejador de acciones para el buscarBoton que busca en la base de datos de
   // la libreta de direcciones y muestra la direcci�n solicitada en un mapa correspondiente.    public String buscarBoton_action() 
    {
      // divide el texto del campo AutoComplete en primer nombre y apellido
      String nombre = String.valueOf( nombreAutoComplete.getValue() );
      int splitIndex = nombre.indexOf( "," );
      String apaterno = nombre.substring( 0, splitIndex );
      String pnombre = nombre.substring( splitIndex + 2 );
      
      try
      {
         // establece los par�metros para la consulta direccionesSeleccionadas
         busquedaDireccionesDataProvider.getCachedRowSet().setObject( 
            1, pnombre );
         busquedaDireccionesDataProvider.getCachedRowSet().setObject( 
            2, apaterno );
         busquedaDireccionesDataProvider.refresh();
         String calle = (String) busquedaDireccionesDataProvider.getValue( 
            "ADDRESSES.STREET" );
         String ciudad = (String) busquedaDireccionesDataProvider.getValue( 
            "ADDRESSES.CITY" );
         String estado = (String) busquedaDireccionesDataProvider.getValue( 
            "ADDRESSES.STATE" );
         String cp =  (String) busquedaDireccionesDataProvider.getValue( 
            "ADDRESSES.ZIP" );
                  
         // aplica formato a la direcci�n para Google Maps
         String direccionGoogle = calle + ", " + ciudad + ", " + estado + 
            " " + cp;
         
         // obtiene los puntos geogr�ficos para la direcci�n
         GeoPoint puntos[] = geoCoder.geoCode( direccionGoogle );

         // si Google Maps no puede encontrar la direcci�n
         if ( puntos == null )
         {
            error( "El mapa para " + direccionGoogle + " no se pudo encontrar");
            mapViewer.setRendered( false ); // oculta el mapa
            return null;
         } // fin de if
            
         // centra el mapa para la direcci�n dada
         mapViewer_center.setLatitude( puntos[0].getLatitude() );
         mapViewer_center.setLongitude( puntos[0].getLongitude() );

         // crea un marcador para la direcci�n y establece su texto a mostrar
         mapMarker.setLatitude( puntos[0].getLatitude() );
         mapMarker.setLongitude( puntos[0].getLongitude() );
         mapMarker.setMarkup(  pnombre + " " + apaterno + "<br/>" + calle +   
            "<br/>" + ciudad + ", " + estado + " " + cp );

         mapViewer.setRendered( true ); // muestra el mapa
      } // fin de try
      catch ( Exception e )
      {
         error( "Error al procesar busqueda. " + e.getMessage() );
      } // fin de catch
      
        return null;
    } // fin del m�todo buscarBoton_action
} // fin de la clase LibretaDirecciones

