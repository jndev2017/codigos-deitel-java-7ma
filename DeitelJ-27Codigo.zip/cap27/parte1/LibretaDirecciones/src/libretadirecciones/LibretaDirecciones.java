// Fig. 27.8: LibretaDirecciones.java
// Bean de p�gina para agregar un contacto a la libreta de direcciones.
package libretadirecciones;

import com.sun.data.provider.RowKey;
import com.sun.rave.web.ui.appbase.AbstractPageBean;
import com.sun.rave.web.ui.component.Body;
import com.sun.rave.web.ui.component.Form;
import com.sun.rave.web.ui.component.Head;
import com.sun.rave.web.ui.component.Html;
import com.sun.rave.web.ui.component.Link;
import com.sun.rave.web.ui.component.Page;
import javax.faces.FacesException;
import com.sun.rave.web.ui.component.StaticText;
import com.sun.rave.web.ui.component.TextField;
import com.sun.rave.web.ui.component.Label;
import com.sun.rave.web.ui.component.Button;
import com.sun.rave.web.ui.component.Table;
import com.sun.rave.web.ui.component.TableRowGroup;
import com.sun.rave.web.ui.component.TableColumn;
import com.sun.data.provider.impl.CachedRowSetDataProvider;
import com.sun.rave.web.ui.component.MessageGroup;

public class LibretaDirecciones extends AbstractPageBean 
{
    private int __placeholder;
    
    private void _init() throws Exception 
    {
        addressesDataProvider.setCachedRowSet(
                (javax.sql.rowset.CachedRowSet)
                    getValue("#{SessionBean1.addressesRowSet}"));
        direccionesTabla.setInternalVirtualForm(true);
    }


    private Page page1 = new Page();
    
    public Page getPage1() 
    {
        return page1;
    }
    
    public void setPage1(Page p) 
    {
        this.page1 = p;
    }
    
    private Html html1 = new Html();
    
    public Html getHtml1() 
    {
        return html1;
    }
    
    public void setHtml1(Html h) 
    {
        this.html1 = h;
    }
    
    private Head head1 = new Head();
    
    public Head getHead1() 
    {
        return head1;
    }
    
    public void setHead1(Head h) 
    {
        this.head1 = h;
    }
    
    private Link link1 = new Link();
    
    public Link getLink1() 
    {
        return link1;
    }
    
    public void setLink1(Link l) 
    {
        this.link1 = l;
    }
    
    private Body body1 = new Body();
    
    public Body getBody1() 
    {
        return body1;
    }
    
    public void setBody1(Body b) 
    {
        this.body1 = b;
    }
    
    private Form form1 = new Form();
    
    public Form getForm1() 
    {
        return form1;
    }
    
    public void setForm1(Form f) 
    {
        this.form1 = f;
    }

    private StaticText staticText1 = new StaticText();

    public StaticText getStaticText1() 
    {
        return staticText1;
    }

    public void setStaticText1(StaticText st) 
    {
        this.staticText1 = st;
    }

    private TextField pnombreCampoTexto = new TextField();

    public TextField getPnombreCampoTexto() 
    {
        return pnombreCampoTexto;
    }

    public void setPnombreCampoTexto(TextField tf) 
    {
        this.pnombreCampoTexto = tf;
    }

    private TextField apaternoCampoTexto = new TextField();

    public TextField getApaternoCampoTexto() 
    {
        return apaternoCampoTexto;
    }

    public void setApaternoCampoTexto(TextField tf) 
    {
        this.apaternoCampoTexto = tf;
    }

    private TextField calleCampoTexto = new TextField();

    public TextField getCalleCampoTexto() 
    {
        return calleCampoTexto;
    }

    public void setCalleCampoTexto(TextField tf) 
    {
        this.calleCampoTexto = tf;
    }

    private TextField ciudadCampoTexto = new TextField();

    public TextField getCiudadCampoTexto() 
    {
        return ciudadCampoTexto;
    }

    public void setCiudadCampoTexto(TextField tf) 
    {
        this.ciudadCampoTexto = tf;
    }

    private TextField estadoCampoTexto = new TextField();

    public TextField getEstadoCampoTexto() 
    {
        return estadoCampoTexto;
    }

    public void setEstadoCampoTexto(TextField tf) 
    {
        this.estadoCampoTexto = tf;
    }

    private TextField cpCampoTexto = new TextField();

    public TextField getCpCampoTexto() 
    {
        return cpCampoTexto;
    }

    public void setCpCampoTexto(TextField tf) 
    {
        this.cpCampoTexto = tf;
    }

    private Label pnombreEtiqueta = new Label();

    public Label getPnombreEtiqueta() 
    {
        return pnombreEtiqueta;
    }

    public void setPnombreEtiqueta(Label l) 
    {
        this.pnombreEtiqueta = l;
    }

    private Label apaternoEtiqueta = new Label();

    public Label getApaternoEtiqueta() 
    {
        return apaternoEtiqueta;
    }

    public void setApaternoEtiqueta(Label l) 
    {
        this.apaternoEtiqueta = l;
    }

    private Label calleEtiqueta = new Label();

    public Label getCalleEtiqueta() 
    {
        return calleEtiqueta;
    }

    public void setCalleEtiqueta(Label l) 
    {
        this.calleEtiqueta = l;
    }

    private Label ciudadEtiqueta = new Label();

    public Label getCiudadEtiqueta() 
    {
        return ciudadEtiqueta;
    }

    public void setCiudadEtiqueta(Label l) 
    {
        this.ciudadEtiqueta = l;
    }

    private Label estadoEtiqueta = new Label();

    public Label getEstadoEtiqueta() 
    {
        return estadoEtiqueta;
    }

    public void setEstadoEtiqueta(Label l) 
    {
        this.estadoEtiqueta = l;
    }

    private Label cpEtiqueta = new Label();

    public Label getCpEtiqueta() 
    {
        return cpEtiqueta;
    }

    public void setCpEtiqueta(Label l) 
    {
        this.cpEtiqueta = l;
    }

    private Button enviarBoton = new Button();

    public Button getEnviarBoton() 
    {
        return enviarBoton;
    }

    public void setEnviarBoton(Button b) 
    {
        this.enviarBoton = b;
    }

    private Button borrarBoton = new Button();

    public Button getBorrarBoton() 
    {
        return borrarBoton;
    }

    public void setBorrarBoton(Button b) 
    {
        this.borrarBoton = b;
    }

    private Table direccionesTabla = new Table();

    public Table getDireccionesTabla() 
    {
        return direccionesTabla;
    }

    public void setDireccionesTabla(Table t) 
    {
        this.direccionesTabla = t;
    }

    private TableRowGroup tableRowGroup1 = new TableRowGroup();

    public TableRowGroup getTableRowGroup1() 
    {
        return tableRowGroup1;
    }

    public void setTableRowGroup1(TableRowGroup trg) 
    {
        this.tableRowGroup1 = trg;
    }

    private CachedRowSetDataProvider addressesDataProvider = new CachedRowSetDataProvider();

    public CachedRowSetDataProvider getAddressesDataProvider() 
    {
        return addressesDataProvider;
    }

    public void setAddressesDataProvider(CachedRowSetDataProvider crsdp) 
    {
        this.addressesDataProvider = crsdp;
    }

    private TableColumn pnombreColumna = new TableColumn();

    public TableColumn getPnombreColumna() 
    {
        return pnombreColumna;
    }

    public void setPnombreColumna(TableColumn tc) 
    {
        this.pnombreColumna = tc;
    }

    private StaticText staticText2 = new StaticText();

    public StaticText getStaticText2() 
    {
        return staticText2;
    }

    public void setStaticText2(StaticText st) 
    {
        this.staticText2 = st;
    }

    private TableColumn apaternoColumna = new TableColumn();

    public TableColumn getApaternoColumna() 
    {
        return apaternoColumna;
    }

    public void setApaternoColumna(TableColumn tc) 
    {
        this.apaternoColumna = tc;
    }

    private StaticText staticText3 = new StaticText();

    public StaticText getStaticText3() 
    {
        return staticText3;
    }

    public void setStaticText3(StaticText st) 
    {
        this.staticText3 = st;
    }

    private TableColumn calleColumna = new TableColumn();

    public TableColumn getCalleColumna() 
    {
        return calleColumna;
    }

    public void setCalleColumna(TableColumn tc) 
    {
        this.calleColumna = tc;
    }

    private StaticText staticText4 = new StaticText();

    public StaticText getStaticText4() 
    {
        return staticText4;
    }

    public void setStaticText4(StaticText st) 
    {
        this.staticText4 = st;
    }

    private TableColumn ciudadColumna = new TableColumn();

    public TableColumn getCiudadColumna() 
    {
        return ciudadColumna;
    }

    public void setCiudadColumna(TableColumn tc) 
    {
        this.ciudadColumna = tc;
    }

    private StaticText staticText5 = new StaticText();

    public StaticText getStaticText5() 
    {
        return staticText5;
    }

    public void setStaticText5(StaticText st) 
    {
        this.staticText5 = st;
    }

    private TableColumn estadoColumna = new TableColumn();

    public TableColumn getEstadoColumna() 
    {
        return estadoColumna;
    }

    public void setEstadoColumna(TableColumn tc) 
    {
        this.estadoColumna = tc;
    }

    private StaticText staticText6 = new StaticText();

    public StaticText getStaticText6() 
    {
        return staticText6;
    }

    public void setStaticText6(StaticText st) 
    {
        this.staticText6 = st;
    }

    private TableColumn cpColumna = new TableColumn();

    public TableColumn getCpColumna() 
    {
        return cpColumna;
    }

    public void setCpColumna(TableColumn tc) 
    {
        this.cpColumna = tc;
    }

    private StaticText staticText7 = new StaticText();

    public StaticText getStaticText7() 
    {
        return staticText7;
    }

    public void setStaticText7(StaticText st) 
    {
        this.staticText7 = st;
    }

    private MessageGroup messageGroup1 = new MessageGroup();

    public MessageGroup getMessageGroup1() 
    {
        return messageGroup1;
    }

    public void setMessageGroup1(MessageGroup mg) 
    {
        this.messageGroup1 = mg;
    }
    
    /** 
     * <p>Construir una instancia de bean de p�gina.</p>
     */

    public LibretaDirecciones() {
    }

    protected RequestBean1 getRequestBean1() 
    {
        return (RequestBean1)getBean("RequestBean1");
    }


    protected ApplicationBean1 getApplicationBean1() 
    {
        return (ApplicationBean1)getBean("ApplicationBean1");
    }


    protected SessionBean1 getSessionBean1() 
    {
        return (SessionBean1)getBean("SessionBean1");
    }


    public void init() {
        // Realizar iniciaciones heredadas de la superclase
        super.init();
        try {
            _init();
        } catch (Exception e) {
            log("Page1 Initialization Failure", e);
            throw e instanceof FacesException ? (FacesException) e: new FacesException(e);
        }
    }

    public void preprocess() {
    }

    
    
    public void prerender() 
    {
        addressesDataProvider.refresh();
    }

    public void destroy() 
    {
        addressesDataProvider.close();
    }

    // manejador de acciones que agrega un contacto a la base de datos LibretaDirecciones
    // cuando el usuario hace clic en el bot�n Enviar
    public String enviarBoton_action() 
    {
       if ( addressesDataProvider.canAppendRow() ) 
      {
         try 
         {
            RowKey rk = addressesDataProvider.appendRow();
            addressesDataProvider.setCursorRow(rk);
            
            addressesDataProvider.setValue( "ADDRESSES.FIRSTNAME",
               pnombreCampoTexto.getValue() );
            addressesDataProvider.setValue( "ADDRESSES.LASTNAME",
               apaternoCampoTexto.getValue() );
            addressesDataProvider.setValue( "ADDRESSES.STREET",
               calleCampoTexto.getValue() );
            addressesDataProvider.setValue( "ADDRESSES.CITY",
               ciudadCampoTexto.getValue() );
            addressesDataProvider.setValue( "ADDRESSES.STATE",
               estadoCampoTexto.getValue() );
            addressesDataProvider.setValue( "ADDRESSES.ZIP",
               cpCampoTexto.getValue());
            addressesDataProvider.commitChanges();
            
            // restablece los campos de texto
            apaternoCampoTexto.setValue( "" );
            pnombreCampoTexto.setValue( "" );
            calleCampoTexto.setValue( "" );
            ciudadCampoTexto.setValue( "" );
            estadoCampoTexto.setValue( "" );
            cpCampoTexto.setValue( "" );
         } // fin de try
         catch ( Exception ex ) 
         {
            error( "No se actualizo la libreta de direcciones.  " +
               ex.getMessage() );
         } // fin de catch
      } // fin de if
       
        return null;
    } // fin del m�todo enviarBoton_action
} // fin de la clase LibretaDirecciones

