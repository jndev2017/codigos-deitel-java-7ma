// Fig. 24.3: LeerArchivoServidor.java
// Uso de un objeto JEditorPane para mostrar el contenido de un archivo en un servidor Web.
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class LeerArchivoServidor extends JFrame 
{
   private JTextField campoIntroducir; // objeto JTextField para escribir el nombre del sitio
   private JEditorPane areaContenido; // para mostrar un sitio Web

   // establece la GUI
   public LeerArchivoServidor()
   {
      super( "Navegador Web simple" );

      // crea campoIntroducir y registra su componente de escucha
      campoIntroducir = new JTextField( "Escriba el URL del archivo" );
      campoIntroducir.addActionListener(
         new ActionListener() 
         {
            // obtiene el documento especificado por el usuario
            public void actionPerformed( ActionEvent evento )
            {
               obtenerLaPagina( evento.getActionCommand() );
            } // fin del m�todo actionPerformed
         } // fin de la clase interna
      ); // fin de la llamada a addActionListener

      add( campoIntroducir, BorderLayout.NORTH );

      areaContenido = new JEditorPane(); // crea areaContenido
      areaContenido.setEditable( false );
      areaContenido.addHyperlinkListener(
         new HyperlinkListener() 
         {
            // si el usuario hizo clic en un hiperv�nculo, va a la p�gina especificada
            public void hyperlinkUpdate( HyperlinkEvent evento )
            {
               if ( evento.getEventType() == 
                    HyperlinkEvent.EventType.ACTIVATED )
                  obtenerLaPagina( evento.getURL().toString() );
            } // end method hyperlinkUpdate
         } // fin de la clase interna an�nima
      ); // fin de la llamada a addHyperlinkListener

      add( new JScrollPane( areaContenido ), BorderLayout.CENTER );
      setSize( 400, 300 ); // establece el tama�o de la ventana
      setVisible( true ); // muestra la ventana
   } // fin del constructor de LeerArchivoServidor

   // carga el documento
   private void obtenerLaPagina( String ubicacion )
   {
      try // carga el documento y muestra la ubicaci�n
      {
         areaContenido.setPage( ubicacion ); // establece la p�gina
         campoIntroducir.setText( ubicacion ); // establece el texto
      } // fin de try
      catch ( IOException excepcionES ) 
      {
         JOptionPane.showMessageDialog( this,
            "Error al obtener el URL especificado", "URL incorrecto", 
            JOptionPane.ERROR_MESSAGE );
      } // fin de catch
   } // fin del m�todo obtenerLaPagina
} // fin de la clase LeerArchivoServidor


/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
