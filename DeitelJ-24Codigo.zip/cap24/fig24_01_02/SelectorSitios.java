// Fig. 24.2: SelectorSitios.java
// Este programa carga un documento de un URL.
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.ArrayList;
import java.awt.BorderLayout;
import java.applet.AppletContext;
import javax.swing.JApplet;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class SelectorSitios extends JApplet 
{
   private HashMap< Object, URL > sitios; // nombres de sitios y URLs
   private ArrayList< String > nombresSitios; // nombres de sitios
   private JList selectorSitios; // lista de sitios a elegir

   // lee los par�metros de HTML y establece la GUI
   public void init()
   {
      sitios = new HashMap< Object, URL >(); // crea objeto HashMap
      nombresSitios = new ArrayList< String >(); // crea objeto ArrayList

      // obtiene los par�metros del documento de HTML
      obtenerSitiosDeParametrosHTML(); 

      // crea componentes de GUI e interfaz de esquema
      add( new JLabel( "Seleccione un sitio para navegar" ), BorderLayout.NORTH );

      selectorSitios = new JList( nombresSitios.toArray() ); // llena el objeto JList
      selectorSitios.addListSelectionListener(
         new ListSelectionListener() // clase interna an�nima
         {
            // va al sitio seleccionado por el usuario
            public void valueChanged( ListSelectionEvent evento )
            {
               // obtiene el nombre del sitio seleccionado
               Object objeto = selectorSitios.getSelectedValue();

               // usa el nombre del sitio para localizar el URL correspondiente
               URL nuevoDocumento = sitios.get( objeto );

               // obtiene el contenedor de applets
               AppletContext navegador = getAppletContext();

               // indica al contenedor de applets que cambie de p�gina
               navegador.showDocument( nuevoDocumento );
            } // fin del m�todo valueChanged
         } // fin de la clase interna an�nima
      ); // fin de la llamada a addListSelectionListener

      add( new JScrollPane( selectorSitios ), BorderLayout.CENTER );
   } // fin del m�todo init

   // obtiene los par�metros del documento de HTML
   private void obtenerSitiosDeParametrosHTML()
   {
      String titulo; // titulo del sitio
      String ubicacion; // ubicacion del sitio
      URL url; // URL de la ubicaci�n
      int contador = 0; // cuenta el n�mero de sitios

      titulo = getParameter( "titulo" + contador ); // obtiene el t�tulo del primer sitio

      // itera hasta que no haya m�s par�metros en el documento de HTML
      while ( titulo != null ) 
      {
         // obtiene la ubicaci�n del sitio
         ubicacion = getParameter( "ubicacion" + contador );
            
         try // coloca titulo/URL en objeto HashMap y titulo en objeto ArrayList
         {
            url = new URL( ubicacion ); // convierte la ubicaci�n en URL
            sitios.put( titulo, url ); // coloca titulo/URL en objeto HashMap
            nombresSitios.add( titulo ); // coloca titulo en objeto ArrayList
         } // fin de try
         catch ( MalformedURLException excepcionURL ) 
         {
            excepcionURL.printStackTrace();
         } // fin de catch

         contador++;
         titulo = getParameter( "titulo" + contador ); // obtiene el t�tulo del siguiente sitio
      } // fin de while
   } // fin del m�todo obtenerSitiosDeParametrosHTML
} // fin de la clase SelectorSitios

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/