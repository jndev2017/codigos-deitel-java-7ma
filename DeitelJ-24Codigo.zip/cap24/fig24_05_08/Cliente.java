// Fig. 24.7: Cliente.java
// Cliente que lee y muestra la informaci�n que se env�a desde un Servidor.
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class Cliente extends JFrame 
{
   private JTextField campoIntroducir; // introduce la informaci�n del usuario
   private JTextArea areaPantalla; // muestra la informaci�n al usuario
   private ObjectOutputStream salida; // flujo de salida hacia el servidor
   private ObjectInputStream entrada; // flujo de entrada del servidor
   private String mensaje = ""; // mensaje del servidor
   private String servidorChat; // aloja al servidor para esta aplicaci�n
   private Socket cliente; // socket para comunicarse con el servidor

   // inicializa el objeto servidorChat y establece la GUI
   public Cliente( String host )
   {
      super( "Cliente" );

      servidorChat = host; // establece el servidor al que se conecta este cliente

      campoIntroducir = new JTextField(); // crea objeto campoIntroducir
      campoIntroducir.setEditable( false );
      campoIntroducir.addActionListener(
         new ActionListener() 
         {
            // envia el mensaje al servidor
            public void actionPerformed( ActionEvent evento )
            {
               enviarDatos( evento.getActionCommand() );
               campoIntroducir.setText( "" );
            } // fin del m�todo actionPerformed
         } // fin de la clase interna an�nima
      ); // fin de la llamada a addActionListener

      add( campoIntroducir, BorderLayout.NORTH );

      areaPantalla = new JTextArea(); // crea objeto areaPantalla
      add( new JScrollPane( areaPantalla ), BorderLayout.CENTER );

      setSize( 300, 150 ); // establece el tama�o de la ventana
      setVisible( true ); // muestra la ventana
   } // fin del constructor de Cliente

   // se conecta al servidor y procesa los mensajes que �ste env�a
   public void ejecutarCliente() 
   {
      try // se conecta al servidor, obtiene flujos, procesa la conexi�n
      {
         conectarAlServidor(); // crea un objeto Socket para hacer la conexi�n
         obtenerFlujos(); // obtiene los flujos de entrada y salida
         procesarConexion(); // procesa la conexi�n
      } // fin de try
      catch ( EOFException excepcionEOF ) 
      {
         mostrarMensaje( "\nCliente termino la conexion" );
      } // fin de catch
      catch ( IOException excepcionES ) 
      {
         excepcionES.printStackTrace();
      } // fin de catch
      finally 
      {
         cerrarConexion(); // cierra la conexi�n
      } // fin de finally
   } // fin del m�todo ejecutarCliente

   // se conecta al servidor
   private void conectarAlServidor() throws IOException
   {      
      mostrarMensaje( "Intentando realizar conexion\n" );

      // crea objeto Socket para hacer conexi�n con el servidor
      cliente = new Socket( InetAddress.getByName( servidorChat ), 12345 );

      // muestra la informaci�n de la conexi�n
      mostrarMensaje( "Conectado a: " + 
         cliente.getInetAddress().getHostName() );
   } // fin del m�todo conectarAlServidor

   // obtiene flujos para enviar y recibir datos
   private void obtenerFlujos() throws IOException
   {
      // establece flujo de salida para los objetos
      salida = new ObjectOutputStream( cliente.getOutputStream() );      
      salida.flush(); // vac�a el b�fer de salida para enviar informaci�n de encabezado

      // establece flujo de entrada para los objetos
      entrada = new ObjectInputStream( cliente.getInputStream() );

      mostrarMensaje( "\nSe obtuvieron los flujos de E/S\n" );
   } // fin del m�todo obtenerFlujos

   // procesa la conexi�n con el servidor
   private void procesarConexion() throws IOException
   {
      // habilita campoIntroducir para que el usuario cliente pueda enviar mensajes
      establecerCampoEditable( true );

      do // procesa los mensajes que se env�an desde el servidor
      { 
         try // lee el mensaje y lo muestra
         {
            mensaje = ( String ) entrada.readObject(); // lee nuevo mensaje
            mostrarMensaje( "\n" + mensaje ); // muestra el mensaje
         } // fin de try
         catch ( ClassNotFoundException excepcionClaseNoEncontrada ) 
         {
            mostrarMensaje( "\nSe recibio un tipo de objeto desconocido" );
         } // fin de catch

      } while ( !mensaje.equals( "SERVIDOR>>> TERMINAR" ) );
   } // fin del m�todo procesarConexion

   // cierra flujos y socket
   private void cerrarConexion() 
   {
      mostrarMensaje( "\nCerrando conexion" );
      establecerCampoEditable( false ); // deshabilita campoIntroducir

      try 
      {
         salida.close(); // cierra el flujo de salida
         entrada.close(); // cierra el flujo de entrada
         cliente.close(); // cierra el socket
      } // fin de try
      catch ( IOException excepcionES ) 
      {
         excepcionES.printStackTrace();
      } // fin de catch
   } // fin del m�todo cerrarConexion

   // env�a un mensaje al servidor
   private void enviarDatos( String mensaje )
   {
      try // env�a un objeto al servidor
      {
         salida.writeObject( "CLIENTE>>> " + mensaje );
         salida.flush(); // env�a todos los datos a la salida
         mostrarMensaje( "\nCLIENTE>>> " + mensaje );
      } // fin de try
      catch ( IOException excepcionES )
      {
         areaPantalla.append( "\nError al escribir objeto" );
      } // fin de catch
   } // fin del m�todo enviarDatos

   // manipula el objeto areaPantalla en el subproceso despachador de eventos
   private void mostrarMensaje( final String mensajeAMostrar )
   {
      SwingUtilities.invokeLater(
         new Runnable()
         {
            public void run() // actualiza objeto areaPantalla
            {
               areaPantalla.append( mensajeAMostrar );
            } // fin del m�todo run
         }  // fin de la clase interna an�nima
      ); // fin de la llamada a SwingUtilities.invokeLater
   } // fin del m�todo mostrarMensaje

   // manipula a campoIntroducir en el subproceso despachador de eventos
   private void establecerCampoEditable( final boolean editable )
   {
      SwingUtilities.invokeLater(
         new Runnable() 
         {
            public void run() // establece la propiedad de edici�n de campoIntroducir
            {
               campoIntroducir.setEditable( editable );
            } // fin del m�todo run
         } // fin de la clase interna an�nima
      ); // fin de la llamada a SwingUtilities.invokeLater
   } // fin del m�todo establecerCampoEditable
} // fin de la clase Cliente

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
