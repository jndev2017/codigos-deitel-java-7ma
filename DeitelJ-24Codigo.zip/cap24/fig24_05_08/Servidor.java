// Fig. 24.5: Servidor.java
// Establece un servidor que recibe una conexi�n de un cliente, env�a 
// una cadena al cliente y cierra la conexi�n.
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class Servidor extends JFrame 
{
   private JTextField campoIntroducir; // recibe como entrada un mensaje del usuario
   private JTextArea areaPantalla; // muestra informaci�n al usuario
   private ObjectOutputStream salida; // flujo de salida hacia el cliente
   private ObjectInputStream entrada; // flujo de entrada del cliente
   private ServerSocket servidor; // socket servidor
   private Socket conexion; // conexi�n al cliente
   private int contador = 1; // contador del n�mero de conexiones

   // establece la GUI
   public Servidor()
   {
      super( "Servidor" );

      campoIntroducir = new JTextField(); // crea objeto campoIntroducir
      campoIntroducir.setEditable( false );
      campoIntroducir.addActionListener(
         new ActionListener() 
         {
            // env�a un mensaje al cliente
            public void actionPerformed( ActionEvent evento )
            {
               enviarDatos( evento.getActionCommand() );
               campoIntroducir.setText( "" );
            } // fin del m�todo actionPerformed
         } // fin de la clase interna an�nima
      ); // fin de la llamada a addActionListener

      add( campoIntroducir, BorderLayout.NORTH );

      areaPantalla = new JTextArea(); // crea objeto areaPantalla
      add( new JScrollPane( areaPantalla ), BorderLayout.CENTER );

      setSize( 300, 150 ); // establece el tama�o de la ventana
      setVisible( true ); // muestra la ventana
   } // fin del constructor de Servidor

   // establece y ejecuta el servidor
   public void ejecutarServidor()
   {
      try // establece el servidor para que reciba conexiones; procesa las conexiones
      {
         servidor = new ServerSocket( 12345, 100 ); // crea objeto ServerSocket

         while ( true ) 
         {
            try 
            {
               esperarConexion(); // espera una conexi�n
               obtenerFlujos(); // obtiene los flujos de entrada y salida
               procesarConexion(); // procesa la conexi�n
            } // fin de try
            catch ( EOFException excepcionEOF ) 
            {
               mostrarMensaje( "\nServidor termino la conexion" );
            } // fin de catch
            finally 
            {
               cerrarConexion(); //  cierra la conexi�n
               contador++;
            } // fin de finally
         } // fin de while
      } // fin de try
      catch ( IOException exepcionES ) 
      {
         exepcionES.printStackTrace();
      } // fin de catch
   } // fin del m�todo ejecutarServidor

   // espera a que llegue una conexi�n, despu�s muestra informaci�n sobre �sta
   private void esperarConexion() throws IOException
   {
      mostrarMensaje( "Esperando una conexion\n" );
      conexion = servidor.accept(); // permite al servidor aceptar la conexi�n            
      mostrarMensaje( "Conexion " + contador + " recibida de: " +
         conexion.getInetAddress().getHostName() );
   } // fin del m�todo esperarConexion

   // obtiene flujos para enviar y recibir datos
   private void obtenerFlujos() throws IOException
   {
      // establece el flujo de salida para los objetos
      salida = new ObjectOutputStream( conexion.getOutputStream() );
      salida.flush(); // vac�a el b�fer de salida para enviar informaci�n del encabezado

      // establece el flujo de entrada para los objetos
      entrada = new ObjectInputStream( conexion.getInputStream() );

      mostrarMensaje( "\nSe obtuvieron los flujos de E/S\n" );
   } // fin del m�todo obtenerFlujos

   // procesa la conexi�n con el cliente
   private void procesarConexion() throws IOException
   {
      String mensaje = "Conexion exitosa";
      enviarDatos( mensaje ); // env�a mensaje de conexi�n exitosa

      // habilita campoIntroducir para que el usuario del servidor pueda enviar mensajes
      setTextFieldEditable( true );

      do // procesa los mensajes enviados desde el cliente
      { 
         try // lee el mensaje y lo muestra en pantalla
         {
            mensaje = ( String ) entrada.readObject(); // lee el nuevo mensaje
            mostrarMensaje( "\n" + mensaje ); // muestra el mensaje
         } // fin de try
         catch ( ClassNotFoundException excepcionClaseNoEncontrada ) 
         {
            mostrarMensaje( "\nSe recibio un tipo de objeto desconocido" );
         } // fin de catch

      } while ( !mensaje.equals( "CLIENTE>>> TERMINAR" ) );
   } // fin del m�todo procesarConexion

   // clierra flujos y socket
   private void cerrarConexion() 
   {
      mostrarMensaje( "\nTerminando conexion\n" );
      setTextFieldEditable( false ); // deshabilita campoIntroducir

      try 
      {
         salida.close(); // cierra flujo de salida
         entrada.close(); // cierra flujo de entrada
         conexion.close(); // cierra el socket
      } // fin de try
      catch ( IOException exepcionES ) 
      {
         exepcionES.printStackTrace();
      } // fin de catch
   } // fin del m�todo cerrarConexion

   // env�a el mensaje al cliente
   private void enviarDatos( String mensaje )
   {
      try // env�a objeto al cliente
      {
         salida.writeObject( "SERVIDOR>>> " + mensaje );
         salida.flush(); // env�a toda la salida al cliente
         mostrarMensaje( "\nSERVIDOR>>> " + mensaje );
      } // fin de try
      catch ( IOException exepcionES ) 
      {
         areaPantalla.append( "\nError al escribir objeto" );
      } // fin de catch
   } // fin del m�todo enviarDatos

   // manipula areaPantalla en el subproceso despachador de eventos
   private void mostrarMensaje( final String mensajeAMostrar )
   {
      SwingUtilities.invokeLater(
         new Runnable() 
         {
            public void run() // updates areaPantalla
            {
               areaPantalla.append( mensajeAMostrar ); // adjunta el mensaje
            } // fin del m�todo run
         } // fin de la clase interna an�nima
      ); // fin de la llamada a SwingUtilities.invokeLater
   } // fin del m�todo mostrarMensaje

   // manipula a campoIntroducir en el subproceso despachador de eventos
   private void setTextFieldEditable( final boolean editable )
   {
      SwingUtilities.invokeLater(
         new Runnable()
         {
            public void run() // establece la propiedad de edici�n de campoIntroducir
            {
               campoIntroducir.setEditable( editable );
            } // fin del m�todo
         }  // fin de la clase interna
      ); // fin de la llamada a SwingUtilities.invokeLater
   } // fin del m�todo setTextFieldEditable
} // fin de la clase Servidor

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
