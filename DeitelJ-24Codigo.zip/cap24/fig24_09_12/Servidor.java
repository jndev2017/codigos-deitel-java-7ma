// Fig. 24.9: Servidor.java
// Servidor que recibe y env�a paquetes desde/hacia un cliente.
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class Servidor extends JFrame 
{
   private JTextArea areaPantalla; // muestra los paquetes recibidos
   private DatagramSocket socket; // socket para conectarse al cliente

   // establece la GUI y el objeto DatagramSocket
   public Servidor()
   {
      super( "Servidor" );

      areaPantalla = new JTextArea(); // crea objeto areaPantalla
      add( new JScrollPane( areaPantalla ), BorderLayout.CENTER );
      setSize( 400, 300 ); // establece el tama�o de la ventana
      setVisible( true ); // muestra la ventana

      try // crea objeto DatagramSocket para enviar y recibir paquetes
      {
         socket = new DatagramSocket( 5000 );
      } // fin de try
      catch ( SocketException excepcionSocket ) 
      {
         excepcionSocket.printStackTrace();
         System.exit( 1 );
      } // fin de catch
   } // fin del constructor de Servidor

   // espera a que lleguen los paquetes, muestra los datos y repite el paquete al cliente
   public void esperarPaquetes()
   {
      while ( true ) 
      {
         try // recibe el paquete, muestra su contenido, devuelve una copia al cliente
         {
            byte datos[] = new byte[ 100 ]; // establece un paquete
            DatagramPacket paqueteRecibir = 
               new DatagramPacket( datos, datos.length );

            socket.receive( paqueteRecibir ); // espera a recibir el paquete

            // muestra la informaci�n del paquete recibido
            mostrarMensaje( "\nPaquete recibido:" + 
               "\nDe host: " + paqueteRecibir.getAddress() + 
               "\nPuerto host: " + paqueteRecibir.getPort() + 
               "\nLongitud: " + paqueteRecibir.getLength() + 
               "\nContiene:\n\t" + new String( paqueteRecibir.getData(), 
                  0, paqueteRecibir.getLength() ) );

            enviarPaqueteAlCliente( paqueteRecibir ); // env�a el paquete al cliente
         } // fin de try
         catch ( IOException excepcionES )
         {
            mostrarMensaje( excepcionES.toString() + "\n" );
            excepcionES.printStackTrace();
         } // fin de catch
      } // fin de while
   } // fin del m�todo esperarPaquetes

   // repite el paquete al cliente
   private void enviarPaqueteAlCliente( DatagramPacket paqueteRecibir ) 
      throws IOException
   {
      mostrarMensaje( "\n\nRepitiendo datos al cliente..." );

      // crea paquete para enviar
      DatagramPacket paqueteEnviar = new DatagramPacket( 
         paqueteRecibir.getData(), paqueteRecibir.getLength(), 
         paqueteRecibir.getAddress(), paqueteRecibir.getPort() );

      socket.send( paqueteEnviar ); // env�a paquete al cliente
      mostrarMensaje( "Paquete enviado\n" );
   } // fin del m�todo enviarPaqueteAlCliente

   // manipula objeto areaPantalla en el subproceso despachador de eventos
   private void mostrarMensaje( final String mensajeAMostrar )
   {
      SwingUtilities.invokeLater(
         new Runnable() 
         {
            public void run() // actualiza areaPantalla
            {
               areaPantalla.append( mensajeAMostrar ); // muestra mensaje
            } // fin del m�todo run
         } // fin de la clase interna an�nima
      ); // fin de la llamada a SwingUtilities.invokeLater
   } // fin del m�todo mostrarMensaje
} // fin de la clase Servidor

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/