// Fig. 24.11: Cliente.java
// Cliente que env�a y recibe paquetes desde/hacia un servidor.
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class Cliente extends JFrame 
{
   private JTextField campoIntroducir; // para introducir mensajes
   private JTextArea areaPantalla; // para mostrar mensajes
   private DatagramSocket socket; // socket para conectarse al servidor

   // establece la GUI y el objeto DatagramSocket
   public Cliente()
   {
      super( "Cliente" );

      campoIntroducir = new JTextField( "Escriba aqui el mensaje" );
      campoIntroducir.addActionListener(
         new ActionListener() 
         { 
            public void actionPerformed( ActionEvent evento )
            {
               try // crea y env�a un paquete
               {
                  // obtiene mensaje del campo de texto
                  String mensaje = evento.getActionCommand();
                  areaPantalla.append( "\nEnviando paquete que contiene: " +
                     mensaje + "\n" );

                  byte datos[] = mensaje.getBytes(); // convierte en bytes
         
                  // crea objeto sendPacket
                  DatagramPacket paqueteEnviar = new DatagramPacket( datos, 
                     datos.length, InetAddress.getLocalHost(), 5000 );

                  socket.send( paqueteEnviar ); // env�a el paquete
                  areaPantalla.append( "Paquete enviado\n" );
                  areaPantalla.setCaretPosition( 
                     areaPantalla.getText().length() );
               } // fin de try
               catch ( IOException excepcionES ) 
               {
                  mostrarMensaje( excepcionES.toString() + "\n" );
                  excepcionES.printStackTrace();
               } // fin de catch
            } // fin de actionPerformed
         } // fin de la clase interna
      ); // fin de la llamada a addActionListener

      add( campoIntroducir, BorderLayout.NORTH );

      areaPantalla = new JTextArea();
      add( new JScrollPane( areaPantalla ), BorderLayout.CENTER );

      setSize( 400, 300 ); // establece el tama�o de la ventana
      setVisible( true ); // muestra la ventana

      try // crea objeto DatagramSocket para enviar y recibir paquetes
      {
         socket = new DatagramSocket();
      } // fin de try
      catch ( SocketException excepcionSocket ) 
      {
         excepcionSocket.printStackTrace();
         System.exit( 1 );
      } // fin de catch
   } // fin del constructor de Cliente

   // espera a que lleguen los paquetes del servidor, muestra el contenido de �stos
   public void esperarPaquetes()
   {
      while ( true ) 
      {
         try // recibe paquete y muestra su contenido
         {
            byte datos[] = new byte[ 100 ]; // establece el paquete
            DatagramPacket paqueteRecibir = new DatagramPacket( 
               datos, datos.length );

            socket.receive( paqueteRecibir ); // espera el paquete

            // muestra el contenido del paquete
            mostrarMensaje( "\nPaquete recibido:" + 
               "\nDe host: " + paqueteRecibir.getAddress() + 
               "\nPuerto host: " + paqueteRecibir.getPort() + 
               "\nLongitud: " + paqueteRecibir.getLength() + 
               "\nContiene:\n\t" + new String( paqueteRecibir.getData(), 
                  0, paqueteRecibir.getLength() ) );
         } // fin de try
         catch ( IOException excepcion ) 
         {
            mostrarMensaje( excepcion.toString() + "\n" );
            excepcion.printStackTrace();
         } // fin de catch
      } // fin de while
   } // fin del m�todo esperarPaquetes

   // manipula objeto areaPantalla en el subproceso despachador de eventos
   private void mostrarMensaje( final String mensajeAMostrar )
   {
      SwingUtilities.invokeLater(
         new Runnable()
         {
            public void run() // actualiza objeto areaPantalla
            {
               areaPantalla.append( mensajeAMostrar );
            } // fin del m�todo run
         }  // fin de la clase interna
      ); // fin de la llamada a SwingUtilities.invokeLater
   } // fin del m�todo mostrarMensaje
}  // fin de la clase Cliente


/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
