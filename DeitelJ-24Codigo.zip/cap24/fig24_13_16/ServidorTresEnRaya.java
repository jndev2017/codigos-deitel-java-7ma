// Fig. 24.13: ServidorTresEnRaya.java
// Esta clase mantiene un juego de Tres en raya para dos clientes.
import java.awt.BorderLayout;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;
import java.util.Formatter;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class ServidorTresEnRaya extends JFrame 
{
   private String[] tablero = new String[ 9 ]; // tablero de tres en raya
   private JTextArea areaSalida; // para imprimir los movimientos en pantalla
   private Jugador[] jugadores; // arreglo de objetos Jugador
   private ServerSocket servidor; // socket servidor para conectarse con los clientes
   private int jugadorActual; // lleva la cuenta del jugador que sigue en turno
   private final static int JUGADOR_X = 0; // constante para el primer jugador
   private final static int JUGADOR_O = 1; // constante para el segundo jugador
   private final static String[] MARCAS = { "X", "O" }; // arreglo de marcas
   private ExecutorService ejecutarJuego; // ejecuta a los jugadores
   private Lock bloqueoJuego; // para bloquear el juego y estar sincronizado
   private Condition otroJugadorConectado; // para esperar al otro jugador
   private Condition turnoOtroJugador; // para esperar el turno del otro jugador

   // establece servidor de tres en raya y GUI para mostrar mensajes en pantalla
   public ServidorTresEnRaya()
   {
      super( "Servidor de Tres en raya" ); // establece el t�tulo de la ventana

      // crea objeto ExecutorService con un subproceso para cada jugador
      ejecutarJuego = Executors.newFixedThreadPool( 2 );
      bloqueoJuego = new ReentrantLock(); // crea bloqueo para el juego

      // variable de condici�n para los dos jugadores conectados
      otroJugadorConectado = bloqueoJuego.newCondition();

      // variable de condici�n para el turno del otro jugador
      turnoOtroJugador = bloqueoJuego.newCondition();      

      for ( int i = 0; i < 9; i++ )
         tablero[ i ] = new String( "" ); // crea tablero de tres en raya
      jugadores = new Jugador[ 2 ]; // crea arreglo de jugadores
      jugadorActual = JUGADOR_X; // establece el primer jugador como el jugador actual
 
      try
      {
         servidor = new ServerSocket( 12345, 2 ); // establece objeto ServerSocket
      } // fin de try
      catch ( IOException excepcionES ) 
      {
         excepcionES.printStackTrace();
         System.exit( 1 );
      } // fin de catch

      areaSalida = new JTextArea(); // crea objeto JTextArea para mostrar la salida
      add( areaSalida, BorderLayout.CENTER );
      areaSalida.setText( "Servidor esperando conexiones\n" );

      setSize( 300, 300 ); // establece el tama�o de la ventana
      setVisible( true ); // muestra la ventana
   } // fin del constructor de ServidorTresEnRaya

   // espera dos conexiones para poder jugar
   public void execute()
   {
      // espera a que se conecte cada cliente
      for ( int i = 0; i < jugadores.length; i++ ) 
      {
         try // espera la conexi�n, crea el objeto Jugador, inicia objeto Runnable
         {
            jugadores[ i ] = new Jugador( servidor.accept(), i );
            ejecutarJuego.execute( jugadores[ i ] ); // ejecuta el objeto Runnable jugador
         } // fin de try
         catch ( IOException excepcionES ) 
         {
            excepcionES.printStackTrace();
            System.exit( 1 );
         } // fin de catch
      } // fin de for

      bloqueoJuego.lock(); // bloquea el juego para avisar al subproceso del jugador X

      try
      {
         jugadores[ JUGADOR_X ].establecerSuspendido( false ); // contin�a el jugador X
         otroJugadorConectado.signal(); // despierta el subproceso del jugador X
      } // fin de try
      finally
      {
         bloqueoJuego.unlock(); // desbloquea el juego despu�s de avisar al jugador X
      } // fin de finally
   } // fin del m�todo execute
   
   // muestra un mensaje en objeto areaSalida
   private void mostrarMensaje( final String mensajeAMostrar )
   {
      // muestra un mensaje del subproceso de ejecuci�n despachador de eventos
      SwingUtilities.invokeLater(
         new Runnable() 
         {
            public void run() // actualiza el objeto areaSalida
            {
               areaSalida.append( mensajeAMostrar ); // agrega el mensaje
            } // fin del m�todo run
         } // fin de la clase interna
      ); // fin de la llamada a SwingUtilities.invokeLater
   } // fin del m�todo mostrarMensaje

   // determina si el movimiento es v�lido
   public boolean validarYMover( int ubicacion, int jugador )
   {
      // mientras no sea el jugador actual, debe esperar su turno
      while ( jugador != jugadorActual ) 
      {
         bloqueoJuego.lock(); // bloquea el juego para esperar a que el otro jugador haga su movmiento

         try 
         {
            turnoOtroJugador.await(); // espera el turno de jugador
         } // fin de try
         catch ( InterruptedException excepcion )
         {
            excepcion.printStackTrace();
         } // fin de catch
         finally
         {
            bloqueoJuego.unlock(); // desbloquea el juego despu�s de esperar
         } // fin de finally
      } // fin de while

      // si la ubicaci�n no est� ocupada, realiza el movimiento
      if ( !estaOcupada( ubicacion ) )
      {
         tablero[ ubicacion ] = MARCAS[ jugadorActual ]; // establece el movimiento en el tablero
         jugadorActual = ( jugadorActual + 1 ) % 2; // cambia el jugador

         // deja que el nuevo jugador sepa que se realiz� un movimiento
         jugadores[ jugadorActual ].otroJugadorMovio( ubicacion );

         bloqueoJuego.lock(); // bloquea el juego para indicar al otro jugador que realice su movimiento

         try 
         {
            turnoOtroJugador.signal(); // indica al otro jugador que debe continuar
         } // fin de try
         finally
         {
            bloqueoJuego.unlock(); // desbloquea el juego despues de avisar
         } // fin de finally

         return true; // notifica al jugador que el movimiento fue v�lido
      } // fin de if
      else // el movimiento no fue v�lido
         return false; // notifica al jugador que el movimiento fue inv�lido
   } // fin del m�todo validarYMover

   // determina si la ubicaci�n est� ocupada
   public boolean estaOcupada( int ubicacion )
   {
      if ( tablero[ ubicacion ].equals( MARCAS[ JUGADOR_X ] ) || 
         tablero [ ubicacion ].equals( MARCAS[ JUGADOR_O ] ) )
         return true; // la ubicaci�n est� ocupada
      else
         return false; // la ubicaci�n no est� ocuapada
   } // fin del m�todo estaOcupada

   // coloca c�digo en este m�todo para determinar si termin� el juego 
   public boolean seTerminoJuego()
   {
      return false; // esto se deja como ejercicio
   } // fin del m�todo seTerminoJuego

   // la clase interna privada Jugador maneja a cada Jugador como objeto Runnable
   private class Jugador implements Runnable 
   {
      private Socket conexion; // conexi�n con el cliente
      private Scanner entrada; // entrada del cliente
      private Formatter salida; // salida al cliente
      private int numeroJugador; // rastrea cu�l jugador es el actual
      private String marca; // marca para este jugador
      private boolean suspendido = true; // indica si el subproceso est� suspendido

      // establece el subproceso Jugador
      public Jugador( Socket socket, int numero )
      {
         numeroJugador = numero; // almacena el n�mero de este jugador
         marca = MARCAS[ numeroJugador ]; // especifica la marca del jugador
         conexion = socket; // almacena socket para el cliente
         
         try // obtiene los flujos del objeto Socket
         {
            entrada = new Scanner( conexion.getInputStream() );
            salida = new Formatter( conexion.getOutputStream() );
         } // fin de try
         catch ( IOException excepcionES ) 
         {
            excepcionES.printStackTrace();
            System.exit( 1 );
         } // fin de catch
      } // fin del constructor de Jugador

      // env�a mensaje que indica que el otro jugador hizo un movimiento
      public void otroJugadorMovio( int ubicacion )
      {
         salida.format( "El oponente realizo movimiento\n" );
         salida.format( "%d\n", ubicacion ); // env�a la ubicaci�n del movimiento
         salida.flush(); // vac�a la salida
      } // fin del m�todo otroJugadorMovio

      // controla la ejecuci�n del subproceso
      public void run()
      {
         // env�a al cliente su marca (X or O), procesa los mensajes del cliente
         try 
         {
            mostrarMensaje( "Jugador " + marca + " conectado\n" );
            salida.format( "%s\n", marca ); // env�a la marca del jugador
            salida.flush(); // vac�a la salida

            // si es el jugador X, espera a que llegue el otro jugador
            if ( numeroJugador == JUGADOR_X ) 
            {
               salida.format( "%s\n%s", "Jugador X conectado",
                  "Esperando al otro jugador\n" );
               salida.flush(); // vac�a la salida

               bloqueoJuego.lock(); // bloquea el juego para esperar al segundo jugador

               try 
               {
                  while( suspendido )
                  {
                     otroJugadorConectado.await(); // espera al jugador O
                  } // fin de while
               } // fin de try 
               catch ( InterruptedException excepcion ) 
               {
                  excepcion.printStackTrace();
               } // fin de catch
               finally
               {
                  bloqueoJuego.unlock(); // desbloquea el juego despu�s del segundo jugador
               } // fin de finally

               // env�a un mensaje que indica que el otro jugador se conect�
               salida.format( "El otro jugador se conecto. Ahora es su turno.\n" );
               salida.flush(); // vac�a la salida
            } // fin de if
            else
            {
               salida.format( "El jugador O se conecto, por favor espere\n" );
               salida.flush(); // vac�a la salida
            } // fin de else

            // mientras el juego no termine
            while ( !seTerminoJuego() ) 
            {
               int ubicacion = 0; // inicializa la ubicaci�n del movimiento

               if ( entrada.hasNext() )
                  ubicacion = entrada.nextInt(); // obtiene la ubicaci�n del movimiento

               // comprueba si el movimiento es v�lido
               if ( validarYMover( ubicacion, numeroJugador ) ) 
               {
                  mostrarMensaje( "\nubicacion: " + ubicacion );
                  salida.format( "Movimiento valido.\n" ); // notifica al cliente
                  salida.flush(); // vac�a la salida
               } // fin de if
               else // el movimiento fue inv�lido
               {
                  salida.format( "Movimiento invalido, intente de nuevo\n" );
                  salida.flush(); // vac�a la salida
               } // fin de else
            } // fin de while
         } // fin de try
         finally
         {
            try
            {
               conexion.close(); // cierra la conexi�n con el cliente
            } // fin de try
            catch ( IOException excepcionES ) 
            {
               excepcionES.printStackTrace();
               System.exit( 1 );
            } // fin de catch
         } // fin de finally
      } // fin del m�todo run

      // establece si se suspende el subproceso o no
      public void establecerSuspendido( boolean estado )
      {
         suspendido = estado; // establece el valor de suspendido
      } // fin del m�todo establecerSuspendido
   } // fin de la clase Jugador
} // fin de la clase ServidorTresEnRaya

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/

