// Fig. 20.10: SumaApplet.java
// Suma de dos n�meros de punto flotante.
import java.awt.Graphics;       // el programa usa la clase Graphics
import javax.swing.JApplet;     // el programa usa la clase JApplet
import javax.swing.JOptionPane; // el programa usa la clase JOptionPane

public class SumaApplet extends JApplet 
{
   private double suma; // suma de los valores introducidos por el usuario

   // inicializa el applet, obteniendo los valores del usuario
   public void init()
   {
      String primerNumero;  // primera cadena introducida por el usuario
      String segundoNumero; // segunda cadena introducida por el usuario

      double numero1; // primer n�mero a sumar
      double numero2; // segundo n�mero a sumar

      // obtiene el primer n�mero del usuario
      primerNumero = JOptionPane.showInputDialog(
         "Escriba el primer valor de punto flotante" );

      // obtiene el segundo n�mero del usuario
      segundoNumero = JOptionPane.showInputDialog(
         "Escriba el segundo valor de punto flotante" );

      // convierte los n�meros del tipo String al tipo double
      numero1 = Double.parseDouble( primerNumero ); 
      numero2 = Double.parseDouble( segundoNumero );

      suma = numero1 + numero2; // suma los n�meros
   } // fin del m�todo init

   // dibuja los resultados en un rect�ngulo, en el fondo del applet
   public void paint( Graphics g )
   {
      super.paint( g ); // llama a la versi�n del m�todo paint de la superclase

      // dibuja un rect�ngulo empezando desde (15, 10), que tenga 270 
      // p�xeles de ancho y 20 p�xeles de alto
      g.drawRect( 15, 10, 270, 20 );

      // dibuja los resultados como un objeto String en (25, 25)
      g.drawString( "La suma es " + suma, 25, 25 );
   } // fin del m�todo paint
} // fin de la clase SumaApplet

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
