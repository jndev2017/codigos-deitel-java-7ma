// Fig. 9.17: PruebaConstructores.java
// Muestra el orden en el que se llaman los constructores de la superclase y la subclase.

public class PruebaConstructores 
{
   public static void main( String args[] )
   {
      EmpleadoPorComision4 empleado1 = new EmpleadoPorComision4( 
         "Bob", "Lewis", "333-33-3333", 5000, .04 );
      
      System.out.println();
      EmpleadoBaseMasComision5 empleado2 = 
         new EmpleadoBaseMasComision5( 
         "Lisa", "Jones", "555-55-5555", 2000, .06, 800 );
      
      System.out.println();
      EmpleadoBaseMasComision5 empleado3 = 
         new EmpleadoBaseMasComision5( 
         "Mark", "Sands", "888-88-8888", 8000, .15, 2000 );
   } // fin de main
} // fin de la clase PruebaConstructores


/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
