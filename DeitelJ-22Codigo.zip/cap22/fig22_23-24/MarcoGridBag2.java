// Fig. 22.23: MarcoGridBag2.java
// Demostraci�n de las constantes de GridBagLayout.
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Component;
import javax.swing.JFrame;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JButton;

public class MarcoGridBag2 extends JFrame 
{ 
   private GridBagLayout esquema; // esquema de este marco
   private GridBagConstraints restricciones; // restricciones de este esquema
    
   // establece la GUI
   public MarcoGridBag2()
   {
      super( "GridBagLayout" );
      esquema = new GridBagLayout();
      setLayout( esquema ); // establece el esquema del marco 
      restricciones = new GridBagConstraints(); // instancia las restricciones

      // crea los componentes de la GUI
      String metales[] = { "Cobre", "Aluminio", "Plata" };
      JComboBox cuadroComb = new JComboBox( metales );

      JTextField campoTexto = new JTextField( "CampoTexto" );

      String fuentes[] = { "Serif", "Monospaced" };
      JList lista = new JList( fuentes );

      String nombres[] = { "cero", "uno", "dos", "tres", "cuatro" };
      JButton botones[] = new JButton[ nombres.length ];

      for ( int cuenta = 0; cuenta < botones.length; cuenta++ )
         botones[ cuenta ] = new JButton( nombres[ cuenta ] );

      // define las restricciones para el componente de la GUI campoTexto
      restricciones.weightx = 1;
      restricciones.weighty = 1;  
      restricciones.fill = GridBagConstraints.BOTH;
      restricciones.gridwidth = GridBagConstraints.REMAINDER;
      agregarComponente( campoTexto );

      // botones[0] -- weightx y weighty son 1: fill es BOTH
      restricciones.gridwidth = 1;
      agregarComponente( botones[ 0 ] );

      // botones[1] -- weightx y weighty son 1: fill es BOTH
      restricciones.gridwidth = GridBagConstraints.RELATIVE;
      agregarComponente( botones[ 1 ] );

      // botones[2] -- weightx y weighty son 1: fill es BOTH
      restricciones.gridwidth = GridBagConstraints.REMAINDER;
      agregarComponente( botones[ 2 ] );

      // cuadroComb -- weightx es 1: fill es BOTH
      restricciones.weighty = 0;
      restricciones.gridwidth = GridBagConstraints.REMAINDER;
      agregarComponente( cuadroComb );
      
      // botones[3] -- weightx es 1: fill es BOTH
      restricciones.weighty = 1;
      restricciones.gridwidth = GridBagConstraints.REMAINDER;
      agregarComponente( botones[ 3 ] ); 

      // botones[4] -- weightx y weighty son 1: fill es BOTH
      restricciones.gridwidth = GridBagConstraints.RELATIVE;
      agregarComponente( botones[ 4 ] );

      // lista -- weightx y weighty son 1: fill es BOTH
      restricciones.gridwidth = GridBagConstraints.REMAINDER;
      agregarComponente( lista );
   } // fin del constructor de MarcoGridBag2

   // agrega un componente al contenedor
   private void agregarComponente( Component componente ) 
   {
      esquema.setConstraints( componente, restricciones );
      add( componente ); // agrega el componente
   } // fin del m�todo agregarComponente
} // fin de la clase MarcoGridBag2

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/