// Fig. 22.13: MarcoJTabbedPane.java
// Demostraci�n de JTabbedPane.
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.SwingConstants;

public class MarcoJTabbedPane extends JFrame  
{
   // establece la GUI
   public MarcoJTabbedPane()
   {
      super( "Demo de JTabbedPane " );

      JTabbedPane panelFichas = new JTabbedPane(); // crea objeto JTabbedPane 

      // establece pane11 y lo agrega al objeto JTabbedPane 
      JLabel etiqueta1 = new JLabel( "panel uno", SwingConstants.CENTER );
      JPanel panel1 = new JPanel(); // crea el primer panel
      panel1.add( etiqueta1 ); // agrega etiqueta al panel
      panelFichas.addTab( "Ficha uno", null, panel1, "Primer panel" ); 
      
      // establece panel2 y lo agrega al objeto JTabbedPane
      JLabel etiqueta2 = new JLabel( "panel dos", SwingConstants.CENTER );
      JPanel panel2 = new JPanel(); // crea el segundo panel
      panel2.setBackground( Color.YELLOW ); // establece el color de fondo en amarillo
      panel2.add( etiqueta2 ); // agrega etiqueta al panel
      panelFichas.addTab( "Ficha dos", null, panel2, "Segundo panel" ); 

      // establece panel3 y lo agrega al objeto JTabbedPane
      JLabel etiqueta3 = new JLabel( "panel tres" );
      JPanel panel3 = new JPanel(); // crea el tercer panel
      panel3.setLayout( new BorderLayout() ); // usa esquema Borderlayout
      panel3.add( new JButton( "Norte" ), BorderLayout.NORTH );
      panel3.add( new JButton( "Oeste" ), BorderLayout.WEST );
      panel3.add( new JButton( "Este" ), BorderLayout.EAST );
      panel3.add( new JButton( "Sur" ), BorderLayout.SOUTH );
      panel3.add( etiqueta3, BorderLayout.CENTER );
      panelFichas.addTab( "Ficha tres", null, panel3, "Tercer panel" );

      add( panelFichas ); // agrega objeto JTabbedPane al marco
   } // fin del constructor de MarcoJTabbedPane
} // fin de la clase MarcoJTabbedPane

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
