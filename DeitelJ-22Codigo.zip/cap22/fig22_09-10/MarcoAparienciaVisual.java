// Fig. 22.9: MarcoAparienciaVisual.java
// Cambio de la apariencia visual.
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JFrame;
import javax.swing.UIManager;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

public class MarcoAparienciaVisual extends JFrame 
{
   // nombres de cadena de las apariencias visuales
   private final String cadenas[] = { "Metal", "Motif", "Windows" };
   private UIManager.LookAndFeelInfo apariencias[]; // apariencias visuales
   private JRadioButton opcion[]; // botones de opci�n para seleccionar la apariencia visual
   private ButtonGroup grupo; // grupo para los botones de opci�n
   private JButton boton; // muestra la apariencia del bot�n
   private JLabel etiqueta; // muestra la apariencia de la etiqueta
   private JComboBox cuadroComb; // muestra la apariencia del cuadro combinado

   // establece la GUI
   public MarcoAparienciaVisual()
   {
      super( "Demo de apariencia visual" );

      JPanel panelNorte = new JPanel(); // crea panel norte
      panelNorte.setLayout( new GridLayout( 3, 1, 0, 5 ) );

      etiqueta = new JLabel( "Esta es una apariencia visual metalica",
         SwingConstants.CENTER ); // crea etiqueta
      panelNorte.add( etiqueta ); // agrega etiqueta al panel

      boton = new JButton( "JButton" ); // crea bot�n
      panelNorte.add( boton ); // agrega bot�n al panel

      cuadroComb = new JComboBox( cadenas ); // crea cuadro combinado
      panelNorte.add( cuadroComb ); // agrega cuadro combinado al panel
     
      // crea arreglo para los botones de opci�n
      opcion = new JRadioButton[ cadenas.length ];

      JPanel panelSur = new JPanel(); // crea panel sur
      panelSur.setLayout( new GridLayout( 1, opcion.length ) );

      grupo = new ButtonGroup(); // grupo de botones para las apariencias visuales
      ManejadorElementos manejador = new ManejadorElementos(); // manejador de apariencia visual

      for ( int cuenta = 0; cuenta < opcion.length; cuenta++ ) 
      {
         opcion[ cuenta ] = new JRadioButton( cadenas[ cuenta ] );
         opcion[ cuenta ].addItemListener( manejador ); // agrega el manejador
         grupo.add( opcion[ cuenta ] ); // agrega bot�n de opci�n al grupo
         panelSur.add( opcion[ cuenta ] ); // agrega bot�n de opci�n al panel
      } // fin de for

      add( panelNorte, BorderLayout.NORTH ); // agrega panel norte
      add( panelSur, BorderLayout.SOUTH ); // agrega panel sur

      // obtiene la informaci�n de la apariencia visual instalada
      apariencias = UIManager.getInstalledLookAndFeels();
      opcion[ 0 ].setSelected( true ); // establece la selecci�n predeterminada
   } // fin del constructor de MarcoAparienciaVisual

   // usa UIManager para cambiar la apariencia visual de la GUI
   private void cambiarAparienciaVisual( int valor )
   {
      try // cambia la apariencia visual
      {
         // establece la apariencia visual para esta aplicaci�n
         UIManager.setLookAndFeel( apariencias[ valor ].getClassName() );

         // actualiza los componentes en esta aplicaci�n
         SwingUtilities.updateComponentTreeUI( this );
      } // fin de try
      catch ( Exception excepcion ) 
      {
         excepcion.printStackTrace();
      } // fin de catch
   } // fin del m�todo cambiarAparienciaVisual

   // clase interna privada para manejar los eventos de los botones de opci�n
   private class ManejadorElementos implements ItemListener 
   {
      // procesa la selecci�n de apariencia visual del usuario
      public void itemStateChanged( ItemEvent evento )
      {
         for ( int cuenta = 0; cuenta < opcion.length; cuenta++ )
         {
            if ( opcion[ cuenta ].isSelected() ) 
            {
               etiqueta.setText( String.format( "Esta es una apariencia visual %s", 
                  cadenas[ cuenta ] ) );
               cuadroComb.setSelectedIndex( cuenta ); // establece el �ndice del cuadro combinado
               cambiarAparienciaVisual( cuenta ); // cambia la apariencia visual
            } // fin de if
         } // fin de for
      } // fin del m�todo itemStateChanged
   } // fin de la clase interna privada ManejadorElementos
} // fin de la clase MarcoAparienciaVisual



/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
