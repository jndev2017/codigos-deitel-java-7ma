// Fig. 22.2: PanelOvalo.java
// Una clase JPanel personalizada.
import java.awt.Graphics;
import java.awt.Dimension;
import javax.swing.JPanel;

public class PanelOvalo extends JPanel 
{
   private int diametro = 10; // diametro predeterminado de 10

   // dibuja un �valo del di�metro especificado
   public void paintComponent( Graphics g )
   {
      super.paintComponent( g );

      g.fillOval( 10, 10, diametro, diametro ); // dibuja un c�rculo
   } // fin del m�todo paintComponent

   // valida y establece el di�metro, despu�s vuelve a pintar
   public void establecerDiametro( int nuevoDiametro )
   {
      // si el di�metro es inv�lido, usa el valor predeterminado de 10
      diametro = ( nuevoDiametro >= 0 ? nuevoDiametro : 10 );
      repaint(); // vuelve a pintar el panel
   } // fin del m�todo establecerDiametro

   // lo utiliza el administrador de esquemas para determinar el tama�o preferido
   public Dimension getPreferredSize()
   {
      return new Dimension( 200, 200 );
   } // fin del m�todo getPreferredSize

   // lo utiliza el administrador de esquemas para determinar el tama�o m�nimo
   public Dimension getMinimumSize()
   {
      return getPreferredSize();
   } // fin del m�todo getMinimumSize
} // fin de la clase PanelOvalo

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/