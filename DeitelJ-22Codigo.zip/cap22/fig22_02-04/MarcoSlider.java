// Fig. 22.3: MarcoSlider.java
// Uso de objetos JSlider para cambiar el tama�o de un �valo.
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JSlider;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

public class MarcoSlider extends JFrame 
{
   private JSlider diametroJSlider; // control deslizable para seleccionar el di�metro
   private PanelOvalo miPanel; // panel para dibujar el c�rculo

   // constructor sin argumentos
   public MarcoSlider() 
   {
      super( "Demostracion de JSlider" );

      miPanel = new PanelOvalo(); // crea panel para dibujar el c�rculo
      miPanel.setBackground( Color.YELLOW ); // establece el color de fondo en amarillo

      // establece objeto JSlider para controlar el valor del di�metro
      diametroJSlider = 
         new JSlider( SwingConstants.HORIZONTAL, 0, 200, 10 );
      diametroJSlider.setMajorTickSpacing( 10 ); // crea un pulso cada 10
      diametroJSlider.setPaintTicks( true ); // pulsos de paint en el control deslizable

      // registra el componente de escucha de eventos del objeto JSlider
      diametroJSlider.addChangeListener(

         new ChangeListener() // clase interna an�nima
         {  
            // maneja el cambio en el valor del control deslizable
            public void stateChanged( ChangeEvent e )
            {
               miPanel.establecerDiametro( diametroJSlider.getValue() );
            } // fin del m�todo stateChanged
         } // fin de la clase interna an�nima
      ); // fin de la llamada a addChangeListener

      add( diametroJSlider, BorderLayout.SOUTH ); // agrega el control deslizable al marco
      add( miPanel, BorderLayout.CENTER ); // agrega el panel al marco
   } // fin del constructor de MarcoSlider
} // fin de la clase MarcoSlider

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/