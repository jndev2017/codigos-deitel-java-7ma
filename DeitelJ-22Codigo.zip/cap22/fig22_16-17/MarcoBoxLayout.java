// Fig. 22.16: MarcoBoxLayout.java
// Demostraci�n de BoxLayout.
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class MarcoBoxLayout extends JFrame 
{
   // establece la GUI
   public MarcoBoxLayout()
   {
      super( "Demostraci�n de BoxLayout" );

      // crea contenedores Box con BoxLayout
      Box horizontal1 = Box.createHorizontalBox();
      Box vertical1 = Box.createVerticalBox();
      Box horizontal2 = Box.createHorizontalBox();
      Box vertical2 = Box.createVerticalBox();

      final int TAMANIO = 3; // n�mero de botones en cada objeto Box

      // agrega botones al objeto Box horizontal1
      for ( int cuenta = 0; cuenta < TAMANIO; cuenta++ )
         horizontal1.add( new JButton( "Boton " + cuenta ) );

      // crea montante y agrega botones al objeto Box vertical1
      for ( int cuenta = 0; cuenta < TAMANIO; cuenta++ ) 
      {
         vertical1.add( Box.createVerticalStrut( 25 ) );
         vertical1.add( new JButton( "Boton " + cuenta ) );
      } // fin de for

      // crea pegamento horizontal y agrega botones al objeto to Box horizontal2
      for ( int cuenta = 0; cuenta < TAMANIO; cuenta++ ) 
      {
         horizontal2.add( Box.createHorizontalGlue() );
         horizontal2.add( new JButton( "Boton " + cuenta ) );
      } // fin de for

      // crea un �rea r�gida y agrega botones al objeto Box vertical2
      for ( int cuenta = 0; cuenta < TAMANIO; cuenta++ ) 
      {
         vertical2.add( Box.createRigidArea( new Dimension( 12, 8 ) ) );
         vertical2.add( new JButton( "Boton " + cuenta ) );
      } // fin de for

      // crea pegamento vertical y agrega botones al panel
      JPanel panel = new JPanel();
      panel.setLayout( new BoxLayout( panel, BoxLayout.Y_AXIS ) );

      for ( int cuenta = 0; cuenta < TAMANIO; cuenta++ ) 
      {
         panel.add( Box.createGlue() );
         panel.add( new JButton( "Boton " + cuenta ) );
      } // fin de for

      // crea un objeto JTabbedPane
      JTabbedPane fichas = new JTabbedPane( 
         JTabbedPane.TOP, JTabbedPane.SCROLL_TAB_LAYOUT ); 

      // coloca cada contenedor en el panel con fichas
      fichas.addTab( "Cuadro horizontal", horizontal1 );
      fichas.addTab( "Cuadro vertical con montantes", vertical1 );
      fichas.addTab( "Cuadro horizontal con pegamento", horizontal2 );
      fichas.addTab( "Cuadro vertical con areas rigidas", vertical2 );
      fichas.addTab( "Cuadro vertical con pegamento", panel );

      add( fichas ); // coloca panel con fichas en el marco
   } // fin del constructor de MarcoBoxLayout
} // fin de la clase MarcoBoxLayout

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/