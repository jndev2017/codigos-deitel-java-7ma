// Fig. 22.7: MarcoContextual.java
// Demostraci�n de los objetos JPopupMenu.
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.ButtonGroup;

public class MarcoContextual extends JFrame 
{
   private JRadioButtonMenuItem elementos[]; // contiene los elementos para los colores
   private final Color valoresColores[] = 
      { Color.BLUE, Color.YELLOW, Color.RED }; // colores a utilizar
   private JPopupMenu menuContextual; // permite al usuario seleccionar el color

   // el constructor sin argumentos establece la GUI
   public MarcoContextual()
   {
      super( "Uso de objetos JPopupMenu" );

      ManejadorElementos manejador = new ManejadorElementos(); // manejador para los elementos de men�
      String colores[] = { "Azul", "Amarillo", "Rojo" }; // arreglo de colores

      ButtonGroup grupoColores = new ButtonGroup(); // administra los elementos de colores
      menuContextual = new JPopupMenu(); // crea el men� contextual
      elementos = new JRadioButtonMenuItem[ 3 ]; // elementos para seleccionar el color

      // construye elemento de men�, lo agrega al men� contextual, habilita el manejo de eventos
      for ( int cuenta = 0; cuenta < elementos.length; cuenta++ ) 
      {
         elementos[ cuenta ] = new JRadioButtonMenuItem( colores[ cuenta ] );
         menuContextual.add( elementos[ cuenta ] ); // agrega elemento al men� contextual
         grupoColores.add( elementos[ cuenta ] ); // agrega elemento al grupo de botones
         elementos[ cuenta ].addActionListener( manejador ); // agrega el manejador
      } // fin de for

      setBackground( Color.WHITE ); // establece el color de fondo en blanco

      // declara un objeto MouseListener para que la ventana muestre el men� contextual
      addMouseListener(

         new MouseAdapter() // clase interna an�nima
         {  
            // maneja el evento de oprimir el bot�n del rat�n
            public void mousePressed( MouseEvent evento )
            { 
               checkForTriggerEvent( evento ); // comprueba el desencadenador
            } // fin del m�todo mousePressed

            // maneja el evento de liberaci�n del bot�n del rat�n
            public void mouseReleased( MouseEvent evento )
            { 
               checkForTriggerEvent( evento ); // comprueba el desencadenador
            } // fin del m�todo mouseReleased

            // determina si el evento debe desencadenar el men� contextual
            private void checkForTriggerEvent( MouseEvent evento )
            {
               if ( evento.isPopupTrigger() ) 
                  menuContextual.show( 
                     evento.getComponent(), evento.getX(), evento.getY() );  
            } // fin del m�todo checkForTriggerEvent
         } // fin de la clase interna an�nima
      ); // fin de la llamada a addMouseListener
   } // fin del constructor de MarcoContextual

   // clase interna privada para manejar los eventos de los elementos de men�
   private class ManejadorElementos implements ActionListener 
   {
      // procesa las selecciones de los elementos de men�
      public void actionPerformed( ActionEvent evento )
      {
         // determina cu�l elemento de men� se seleccion�
         for ( int i = 0; i < elementos.length; i++ )
         {
            if ( evento.getSource() == elementos[ i ] ) 
            {
               getContentPane().setBackground( valoresColores[ i ] );
               return;
            } // fin de if
         } // fin de for
      } // fin del m�todo actionPerformed
   } // fin de la clase interna privada ManejadorElementos
} // fin de la clase MarcoContextual

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
