// Fig. 21.1: CargarImagenYEscalar.java
// Carga una imagen y la muestra en su tama�o original y al doble de su
// tama�o original. Carga y muestra la misma imagen como un objeto ImageIcon.
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JApplet;

public class CargarImagenYEscalar extends JApplet 
{
   private Image imagen1; // crea un objeto Image 
   private ImageIcon imagen2; // crea un objeto ImageIcon

   // carga la imagen cuando se carga el applet
   public void init()
   {
      imagen1 = getImage( getClass().getResource( "floresrojas.png" ) ); //getDocumentBase(), "floresrojas.png" );
      imagen2 = new ImageIcon( getClass().getResource( "floresamarillas.png" ) ); //"floresamarillas.png" );
   } // fin del m�todo init

   // muestra la imagen
   public void paint( Graphics g )
   {
      super.paint( g );

      g.drawImage( imagen1, 0, 0, this ); // dibuja la imagen original

      // dibuja la imagen para que se ajuste a la anchura y altura menos 120 p�xeles
      g.drawImage( imagen1, 0, 120, getWidth(), getHeight() - 120, this );

      // dibuja un icono, usando su m�todo paintIcon
      imagen2.paintIcon( this, g, 180, 0 );
   } // fin del m�todo paint
} // fin de la clase CargarImagenYEscalar


/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
