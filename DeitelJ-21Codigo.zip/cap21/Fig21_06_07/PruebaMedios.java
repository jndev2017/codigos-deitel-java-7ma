// Fig. 21.7: PruebaMedios.java
// Un reproductor de medios simple
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

public class PruebaMedios
{
   // inicia la aplicaci�n
   public static void main( String args[] )
   {
      // crea un selector de archivo
      JFileChooser selectorArchivo = new JFileChooser();
      
      // muestra cuadro de di�logo para abrir archivo
      int resultado = selectorArchivo.showOpenDialog( null );

      if ( resultado == JFileChooser.APPROVE_OPTION ) // el usuario eligi� un archivo
      {
         URL urlMedios = null;
         
         try
         {
            // obtiene el archivo como un URL
            urlMedios = selectorArchivo.getSelectedFile().toURL();
         } // fin de try
         catch ( MalformedURLException malformedURLException )
         {
            System.err.println( "No se puedo crear URL para el archivo" );
         } // fin de catch

         if ( urlMedios != null ) // s�lo lo muestra si hay un URL v�lido
         {
            JFrame pruebaMedios = new JFrame( "Probador de medios" );
            pruebaMedios.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
            
            PanelMedios panelMedios = new PanelMedios( urlMedios );
            pruebaMedios.add( panelMedios );
            
            pruebaMedios.setSize( 300, 300 );
            pruebaMedios.setVisible( true );
         } // fin de if interior
      } // fin de if exterior
   } // fin de main
} // fin de la clase PruebaMedios

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/