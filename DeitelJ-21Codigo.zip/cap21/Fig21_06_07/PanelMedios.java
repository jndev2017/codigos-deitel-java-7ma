// Fig 21.6: PanelMedios.java
// Un objeto JPanel que reproduce medios de un URL
import java.awt.BorderLayout;
import java.awt.Component;
import java.io.IOException;
import java.net.URL;
import javax.media.CannotRealizeException;
import javax.media.Manager;
import javax.media.NoPlayerException;
import javax.media.Player;
import javax.swing.JPanel;

public class PanelMedios extends JPanel
{
   public PanelMedios( URL urlMedios )
   {
      setLayout( new BorderLayout() ); // usa un objeto BorderLayout
      
      // Usa componentes ligeros para compatibilidad con Swing
      Manager.setHint( Manager.LIGHTWEIGHT_RENDERER, true );
      
      try
      {
         // crea un objeto Player para reproducir los medios especificados en el URL
         Player reproductorMedios = Manager.createRealizedPlayer( urlMedios );
         
         // obtiene los componentes para el video y los controles de reproducci�n
         Component video = reproductorMedios.getVisualComponent();
         Component controles = reproductorMedios.getControlPanelComponent();
         
         if ( video != null ) 
            add( video, BorderLayout.CENTER ); // agrega el componente de video

         if ( controles != null ) 
            add( controles, BorderLayout.SOUTH ); // agrega los controles
         
         reproductorMedios.start(); // empieza a reproducir el clip de medios
      } // fin de try
      catch ( NoPlayerException noPlayerException )
      {
         System.err.println( "No se encontro reproductor de medios" );
      } // fin de catch
      catch ( CannotRealizeException cannotRealizeException )
      {
         System.err.println( "No se puedo realizar el reproductor de medios" );
      } // fin de catch
      catch ( IOException iOException )
      {
         System.err.println( "Error al leer del origen" );
      } // fin de catch
   } // fin del constructor de PanelMedios
} // fin de la clase PanelMedios

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/