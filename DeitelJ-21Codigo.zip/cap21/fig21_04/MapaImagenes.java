// Fig. 21.4: MapaImagenes.java
// Demostraci�n de un mapa de im�genes.
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JApplet;

public class MapaImagenes extends JApplet 
{
   private ImageIcon imagenMapa;

   private static final String leyendas[] = { "Error comun de programacion",
      "Buena practica de programacion", "Observacion de apariencia visual", 
      "Tip de rendimiento", "Tip de portabilidad", 
      "Observacion de Ingenieria de Software", "Tip para prevenir errores" };

   // establece los componentes de escucha del rat�n
   public void init()
   {
      addMouseListener(

         new MouseAdapter() // clase interna an�nima
         { 
            // indica cuando el puntero del rat�n sale del �rea del applet
            public void mouseExited( MouseEvent evento )
            {
               showStatus( "Apuntador fuera de applet" );
            } // fin del m�todo mouseExited
         } // fin de la clase interna an�nima
      ); // fin de la llamada a addMouseListener

      addMouseMotionListener(

         new MouseMotionAdapter() // clase interna an�nima
         { 
            // determina el �cono sobre el cual aparece el rat�n
            public void mouseMoved( MouseEvent evento )
            {
               showStatus( traducirPosicion(
                  evento.getX(), evento.getY() ) );
            } // fin del m�todo mouseMoved
         } // fin de la clase interna an�nima
      ); // fin de la llamada a addMouseMotionListener

      imagenMapa = new ImageIcon( "iconos.png" ); // obtiene la imagen
   } // fin del m�todo init

   // muestra imagenMapa
   public void paint( Graphics g )
   {
      super.paint( g );
      imagenMapa.paintIcon( this, g, 0, 0 );
   } // fin del m�todo paint

   // devuelve leyenda del tip correspondiente, con base en las coordenadas del rat�n
   public String traducirPosicion( int x, int y )
   {
      // si las coordenadas est�n fuera de la imagen, regresa de inmediato
      if ( x >= imagenMapa.getIconWidth() || y >= imagenMapa.getIconHeight() ) 
         return "";

      // determina el n�mero del �cono (0 - 6)
      double anchuraIcono = ( double ) imagenMapa.getIconWidth() / 7.0;
      int numeroIcono = ( int )( ( double ) x / anchuraIcono );

      return leyendas[ numeroIcono ]; // devuelve la leyenda del �cono apropiado
   } // fin del m�todo traducirPosicion
} // fin de la clase MapaImagenes

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
