// Fig. 21.2: AnimadorLogoJPanel.java
// Animaci�n de una serie de im�genes.
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;

public class AnimadorLogoJPanel extends JPanel 
{
   private final static String NOMBRE_IMAGEN = "deitel"; // nombre de la imagen base
   protected ImageIcon imagenes[]; // arreglo de im�genes
   private final int TOTAL_IMAGENES = 30;  // n�mero de im�genes
   private int imagenActual = 0; // �ndice de la imagen actual
   private final int RETRASO_ANIMACION = 50; // retraso en  milisegundos
   private int anchura; // anchura de la imagen
   private int altura; // altura de la imagen

   private Timer temporizadorAnimacion; // objeto Timer que controla la animaci�n

   // el constructor inicializa el objeto AnimadorLogoJPanel, cargando las im�genes
   public AnimadorLogoJPanel()
   {
      imagenes = new ImageIcon[ TOTAL_IMAGENES ];

      // carga 30 im�genes
      for ( int cuenta = 0; cuenta < imagenes.length; cuenta++ )
         imagenes[ cuenta ] = new ImageIcon( getClass().getResource(
            "imagenes/" + NOMBRE_IMAGEN + cuenta + ".gif" ) );
 
      // este ejemplo supone que todas las im�genes tienen la misma anchura y altura
      anchura = imagenes[ 0 ].getIconWidth();   // obtiene la anchura del icono
      altura = imagenes[ 0 ].getIconHeight(); // obtiene la altura del icono
   } // fin del constructor de AnimadorLogoJPanel

   // muestra la imagen actual
   public void paintComponent( Graphics g )
   {
      super.paintComponent( g ); // llama al m�todo paintComponent de la superclase

      imagenes[ imagenActual ].paintIcon( this, g, 0, 0 );
      
      // establece la siguiente imagen a dibujar, s�lo si el temporizador est� funcionando
      if ( temporizadorAnimacion.isRunning() )  
         imagenActual = ( imagenActual + 1 ) % TOTAL_IMAGENES;
   } // fin del m�todo paintComponent

   // inicia la animaci�n, o la reinicia si se vuelve a mostrar la ventana
   public void iniciarAnimacion()
   {
      if ( temporizadorAnimacion == null ) 
      {
         imagenActual = 0; // muestra la primera imagen

         // crea temporizador
         temporizadorAnimacion = 
            new Timer( RETRASO_ANIMACION, new ManejadorTimer() );

         temporizadorAnimacion.start(); // inicia el objeto Timer
      } // fin de if
      else // temporizadorAnimacion ya existe; reinicia la animaci�n
      {
         if ( ! temporizadorAnimacion.isRunning() )
            temporizadorAnimacion.restart();
      } // fin de else
   } // fin del m�todo iniciarAnimacion

   // detiene el temporizador de la animaci�n
   public void detenerAnimacion()
   {
      temporizadorAnimacion.stop();
   } // fin del m�todo detenerAnimacion

   // devuelve el tama�o m�nimo de la animaci�n
   public Dimension getMinimumSize()
   { 
      return getPreferredSize(); 
   } // fin del m�todo getMinimumSize

   // devuelve el tama�o preferido de la animaci�n
   public Dimension getPreferredSize()
   {
      return new Dimension( anchura, altura );
   } // fin del m�todo getPreferredSize

   // clase interna para manejar los eventos de acci�n del objeto Timer
   private class ManejadorTimer implements ActionListener 
   {
      // responde a un evento del objeto Timer
      public void actionPerformed( ActionEvent actionEvent )
      {
         repaint(); // vuelve a dibujar la animaci�n
      } // fin del m�todo actionPerformed
   } // fin de la clase ManejadorTimer
} // fin de la clase AnimadorLogoJPanel

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
