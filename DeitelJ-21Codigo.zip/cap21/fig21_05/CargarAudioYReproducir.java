// Fig. 21.5: CargarAudioYReproducir.java
// Carga un clip de audio y lo reproduce.
import java.applet.AudioClip;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JComboBox;

public class CargarAudioYReproducir extends JApplet 
{
   private AudioClip sonido1, sonido2, sonidoActual;  
   private JButton reproducirJButton, continuoJButton, detenerJButton;
   private JComboBox sonidoJComboBox;

   // carga la imagen cuando el applet empieza a ejecutarse
   public void init()
   {
      setLayout( new FlowLayout() );

      String opciones[] = { "Welcome", "Hi" };
      sonidoJComboBox = new JComboBox( opciones ); // crea objeto JComboBox

      sonidoJComboBox.addItemListener(

         new ItemListener() // clase interna an�nima
         {
            // detiene el sonido y lo cambia por la selecci�n del usuario
            public void itemStateChanged( ItemEvent e )
            {
               sonidoActual.stop();
               sonidoActual = sonidoJComboBox.getSelectedIndex() == 0 ? 
                  sonido1 : sonido2;
            } // fin del m�todo itemStateChanged
         } // fin de la clase interna an�nima
      ); // fin de la llamada al m�todo addItemListener

      add( sonidoJComboBox ); // agrega objeto JComboBox al applet

      // establece el manejador de eventos de bot�n y los botones
      ManejadorBoton manejador = new ManejadorBoton();

      // crea objeto JButton Reproducir
      reproducirJButton = new JButton( "Reproducir" );
      reproducirJButton.addActionListener( manejador );
      add( reproducirJButton );

      // crea objeto JButton Continuo
      continuoJButton = new JButton( "Continuo" );
      continuoJButton.addActionListener( manejador );
      add( continuoJButton );

      // crea JButton Detener
      detenerJButton = new JButton( "Stop" );
      detenerJButton.addActionListener( manejador );
      add( detenerJButton );

      // carga los sonidos y establecet sonidoActual
      sonido1 = getAudioClip( getDocumentBase(), "welcome.wav" );
      sonido2 = getAudioClip( getDocumentBase(), "hi.au" );
      sonidoActual = sonido1;
   } // fin del m�todo init

   // detiene el sonido cuando el usuario cambia a otra p�gina Web
   public void stop()
   {
      sonidoActual.stop(); // detener AudioClip
   } // fin del m�todo stop

   // clase interna privada para manejar eventos de bot�n
   private class ManejadorBoton implements ActionListener 
   {
      // procesa los eventos de los botones reproducir, continuo y detener
      public void actionPerformed( ActionEvent actionEvent )
      {
         if ( actionEvent.getSource() == reproducirJButton ) 
            sonidoActual.play(); // reproducir AudioClip una vez
         else if ( actionEvent.getSource() == continuoJButton ) 
            sonidoActual.loop(); // reproducir AudioClip en forma continua
         else if ( actionEvent.getSource() == detenerJButton ) 
            sonidoActual.stop(); // detener AudioClip
      } // fin del m�todo actionPerformed
   } // fin de la clase ManejadorBoton
} // fin de la clase CargarAudioYReproducir

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/

