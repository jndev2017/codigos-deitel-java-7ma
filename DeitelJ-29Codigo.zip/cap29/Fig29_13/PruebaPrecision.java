// Fig 29.13: PruebaPrecision.java
// Uso de la precisi�n para n�meros de punto flotante y cadenas.
public class PruebaPrecision 
{
   public static void main( String args[] )
   { 
      double f = 123.94536; 
      String s = "Feliz Cumpleanios"; 

      System.out.printf( "Uso de la precision para numeros de punto flotante\n" );
      System.out.printf( "\t%.3f\n\t%.3e\n\t%.3g\n\n", f, f, f );  
   
      System.out.printf( "Uso de la precision para las cadenas\n" );
      System.out.printf( "\t%.11s\n", s );
   } // fin de main 
} // fin de la clase PruebaPrecision


/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/

