// Fig. 29.11: OtrasConversiones.java
// Uso de los caracteres de conversi�on b, B, h, H, % y n.

public class OtrasConversiones 
{
   public static void main( String args[] ) 
   {
      Object prueba = null;
      System.out.printf( "%b\n", false );
      System.out.printf( "%b\n", true );
      System.out.printf( "%b\n", "Prueba" );
      System.out.printf( "%B\n", prueba );
      System.out.printf( "El codigo hash de \"hola\" es %h\n", "hola" );
      System.out.printf( "El codigo hash de \"Hola\" es %h\n", "Hola" );
      System.out.printf( "El codigo hash de null es %H\n", prueba );
      System.out.printf( "Impresion de un %% en una cadena de formato\n" );
      System.out.printf( "Impresion de una nueva linea %nla siguiente linea empieza aqui" );
   } // fin de main
} // fin de la clase OtrasConversiones

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/

