// Fig. 26.22: Opciones.java
// Bean de p�gina que almacena la selecci�n de lenguaje del usuario como
// una cookie en el cliente.
package cookies;

import com.sun.rave.web.ui.appbase.AbstractPageBean;
import com.sun.rave.web.ui.component.Body;
import com.sun.rave.web.ui.component.Form;
import com.sun.rave.web.ui.component.Head;
import com.sun.rave.web.ui.component.Html;
import com.sun.rave.web.ui.component.Link;
import com.sun.rave.web.ui.component.Page;
import javax.faces.FacesException;
import com.sun.rave.web.ui.component.StaticText;
import com.sun.rave.web.ui.component.Label;
import com.sun.rave.web.ui.component.RadioButtonGroup;
import com.sun.rave.web.ui.model.SingleSelectOptionsList;
import com.sun.rave.web.ui.component.Hyperlink;
import com.sun.rave.web.ui.component.Button;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Cookie;
import java.util.Properties;

public class Opciones extends AbstractPageBean
{
   private int __placeholder;
   
   // el m�todo _init inicializa los componentes y establece
   // las opciones para el grupo de botones de selecci�n.
   private void _init() throws Exception
   {
      listaLenguajesDefaultOptions.setOptions(
        new com.sun.rave.web.ui.model.Option[] 
        {
            new com.sun.rave.web.ui.model.Option("Java","Java"),
            new com.sun.rave.web.ui.model.Option("C","C"),
            new com.sun.rave.web.ui.model.Option("C++","C++"),
            new com.sun.rave.web.ui.model.Option("Visual/Basic/2005",
                "Visual Basic 2005"),
            new com.sun.rave.web.ui.model.Option("Visual/C#/2005",
                "Visual C# 2005") 
        }
      );
   } // fin del m�todo _init
   
   private Page page = new Page();
   
   public Page getPage()
   {
      return page;
   } // fin del m�todo getPage
   
   public void setPage( Page p )
   {
      this.page = p;
   } // fin del m�todo setPage
   
   private Html html = new Html();
   
   public Html getHtml()
   {
      return html;
   } // fin del m�todo getHtml
   
   public void setHtml( Html h )
   {
      this.html = h;
   } // fin del m�todo setHtml
   
   private Head head = new Head();
   
   public Head getHead()
   {
      return head;
   } // fin del m�todo getHead1
   
   public void setHead( Head h )
   {
      this.head = h;
   } // fin del m�todo setHead
   
   private Link link = new Link();
   
   public Link getLink()
   {
      return link;
   } // fin del m�todo getLink
   
   public void setLink( Link l )
   {
      this.link = l;
   } // fin del m�todo setLink
   
   private Body body = new Body();
   
   public Body getBody()
   {
      return body;
   } // fin del m�todo getBody
   
   public void setBody( Body b )
   {
      this.body = b;
   } // fin del m�todo setBody
   
   private Form form = new Form();
   
   public Form getForm()
   {
      return form;
   } // fin del m�todo getForm
   
   public void setForm( Form f )
   {
      this.form = f;
   }  // fin del m�todo setForm
   
   private Label etiquetaLenguaje = new Label();
   
   public Label getEtiquetaLenguaje()
   {
      return etiquetaLenguaje;
   } // fin del m�todo getEtiquetaLenguaje
   
   public void setEtiquetaLenguaje( Label l )
   {
      this.etiquetaLenguaje = l;
   } // fin del m�todo setEtiquetaLenguaje
   
   private RadioButtonGroup listaLenguajes = new RadioButtonGroup();
   
   public RadioButtonGroup getListaLenguajes()
   {
      return listaLenguajes;
   } // fin del m�todo getListaLenguajes
   
   public void setListaLenguajes( RadioButtonGroup rbg )
   {
      this.listaLenguajes = rbg;
   } // fin del m�todo setListaLenguajes
   
   private SingleSelectOptionsList listaLenguajesDefaultOptions =
      new SingleSelectOptionsList();
   
   public SingleSelectOptionsList getListaLenguajesDefaultOptions()
   {
      return listaLenguajesDefaultOptions;
   } // fin del m�todo getListaLenguajesDefaultOptions
   
   public void setListaLenguajesDefaultOptions(
      SingleSelectOptionsList ssol )
   {
      this.listaLenguajesDefaultOptions = ssol;
   } // fin del m�todo setListaLenguajesDefaultOptions
   
   private StaticText etiquetaRespuesta = new StaticText();
   
   public StaticText getEtiquetaRespuesta()
   {
      return etiquetaRespuesta;
   } // fin del m�todo getResponseLabel
   
   public void setEtiquetaRespuesta( StaticText st )
   {
      this.etiquetaRespuesta = st;
   } // fin del m�todo setEtiquetaRespuesta
   
   private Hyperlink vinculoLenguajes = new Hyperlink();
   
   public Hyperlink getVinculoLenguajes()
   {
      return vinculoLenguajes;
   } // fin del m�todo getVinculoLenguajes
   
   public void setVinculoLenguajes( Hyperlink h )
   {
      this.vinculoLenguajes = h;
   } // fin del m�todo setVinculoLenguajes
   
   private Hyperlink vinculoRecomendaciones = new Hyperlink();
   
   public Hyperlink getVinculoRecomendaciones()
   {
      return vinculoRecomendaciones;
   } // fin del m�todo getVinculoRecomendaciones
   
   public void setVinculoRecomendaciones( Hyperlink h )
   {
      this.vinculoRecomendaciones = h;
   } // fin del m�todo setVinculoRecomendaciones
   
   private Button enviar = new Button();
   
   public Button getEnviar()
   {
      return enviar;
   } // fin del m�todo getEnviar
   
   public void setEnviar( Button b )
   {
      this.enviar = b;
   } // fin del m�todo setEnviar
   
   private Properties libros = new Properties();
   
   // Construye una nueva instancia del bean de p�gina e inicializa las propiedades
   // que asocian los lenguajes con los n�meros ISBN de los libros recomendados.
   public Opciones()
   {
      // inicializa el objeto Properties de los valores que se van
      // a almacenar como cookies.
      libros.setProperty( "Java", "0-13-222220-5" );
      libros.setProperty( "C", "0-13-142644-3" );
      libros.setProperty( "C++", "0-13-185757-6" );
      libros.setProperty( "Visual/Basic/2005", "0-13-186900-0" );
      libros.setProperty( "Visual/C#/2005", "0-13-152523-9" );
   } // fin del constructor de Opciones
   
   protected ApplicationBean getApplicationBean()
   {
      return (ApplicationBean) getBean( "ApplicationBean" );
   } // fin del m�todo getApplicationBean
   
   protected RequestBean getRequestBean()
   {
      return (RequestBean) getBean( "RequestBean" );
   } // fin del m�todo getRequestBean
   
   protected SessionBean getSessionBean()
   {
      return (SessionBean) getBean( "SessionBean" );
   } // fin del m�todo getSessionBean
   
   public void init()
   {
      super.init();
      try
      {
         _init();
      } // fin de try
      catch ( Exception e )
      {
         log( "Error al inicializar Opciones", e );
         throw e instanceof FacesException ? ( FacesException ) e:
            new FacesException( e );
      } // fin de catch
   } // fin del m�todo init
   
   public void preprocess()
   {
      // cuerpo vac�o
   } // fin del m�todo preprocess
   
   public void prerender()
   {
      // cuerpo vac�o
   } // fin del m�todo prerender
   
   public void destroy()
   {
      // cuerpo vac�o
   } // fin del m�todo destroy
   
   // Manejador de acciones para el bot�n Enviar. Verifica si se seleccion� un
   // lenguaje y, de ser as�, registra una cookie para ese lenguaje, y 
   // establece la etiquetaRespuesta para indicar el lenguaje seleccionado.
   public String enviar_action()
   {
      String msj = "Bienvenido a Cookies!  Usted ";
      
      // si el usuario hizo una selecci�n
      if ( listaLenguajes.getSelected() != null )
      {
         String lenguaje = listaLenguajes.getSelected().toString();
         String mostrarLenguaje = lenguaje.replace( '/', ' ' );
         msj += "selecciono " + mostrarLenguaje + ".";
         
         // obtiene el n�mero ISBN del libro para el lenguaje dado.
         String ISBN = libros.getProperty( lenguaje );
         
         // crea cookie usando un par nombre-valor de lenguaje-ISBN
         Cookie cookie = new Cookie( lenguaje, ISBN );
         
         // agrega la cookie al encabezado de respuesta para colocarla en
         // el equipo del usuario
         HttpServletResponse respuesta =
            (HttpServletResponse) getExternalContext().getResponse();
         respuesta.addCookie( cookie );
      } // fin de if
      else
         msj += "no selecciono un lenguaje.";
      
      etiquetaRespuesta.setValue(msj);
      listaLenguajes.setRendered(false);
      etiquetaLenguaje.setRendered(false);
      enviar.setRendered(false);
      etiquetaRespuesta.setRendered(true);
      vinculoLenguajes.setRendered(true);
      vinculoRecomendaciones.setRendered(true);
      return null; // vuelve a cargar la p�gina
   } // fin del m�todo enviar_action
   
   // vuelve a mostrar los componentes utilizados para permitir al usuario 
   // seleccionar un lenguaje.
   public String vinculoLenguajes_action()
   {
      etiquetaRespuesta.setRendered(false);
      vinculoLenguajes.setRendered(false);
      vinculoRecomendaciones.setRendered(false);
      listaLenguajes.setRendered(true);
      etiquetaLenguaje.setRendered(true);
      enviar.setRendered(true);
       return null;
   } // fin del m�todo vinculoLenguajes_action
} // end class Opciones

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/