// Fig. 26.24: Recomendaciones.java
// Bean de pagina que muestra las recomendaciones de libros con base en cookies
// que almacenan los lenguajes de programaci�n seleccionados por el usuario.
package cookies;

import com.sun.rave.web.ui.appbase.AbstractPageBean;
import com.sun.rave.web.ui.component.Body;
import com.sun.rave.web.ui.component.Form;
import com.sun.rave.web.ui.component.Head;
import com.sun.rave.web.ui.component.Html;
import com.sun.rave.web.ui.component.Link;
import com.sun.rave.web.ui.component.Page;
import javax.faces.FacesException;
import com.sun.rave.web.ui.component.Listbox;
import com.sun.rave.web.ui.model.DefaultOptionsList;
import com.sun.rave.web.ui.component.Label;
import com.sun.rave.web.ui.component.Hyperlink;
import com.sun.rave.web.ui.model.Option;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Cookie;
import com.sun.rave.web.ui.component.HiddenField;

public class Recomendaciones extends AbstractPageBean
{
   private int __placeholder;
   
   private void _init() throws Exception
   {
      // cuerpo vac�o
   } // fin del m�todo _init()
   
   private Page page = new Page();
   
   public Page getPage()
   {
      return page;
   } // fin del m�todo getPage
   
   public void setPage(Page p)
   {
      this.page = p;
   } // fin del m�todo setPage
   
   private Html html = new Html();
   
   public Html getHtml()
   {
      return html;
   } // fin del m�todo getHtml
   
   public void setHtml(Html h)
   {
      this.html = h;
   } // fin del m�todo setHtml
   
   private Head head = new Head();
   
   public Head getHead()
   {
      return head;
   } // fin del m�todo getHead
   
   public void setHead(Head h)
   {
      this.head = h;
   } // fin del m�todo setHead
   
   private Link link = new Link();
   
   public Link getLink()
   {
      return link;
   } // fin del m�todo getLink
   
   public void setLink(Link l)
   {
      this.link = l;
   } // fin del m�todo setLink
   
   private Body body = new Body();
   
   public Body getBody()
   {
      return body;
   } // fin del m�todo getBody
   
   public void setBody(Body b)
   {
      this.body = b;
   } // fin del m�todo setBody
   
   private Form form = new Form();
   
   public Form getForm()
   {
      return form;
   } // fin del m�todo getForm
   
   public void setForm(Form f)
   {
      this.form = f;
   } // fin del m�todo setForm
   
   private Listbox cuadroListaLibros = new Listbox();
   
   public Listbox getCuadroListaLibros()
   {
      return cuadroListaLibros;
   } // fin del m�todo getCuadroListaLibros
   
   public void setCuadroListaLibros(Listbox l)
   {
      this.cuadroListaLibros = l;
   } // fin del m�todo setCuadroListaLibros
   
   private DefaultOptionsList cuadroListaLibrosOpciones = new DefaultOptionsList();
   
   public DefaultOptionsList getCuadroListaLibrosOpciones()
   {
      return cuadroListaLibrosOpciones;
   } // fin del m�todo getCuadroListaLibrosOpciones
   
   public void setCuadroListaLibrosOpciones(DefaultOptionsList dol)
   {
      this.cuadroListaLibrosOpciones = dol;
   } // fin del m�todo setCuadroListaLibrosOpciones
   
   private Label etiquetaLenguaje = new Label();
   
   public Label getEtiquetaLenguaje()
   {
      return etiquetaLenguaje;
   } // fin del m�todo getEtiquetaLenguaje
   
   public void setEtiquetaLenguaje(Label l)
   {
      this.etiquetaLenguaje = l;
   } // fin del m�todo setEtiquetaLenguaje
   
   private Hyperlink vinculoOpciones = new Hyperlink();
   
   public Hyperlink getVinculoOpciones()
   {
      return vinculoOpciones;
   } // fin del m�todo getVinculoOpciones
   
   public void setVinculoOpciones(Hyperlink h)
   {
      this.vinculoOpciones = h;
   }
   
   public Recomendaciones()
   {
      // constructor vac�o
   } // fin del constructor
   
   protected ApplicationBean getApplicationBean()
   {
      return (ApplicationBean) getBean( "ApplicationBean" );
   } // fin del m�todo getApplicationBean
   
   protected RequestBean getRequestBean()
   {
      return (RequestBean) getBean( "RequestBean" );
   } // fin del m�todo getRequestBean
   
   protected SessionBean getSessionBean()
   {
      return (SessionBean) getBean( "SessionBean" );
   } // fin del m�todo getSessionBean
   
   public void init()
   {
      super.init();
      try
      {
         _init();
      } // fin de try
      catch ( Exception e )
      {
         log( "Error al inicializar Recomendaciones", e );
         throw e instanceof FacesException ? (FacesException) e:
            new FacesException( e );
      } // fin de catch
   } // fin del m�todo init
   
   public void preprocess()
   {
      // cuerpo vac�o
   } // fin del m�todo preprocess
   
   public void prerender()
   {
      // obtiene las cookies del cliente
      HttpServletRequest peticion =
         (HttpServletRequest)getExternalContext().getRequest();
      Cookie [] cookies = peticion.getCookies();
      
      // si hay cookies, almacena los correspondientes libros y
      // n�meros ISBN en un arreglo de Opciones
      Option [] recomendaciones;

      if ( cookies.length > 1 )
      {
         recomendaciones = new Option[ cookies.length - 1 ];
         for ( int i = 0; i < cookies.length - 1; i++ )
         {
            String lenguaje =
               cookies[i].getName().replace( '/', ' ' );
            recomendaciones[ i ] = new Option( lenguaje + 
               " How to Program.  ISBN#: " + cookies[i].getValue() );
         } // fin de for
      } // fin de if
      
      // en caso contrario, almacena un mensaje indicando que no se seleccion� un lenguaje
      else
      {
         recomendaciones = new Option[ 1 ];
         recomendaciones[ 0 ] = new Option( 
            "No hay recomendaciones. Seleccione un lenguaje." ) ;
      } // fin de else
      
      cuadroListaLibros.setItems(recomendaciones);
   } // fin del m�todo prerender
   
   public void destroy()
   {
      // cuerpo vac�o
   } // fin del m�todo destroy
} // fin de la clase Recomendaciones

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/