// Fig. 26.32: Recomendaciones.java
// Bean de p�gina que muestra las recomendaciones de libros con base en
// una propiedad de un objeto SessionBean.
package sesion;

import com.sun.rave.web.ui.appbase.AbstractPageBean;
import com.sun.rave.web.ui.component.Body;
import com.sun.rave.web.ui.component.Form;
import com.sun.rave.web.ui.component.Head;
import com.sun.rave.web.ui.component.Html;
import com.sun.rave.web.ui.component.Link;
import com.sun.rave.web.ui.component.Page;
import javax.faces.FacesException;
import com.sun.rave.web.ui.component.Listbox;
import com.sun.rave.web.ui.component.Label;
import com.sun.rave.web.ui.component.Hyperlink;
import com.sun.rave.web.ui.model.DefaultOptionsList;
import java.util.Enumeration;
import com.sun.rave.web.ui.model.Option;
import java.util.Properties;

public class Recomendaciones extends AbstractPageBean
{
   private int __placeholder;
   
   private void _init() throws Exception
   {
       // cuerpo vac�o
   } // fin del m�todo _init
   
   private Page page = new Page();
   
   public Page getPage()
   {
      return page;
   }
   
   public void setPage(Page p)
   {
      this.page = p;
   }
   
   private Html html = new Html();
   
   public Html getHtml()
   {
      return html;
   }
   
   public void setHtml(Html h)
   {
      this.html = h;
   }
   
   private Head head = new Head();
   
   public Head getHead()
   {
      return head;
   }
   
   public void setHead(Head h)
   {
      this.head = h;
   }
   
   private Link link = new Link();
   
   public Link getLink()
   {
      return link;
   }
   
   public void setLink(Link l)
   {
      this.link = l;
   }
   
   private Body body = new Body();
   
   public Body getBody()
   {
      return body;
   }
   
   public void setBody(Body b)
   {
      this.body = b;
   }
   
   private Form form = new Form();
   
   public Form getForm()
   {
      return form;
   }
   
   public void setForm(Form f)
   {
      this.form = f;
   }
   
   private Listbox cuadroListaLibros = new Listbox();
   
   public Listbox getCuadroListaLibros()
   {
      return cuadroListaLibros;
   }
   
   public void setCuadroListaLibros(Listbox l)
   {
      this.cuadroListaLibros = l;
   }
   
   private Label etiquetaLenguaje = new Label();
   
   public Label getEtiquetaLenguaje()
   {
      return etiquetaLenguaje;
   }
   
   public void setEtiquetaLenguaje(Label l)
   {
      this.etiquetaLenguaje = l;
   }
   
   private Hyperlink vinculoOpciones = new Hyperlink();
   
   public Hyperlink getVinculoOpciones()
   {
      return vinculoOpciones;
   }
   
   public void setVinculoOpciones(Hyperlink h)
   {
      this.vinculoOpciones = h;
   }
   
   private DefaultOptionsList cuadroListaLibrosDefaultOptions = new DefaultOptionsList();
   
   public DefaultOptionsList getCuadroListaLibrosDefaultOptions()
   {
      return cuadroListaLibrosDefaultOptions;
   }
   
   public void setCuadroListaLibrosDefaultOptions(DefaultOptionsList dol)
   {
      this.cuadroListaLibrosDefaultOptions = dol;
   }
   
   // Construye una nueva instancia del bean de p�gina.
   public Recomendaciones()
   {
      // constructor vac�o
   } // fin del constructor
    
   protected RequestBean1 getRequestBean1()
   {
      return (RequestBean1) getBean( "RequestBean1" );
   } // fin del m�todo getRequestBean1
   
   protected ApplicationBean1 getApplicationBean1()
   {
      return (ApplicationBean1) getBean( "ApplicationBean1" );
   } // fin del m�todo getApplicationBean1
  
   protected SessionBean1 getSessionBean1()
   {
      return (SessionBean1) getBean( "SessionBean1" );
   } // fin del m�todo getSessionBean1
   
   public void init()
   {
      super.init();
      try
      {
         _init();
      } // fin de try
      catch ( Exception e )
      {
         log( "Error al inicializar Recomendaciones", e );
         throw e instanceof FacesException ? (FacesException) e: 
            new FacesException( e );
      } // fin de catch
   } // fin del m�todo init

   public void preprocess()
   {
      // cuerpo vac�o
   } // fin del m�todo preprocess
   
   public void prerender()
   {
      // obtiene las selecciones del usuario y el n�mero de selecciones realizadas
      Properties lenguajes = getSessionBean1().getLenguajesSeleccionados();
      Enumeration enumSelecciones = lenguajes.propertyNames();
      int numSeleccionados = getSessionBean1().getNumSelecciones();
         
      Option [] recomendaciones;
      
      // si por lo menos se hizo una selecci�n
      if ( numSeleccionados > 0 )
      {
         recomendaciones = new Option[ numSeleccionados ];

         for( int i = 0; i < numSeleccionados; i++ )
         {
            String lenguaje = (String) enumSelecciones.nextElement() ;
            recomendaciones[ i ] = new Option( lenguaje + 
               " How to Program.  ISBN#: " + 
               lenguajes.getProperty( lenguaje ) );
         } // fin de for
      } // fin de if
      else
      {
         recomendaciones = new Option[ 1 ];
         recomendaciones[ 0 ] = new Option( 
            "No hay recomendaciones. Seleccione un lenguaje." );
      } // fin de else

      cuadroListaLibros.setItems(recomendaciones);
   } // fin del m�todo prerender

   public void destroy()
   {
      // cuerpo vac�o
   } // fin del m�todo destroy
} // fin de la clase Recomendaciones

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
