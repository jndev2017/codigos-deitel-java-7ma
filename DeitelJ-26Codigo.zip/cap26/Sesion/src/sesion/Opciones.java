// Fig. 26.29: Opciones.java
// Bean de p�gina que almacena las selecciones de lenguajes en una propiedad SessionBean.
package sesion;

import com.sun.rave.web.ui.appbase.AbstractPageBean;
import com.sun.rave.web.ui.component.Body;
import com.sun.rave.web.ui.component.Form;
import com.sun.rave.web.ui.component.Head;
import com.sun.rave.web.ui.component.Html;
import com.sun.rave.web.ui.component.Link;
import com.sun.rave.web.ui.component.Page;
import javax.faces.FacesException;
import com.sun.rave.web.ui.component.RadioButtonGroup;
import com.sun.rave.web.ui.component.Hyperlink;
import com.sun.rave.web.ui.component.Button;
import com.sun.rave.web.ui.component.Label;
import com.sun.rave.web.ui.component.StaticText;
import com.sun.rave.web.ui.model.SingleSelectOptionsList;
import java.util.Properties;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class Opciones extends AbstractPageBean
{
   private int __placeholder;
   
   private void _init() throws Exception
   {
      listaLenguajesDefaultOptions.setOptions(
        new com.sun.rave.web.ui.model.Option[] 
        {
            new com.sun.rave.web.ui.model.Option("Java","Java"),
            new com.sun.rave.web.ui.model.Option("C","C"),
            new com.sun.rave.web.ui.model.Option("C++","C++"),
            new com.sun.rave.web.ui.model.Option("Visual Basic 2005",
                "Visual Basic 2005"),
            new com.sun.rave.web.ui.model.Option("Visual C# 2005",
                "Visual C# 2005") 
        }
      );
   } // fin del m�todo init
   
   private Page page = new Page();
   
   public Page getPage()
   {
      return page;
   }
   
   public void setPage(Page p)
   {
      this.page = p;
   }
   
   private Html html = new Html();
   
   public Html getHtml()
   {
      return html;
   }
   
   public void setHtml(Html h)
   {
      this.html = h;
   }
   
   private Head head = new Head();
   
   public Head getHead()
   {
      return head;
   }
   
   public void setHead(Head h)
   {
      this.head = h;
   }
   
   private Link link = new Link();
   
   public Link getLink()
   {
      return link;
   }
   
   public void setLink(Link l)
   {
      this.link = l;
   }
   
   private Body body = new Body();
   
   public Body getBody()
   {
      return body;
   }
   
   public void setBody(Body b)
   {
      this.body = b;
   }
   
   private Form form = new Form();
   
   public Form getForm()
   {
      return form;
   }
   
   public void setForm(Form f)
   {
      this.form = f;
   }
   
   private RadioButtonGroup listaLenguajes = new RadioButtonGroup();
   
   public RadioButtonGroup getListaLenguajes()
   {
      return listaLenguajes;
   }
   
   public void setListaLenguajes(RadioButtonGroup rbg)
   {
      this.listaLenguajes = rbg;
   }
   
   private Hyperlink vinculoLenguajes = new Hyperlink();
   
   public Hyperlink getVinculoLenguajes1()
   {
      return vinculoLenguajes;
   }
   
   public void setVinculoLenguajes1(Hyperlink h)
   {
      this.vinculoLenguajes = h;
   }
   
   private Button enviar = new Button();
   
   public Button getEnviar()
   {
      return enviar;
   }
   
   public void setEnviar(Button b)
   {
      this.enviar = b;
   }
   
   private Hyperlink vinculoRecomendaciones = new Hyperlink();
   
   public Hyperlink getVinculoRecomendaciones()
   {
      return vinculoRecomendaciones;
   }
   
   public void setVinculoRecomendaciones(Hyperlink h)
   {
      this.vinculoRecomendaciones = h;
   }
   
   private Label etiquetaLenguaje = new Label();
   
   public Label getEtiquetaLenguaje()
   {
      return etiquetaLenguaje;
   }
   
   public void setEtiquetaLenguaje(Label l)
   {
      this.etiquetaLenguaje = l;
   }
   
   private StaticText etiquetaRespuesta = new StaticText();
   
   public StaticText getEtiquetaRespuesta()
   {
      return etiquetaRespuesta;
   }
   
   public void setEtiquetaRespuesta(StaticText st)
   {
      this.etiquetaRespuesta = st;
   }
   
   private SingleSelectOptionsList listaLenguajesDefaultOptions = new SingleSelectOptionsList();
   
   public SingleSelectOptionsList getListaLenguajesDefaultOptions()
   {
      return listaLenguajesDefaultOptions;
   }
   
   public void setListaLenguajesDefaultOptions(SingleSelectOptionsList ssol)
   {
      this.listaLenguajesDefaultOptions = ssol;
   }
   
    private StaticText numSelec = new StaticText();

    public StaticText getNumSelec() {
        return numSelec;
    }

    public void setNumSelec(StaticText st) {
        this.numSelec = st;
    }

    private StaticText etiquetaNumSelec = new StaticText();

    public StaticText getEtiquetaNumSelec() {
        return etiquetaNumSelec;
    }

    public void setEtiquetaNumSelec(StaticText st) {
        this.etiquetaNumSelec = st;
    }
    
   private Properties libros = new Properties();
    
   public Opciones()
   {
      // inicializa el objeto Properties de valores que se van a almacenar en 
      // el bean de sesi�n.
      libros.setProperty( "Java", "0-13-222220-5" );
      libros.setProperty( "C", "0-13-142644-3" );
      libros.setProperty( "C++", "0-13-185757-6" );
      libros.setProperty( "Visual Basic 2005", "0-13-186900-0" );
      libros.setProperty( "Visual C# 2005", "0-13-152523-9" );
   } // fin del constructor
   
   protected ApplicationBean1 getApplicationBean1()
   {
      return (ApplicationBean1) getBean( "ApplicationBean1" );
   } // fin del m�todo getApplicationBean1
   
   protected RequestBean1 getRequestBean1()
   {
      return (RequestBean1) getBean( "RequestBean1" );
   } // fin del m�todo getRequestBean1
   
   protected SessionBean1 getSessionBean1()
   {
      return (SessionBean1) getBean( "SessionBean1" );
   } // fin del m�todo getSessionBean1
   
   public void init()
   {
      super.init();
      try
      {
         _init();
      } // fin de try
      catch ( Exception e )
      {
         log( "Error al inicializar Opciones", e );
         throw e instanceof FacesException ? (FacesException) e:
            new FacesException( e );
      } // fin de catch
   } // fin del m�todo init
   
   public void preprocess()
   {
      // cuerpo vac�o
   } // fin del m�todo preprocess
   
   public void prerender()
   {
      // cuerpo vac�o
   } // fin del m�todo prerender

   public void destroy()
   {
      // cuerpo vac�o
   } // fin del m�todo destroy
   
   // manejador de acciones para el bot�n enviar, almacena los lenguajes seleccionados
   // en �mbito de sesi�n para obtenerlos al hacer recomendaciones de libros.
   public String enviar_action()
   {
      String msg = "Bienvenido a las sesiones!  Usted ";
      
      // si el usuario hizo una selecci�n
      if ( getListaLenguajes().getSelected() != null )
      {
         String lenguaje = listaLenguajes.getSelected().toString();
         msg += "selecciono " + lenguaje + ".";
         
         // obtiene el n�mero ISBN del libro para el lenguaje dado.
         String ISBN = libros.getProperty( lenguaje );
         
         // agrega la selecci�n al objeto Properties de SessionBean1
         Properties selections = getSessionBean1().getLenguajesSeleccionados();
         Object resultado = selections.setProperty( lenguaje, ISBN );
         
         // incrementa numSelecciones en el objeto SessionBean1 y actualiza
         // lenguajesSeleccionados si el usuario no ha realizado esta selecci�n 
         // antes
         if ( resultado == null )
         {
            int numSelec = getSessionBean1().getNumSelecciones();
            getSessionBean1().setNumSelecciones(++numSelec);
         } // fin de if
      } // fin de if    
      else
         msg += "no selecciono un lenguaje.";
      
      etiquetaRespuesta.setValue(msg);
      listaLenguajes.setRendered(false);
      etiquetaLenguaje.setRendered(false);
      enviar.setRendered(false);
      etiquetaRespuesta.setRendered(true);
      etiquetaNumSelec.setRendered(true);
      numSelec.setRendered(true);
      vinculoLenguajes.setRendered( true );
      vinculoRecomendaciones.setRendered( true );
      return null;
   } // fin del m�todo enviar_action

   // vuelve a mostrar los componentes usados para permitir al usuario
   // seleccionar un lenguaje.
   public String vinculoLenguajes1_action() {
      etiquetaRespuesta.setRendered(false);
      etiquetaNumSelec.setRendered(false);
      numSelec.setRendered(false);
      vinculoLenguajes.setRendered( false );
      vinculoRecomendaciones.setRendered( false );
      listaLenguajes.setRendered(true);
      etiquetaLenguaje.setRendered(true);
      enviar.setRendered(true);
      return null;
    } // fin del m�todo vinculoLenguajes1_action
} // fin de la clase Opciones

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
