// Fig. 26.29: SessionBean1.java
// Archivo SessionBean1 para almacenar las selecciones de lenguajes.
package sesion;

import com.sun.rave.web.ui.appbase.AbstractSessionBean;
import java.util.Properties;
import javax.faces.FacesException;

public class SessionBean1 extends AbstractSessionBean
{
   private int __placeholder;
   
   private void _init() throws Exception
   {
      // cuerpo vac�o
   } // fin del m�todo _init
   
   public SessionBean1()
   {
      // constructor vac�o
   } // fin del constructor
   
   protected ApplicationBean1 getApplicationBean1()
   {
      return (ApplicationBean1)getBean("ApplicationBean1");
   } // fin del m�todo getApplicationBean11
   
   public void init()
   {
      super.init();
      try
      {
         _init();
      } // fin de try
      catch ( Exception e )
      {
         log("Error al inicializar SessionBean1", e);
         throw e instanceof FacesException ? (FacesException) e: 
            new FacesException( e );
      } // fin de catch
   } // fin del m�todo init
   
   public void passivate()
   {
      // cuerpo vac�o
   } // fin del m�todo passivate
   
   public void activate()
   {
      // cuerpo vac�o
   } // fin del m�todo activate
   
   public void destroy()
   {
      // cuerpo vac�o
   } // fin del m�todo destroy
   
   private int numSelecciones = 0; // almacena el n�mero de selecciones �nicas

    public int getNumSelecciones()
    {
        return this.numSelecciones;
    } // fin del m�todo getNumSelecciones

    public void setNumSelecciones( int numSelecciones )
    {
        this.numSelecciones = numSelecciones;
    } // fin del m�todo setNumSelecciones
   
   //  Almacena pares clave-valor de lenguajes seleccionados
   private Properties lenguajesSeleccionados = new Properties();
   
   public Properties getLenguajesSeleccionados()
   {
      return this.lenguajesSeleccionados;
   } // fin del m�todo getLenguajesSeleccionados
   
   public void setLenguajesSeleccionados( Properties lenguajesSeleccionados )
   {
      this.lenguajesSeleccionados = lenguajesSeleccionados;
   } // fin del m�todo setLenguajesSeleccionados
} // fin de la clase SessionBean1

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/