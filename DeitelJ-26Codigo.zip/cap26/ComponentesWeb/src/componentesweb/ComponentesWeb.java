/*
 * ComponentesWeb.java
 *
 * Created on 22 de octubre de 2007, 11:47 AM
 * Copyright Administrador
 */
package componentesweb;

import com.sun.rave.web.ui.appbase.AbstractPageBean;
import com.sun.rave.web.ui.component.Body;
import com.sun.rave.web.ui.component.Form;
import com.sun.rave.web.ui.component.Head;
import com.sun.rave.web.ui.component.Html;
import com.sun.rave.web.ui.component.Link;
import com.sun.rave.web.ui.component.Page;
import javax.faces.FacesException;
import javax.faces.component.html.HtmlPanelGrid;
import com.sun.rave.web.ui.component.ImageComponent;
import com.sun.rave.web.ui.component.TextField;
import com.sun.rave.web.ui.component.Label;
import com.sun.rave.web.ui.component.DropDown;
import com.sun.rave.web.ui.model.SingleSelectOptionsList;
import com.sun.rave.web.ui.component.Hyperlink;
import com.sun.rave.web.ui.component.RadioButtonGroup;
import com.sun.rave.web.ui.component.Button;
import com.sun.rave.web.ui.component.StaticText;

/**
 * <p>Page bean that corresponds to a similarly named JSP page.  This
 * class contains component definitions (and initialization code) for
 * all components that you have defined on this page, as well as
 * lifecycle methods and event handlers where you may add behavior
 * to respond to incoming events.</p>
 */
public class ComponentesWeb extends AbstractPageBean {
    // <editor-fold defaultstate="collapsed" desc="Creator-managed Component Definition">
    private int __placeholder;
    
    /**
     * <p>Automatically managed component initialization.  <strong>WARNING:</strong>
     * This method is automatically generated, so any user-specified code inserted
     * here is subject to being replaced.</p>
     */
    private void _init() throws Exception {
        librosDesplegableDefaultOptions.setOptions(new com.sun.rave.web.ui.model.Option[] {new com.sun.rave.web.ui.model.Option("VBHTP3e","Visual Basic 2005 How to Program 3e"),new com.sun.rave.web.ui.model.Option("VCSHTP2e","Visual C# How to Program 2e"),new com.sun.rave.web.ui.model.Option("JHTP7e","Java How to Program 7e"),new com.sun.rave.web.ui.model.Option("CPPHTP5e","C++ How to Program 5e"),new com.sun.rave.web.ui.model.Option("XHTP1e","XML How to Program 1e") });
        botonesSeleccionSODefaultOptions.setOptions(new com.sun.rave.web.ui.model.Option[] {new com.sun.rave.web.ui.model.Option("Windows XP", "Windows XP"), new com.sun.rave.web.ui.model.Option("Windows 2000", "Windows 2000"), new com.sun.rave.web.ui.model.Option("Windows NT", "Windows NT"), new com.sun.rave.web.ui.model.Option("Linux", "Linux"), new com.sun.rave.web.ui.model.Option("Otro", "Otro")});
    }
    
    private Page page1 = new Page();
    
    public Page getPage1() {
        return page1;
    }
    
    public void setPage1(Page p) {
        this.page1 = p;
    }
    
    private Html html1 = new Html();
    
    public Html getHtml1() {
        return html1;
    }
    
    public void setHtml1(Html h) {
        this.html1 = h;
    }
    
    private Head head1 = new Head();
    
    public Head getHead1() {
        return head1;
    }
    
    public void setHead1(Head h) {
        this.head1 = h;
    }
    
    private Link link1 = new Link();
    
    public Link getLink1() {
        return link1;
    }
    
    public void setLink1(Link l) {
        this.link1 = l;
    }
    
    private Body body1 = new Body();
    
    public Body getBody1() {
        return body1;
    }
    
    public void setBody1(Body b) {
        this.body1 = b;
    }
    
    private Form form1 = new Form();
    
    public Form getForm1() {
        return form1;
    }
    
    public void setForm1(Form f) {
        this.form1 = f;
    }

    private HtmlPanelGrid gridPanel1 = new HtmlPanelGrid();

    public HtmlPanelGrid getGridPanel1() {
        return gridPanel1;
    }

    public void setGridPanel1(HtmlPanelGrid hpg) {
        this.gridPanel1 = hpg;
    }

    private ImageComponent imagenNombre = new ImageComponent();

    public ImageComponent getImagenNombre() {
        return imagenNombre;
    }

    public void setImagenNombre(ImageComponent ic) {
        this.imagenNombre = ic;
    }

    private TextField cuadroTextoNombre = new TextField();

    public TextField getCuadroTextoNombre() {
        return cuadroTextoNombre;
    }

    public void setCuadroTextoNombre(TextField tf) {
        this.cuadroTextoNombre = tf;
    }

    private TextField cuadroTextoApellido = new TextField();

    public TextField getCuadroTextoApellido() {
        return cuadroTextoApellido;
    }

    public void setCuadroTextoApellido(TextField tf) {
        this.cuadroTextoApellido = tf;
    }

    private ImageComponent imagenApellido = new ImageComponent();

    public ImageComponent getImagenApellido() {
        return imagenApellido;
    }

    public void setImagenApellido(ImageComponent ic) {
        this.imagenApellido = ic;
    }

    private TextField cuadroTextoEmail = new TextField();

    public TextField getCuadroTextoEmail() {
        return cuadroTextoEmail;
    }

    public void setCuadroTextoEmail(TextField tf) {
        this.cuadroTextoEmail = tf;
    }

    private ImageComponent imagenEmail = new ImageComponent();

    public ImageComponent getImagenEmail() {
        return imagenEmail;
    }

    public void setImagenEmail(ImageComponent ic) {
        this.imagenEmail = ic;
    }

    private TextField cuadroTextoTelefono = new TextField();

    public TextField getCuadroTextoTelefono() {
        return cuadroTextoTelefono;
    }

    public void setCuadroTextoTelefono(TextField tf) {
        this.cuadroTextoTelefono = tf;
    }

    private ImageComponent imagenTelefono = new ImageComponent();

    public ImageComponent getImagenTelefono() {
        return imagenTelefono;
    }

    public void setImagenTelefono(ImageComponent ic) {
        this.imagenTelefono = ic;
    }

    private ImageComponent imagenUsuario = new ImageComponent();

    public ImageComponent getImagenUsuario() {
        return imagenUsuario;
    }

    public void setImagenUsuario(ImageComponent ic) {
        this.imagenUsuario = ic;
    }

    private ImageComponent imagenPublicaciones = new ImageComponent();

    public ImageComponent getImagenPublicaciones() {
        return imagenPublicaciones;
    }

    public void setImagenPublicaciones(ImageComponent ic) {
        this.imagenPublicaciones = ic;
    }

    private DropDown librosDesplegable = new DropDown();

    public DropDown getLibrosDesplegable() {
        return librosDesplegable;
    }

    public void setLibrosDesplegable(DropDown dd) {
        this.librosDesplegable = dd;
    }

    private SingleSelectOptionsList librosDesplegableDefaultOptions = new SingleSelectOptionsList();

    public SingleSelectOptionsList getLibrosDesplegableDefaultOptions() {
        return librosDesplegableDefaultOptions;
    }

    public void setLibrosDesplegableDefaultOptions(SingleSelectOptionsList ssol) {
        this.librosDesplegableDefaultOptions = ssol;
    }

    private Hyperlink librosVinculo = new Hyperlink();

    public Hyperlink getLibrosVinculo() {
        return librosVinculo;
    }

    public void setLibrosVinculo(Hyperlink h) {
        this.librosVinculo = h;
    }

    private ImageComponent image1 = new ImageComponent();

    public ImageComponent getImage1() {
        return image1;
    }

    public void setImage1(ImageComponent ic) {
        this.image1 = ic;
    }

    private RadioButtonGroup botonesSeleccionSO = new RadioButtonGroup();

    public RadioButtonGroup getBotonesSeleccionSO() {
        return botonesSeleccionSO;
    }

    public void setBotonesSeleccionSO(RadioButtonGroup rbg) {
        this.botonesSeleccionSO = rbg;
    }

    private SingleSelectOptionsList botonesSeleccionSODefaultOptions = new SingleSelectOptionsList();

    public SingleSelectOptionsList getBotonesSeleccionSODefaultOptions() {
        return botonesSeleccionSODefaultOptions;
    }

    public void setBotonesSeleccionSODefaultOptions(SingleSelectOptionsList ssol) {
        this.botonesSeleccionSODefaultOptions = ssol;
    }

    private Button botonRegistro = new Button();

    public Button getBotonRegistro() {
        return botonRegistro;
    }

    public void setBotonRegistro(Button b) {
        this.botonRegistro = b;
    }

    private StaticText encabezado = new StaticText();

    public StaticText getEncabezado() {
        return encabezado;
    }

    public void setEncabezado(StaticText st) {
        this.encabezado = st;
    }

    private StaticText instrucciones = new StaticText();

    public StaticText getInstrucciones() {
        return instrucciones;
    }

    public void setInstrucciones(StaticText st) {
        this.instrucciones = st;
    }

    private StaticText etiquetaPublicacion = new StaticText();

    public StaticText getEtiquetaPublicacion() {
        return etiquetaPublicacion;
    }

    public void setEtiquetaPublicacion(StaticText st) {
        this.etiquetaPublicacion = st;
    }

    private StaticText etiquetaSO = new StaticText();

    public StaticText getEtiquetaSO() {
        return etiquetaSO;
    }

    public void setEtiquetaSO(StaticText st) {
        this.etiquetaSO = st;
    }
    
    // </editor-fold>


    /** 
     * <p>Construir una instancia de bean de p�gina.</p>
     */
    public ComponentesWeb() {
    }

    /** 
     * <p>Devolver una referencia al bean de datos con �mbito.</p>
     */
    protected ApplicationBean1 getApplicationBean1() {
        return (ApplicationBean1)getBean("ApplicationBean1");
    }


    /** 
     * <p>Devolver una referencia al bean de datos con �mbito.</p>
     */
    protected RequestBean1 getRequestBean1() {
        return (RequestBean1)getBean("RequestBean1");
    }


    /** 
     * <p>Devolver una referencia al bean de datos con �mbito.</p>
     */
    protected SessionBean1 getSessionBean1() {
        return (SessionBean1)getBean("SessionBean1");
    }


    /** 
     * <p>M�todo de devoluci�n de llamada al que se llama cuando se navega hasta esta p�gina,
     * ya sea directamente mediante un URL o de manera indirecta a trav�s de la navegaci�n de p�ginas.
     * Puede personalizar este m�todo para adquirir recursos que se necesitar�n
     * para los controladores de eventos y m�todos del proceso, sin tener en cuenta si esta
     * p�gina realiza procesamiento de devoluci�n de env�os.</p>
     * 
     * <p>Tenga en cuenta que si la petici�n actual es una devoluci�n de env�o, los valores
     * de propiedad de los componentes <strong>no</strong> representan ning�n
     * valor enviado con esta petici�n.  En su lugar, representan los
     * valores de propiedades que se guardaron para esta vista cuando se proces�.</p>
     */
    public void init() {
        // Realizar iniciaciones heredadas de la superclase
        super.init();
        // Realizar inicio de aplicaci�n que debe finalizar
        // *antes* de que se inicien los componentes administrados
        // TODO - Agregar c�digo de inicio propio aqu�

        // <editor-fold defaultstate="collapsed" desc="Inicio de componente administrado por el programa">
        // Iniciar componentes administrados autom�ticamente
        // *Nota* - esta l�gica NO debe modificarse
        try {
            _init();
        } catch (Exception e) {
            log("Page1 Initialization Failure", e);
            throw e instanceof FacesException ? (FacesException) e: new FacesException(e);
        }
        // </editor-fold>
        // Realizar inicio de aplicaci�n que debe finalizar
        // *despu�s* de que se inicien los componentes administrados
        // TODO - Agregar c�digo de inicio propio aqu�

    }

    /** 
     * <p>M�todo de devoluci�n de llamada al que se llama cuando el �rbol de componentes se ha
     * restaurado, pero antes de que se produzca el procesamiento de cualquier evento.  Este m�todo
     * <strong>s�lo</strong> se llamar� en una petici�n de devoluci�n de env�o que
     * est� procesando el env�o de un formulario.  Puede personalizar este m�todo para asignar
     * recursos necesarios para los controladores de eventos.</p>
     */
    public void preprocess() {
    }

    /** 
     * <p>M�todo de devoluci�n de llamada al que se llama justo antes del procesamiento.
     * <strong>S�lo</strong> se llamar� a este m�todo en la p�gina que
     * se procesa, no se llamar�, por ejemplo, en una p�gina que
     * ha procesado una devoluci�n de env�o y a continuaci�n ha navegado hasta otra p�gina.  Puede personalizar
     * este m�todo para asignar recursos necesarios para procesar
     * esta p�gina.</p>
     */
    public void prerender() {
    }

    /** 
     * <p>M�todo de devoluci�n de llamada al que se llama cuando se completa el procesamiento de
     * esta petici�n, si se llam� al m�todo <code>init()</code> (sin tener en cuenta
     * si se trata de la p�gina que se ha procesado o no).  Puede personalizar este
     * m�todo para liberar los recursos adquiridos en los m�todos <code>init()</code>,
     * <code>preprocess()</code> o <code>prerender()</code> (o
     * durante la ejecuci�n de un controlador de eventos).</p>
     */
    public void destroy() {
    }
}

