/*
 * Validacion.java
 *
 * Created on 23 de octubre de 2007, 02:04 AM
 * Copyright Administrador
 */
package validacion;

import com.sun.rave.web.ui.appbase.AbstractPageBean;
import com.sun.rave.web.ui.component.Body;
import com.sun.rave.web.ui.component.Form;
import com.sun.rave.web.ui.component.Head;
import com.sun.rave.web.ui.component.Html;
import com.sun.rave.web.ui.component.Link;
import com.sun.rave.web.ui.component.Page;
import javax.faces.FacesException;
import com.sun.rave.web.ui.component.StaticText;
import com.sun.rave.web.ui.component.TextField;
import com.sun.rave.web.ui.component.Label;
import com.sun.rave.web.ui.component.Button;
import com.sun.rave.web.ui.component.Message;
import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.validator.LengthValidator;

/**
 * <p>Page bean that corresponds to a similarly named JSP page.  This
 * class contains component definitions (and initialization code) for
 * all components that you have defined on this page, as well as
 * lifecycle methods and event handlers where you may add behavior
 * to respond to incoming events.</p>
 */
public class Validacion extends AbstractPageBean {
    // <editor-fold defaultstate="collapsed" desc="Creator-managed Component Definition">
    private int __placeholder;
    
    /**
     * <p>Automatically managed component initialization.  <strong>WARNING:</strong>
     * This method is automatically generated, so any user-specified code inserted
     * here is subject to being replaced.</p>
     */
    private void _init() throws Exception {
        longitudNombreValidador.setMaximum(30);
    }
    
    private Page page1 = new Page();
    
    public Page getPage1() {
        return page1;
    }
    
    public void setPage1(Page p) {
        this.page1 = p;
    }
    
    private Html html1 = new Html();
    
    public Html getHtml1() {
        return html1;
    }
    
    public void setHtml1(Html h) {
        this.html1 = h;
    }
    
    private Head head1 = new Head();
    
    public Head getHead1() {
        return head1;
    }
    
    public void setHead1(Head h) {
        this.head1 = h;
    }
    
    private Link link1 = new Link();
    
    public Link getLink1() {
        return link1;
    }
    
    public void setLink1(Link l) {
        this.link1 = l;
    }
    
    private Body body1 = new Body();
    
    public Body getBody1() {
        return body1;
    }
    
    public void setBody1(Body b) {
        this.body1 = b;
    }
    
    private Form form1 = new Form();
    
    public Form getForm1() {
        return form1;
    }
    
    public void setForm1(Form f) {
        this.form1 = f;
    }

    private StaticText encabezado = new StaticText();

    public StaticText getEncabezado() {
        return encabezado;
    }

    public void setEncabezado(StaticText st) {
        this.encabezado = st;
    }

    private StaticText staticText1 = new StaticText();

    public StaticText getStaticText1() {
        return staticText1;
    }

    public void setStaticText1(StaticText st) {
        this.staticText1 = st;
    }

    private TextField ctextoNombre = new TextField();

    public TextField getCtextoNombre() {
        return ctextoNombre;
    }

    public void setCtextoNombre(TextField tf) {
        this.ctextoNombre = tf;
    }

    private TextField ctextoEmail = new TextField();

    public TextField getCtextoEmail() {
        return ctextoEmail;
    }

    public void setCtextoEmail(TextField tf) {
        this.ctextoEmail = tf;
    }

    private TextField ctextoTelefono = new TextField();

    public TextField getCtextoTelefono() {
        return ctextoTelefono;
    }

    public void setCtextoTelefono(TextField tf) {
        this.ctextoTelefono = tf;
    }

    private Label etiquetaNombre = new Label();

    public Label getEtiquetaNombre() {
        return etiquetaNombre;
    }

    public void setEtiquetaNombre(Label l) {
        this.etiquetaNombre = l;
    }

    private Label etiquetaEmail = new Label();

    public Label getEtiquetaEmail() {
        return etiquetaEmail;
    }

    public void setEtiquetaEmail(Label l) {
        this.etiquetaEmail = l;
    }

    private Label etiquetaTelefono = new Label();

    public Label getEtiquetaTelefono() {
        return etiquetaTelefono;
    }

    public void setEtiquetaTelefono(Label l) {
        this.etiquetaTelefono = l;
    }

    private Button botonEnviar = new Button();

    public Button getBotonEnviar() {
        return botonEnviar;
    }

    public void setBotonEnviar(Button b) {
        this.botonEnviar = b;
    }

    private Message mensajeNombre = new Message();

    public Message getMensajeNombre() {
        return mensajeNombre;
    }

    public void setMensajeNombre(Message m) {
        this.mensajeNombre = m;
    }

    private Message mensajeEmail = new Message();

    public Message getMensajeEmail() {
        return mensajeEmail;
    }

    public void setMensajeEmail(Message m) {
        this.mensajeEmail = m;
    }

    private Message mensajeTelefono = new Message();

    public Message getMensajeTelefono() {
        return mensajeTelefono;
    }

    public void setMensajeTelefono(Message m) {
        this.mensajeTelefono = m;
    }

    private StaticText textoResultado = new StaticText();

    public StaticText getTextoResultado() {
        return textoResultado;
    }

    public void setTextoResultado(StaticText st) {
        this.textoResultado = st;
    }

    private HtmlPanelGrid panelCuadricula = new HtmlPanelGrid();

    public HtmlPanelGrid getPanelCuadricula() {
        return panelCuadricula;
    }

    public void setPanelCuadricula(HtmlPanelGrid hpg) {
        this.panelCuadricula = hpg;
    }

    private StaticText etiquetaResultadoNombre = new StaticText();

    public StaticText getEtiquetaResultadoNombre() {
        return etiquetaResultadoNombre;
    }

    public void setEtiquetaResultadoNombre(StaticText st) {
        this.etiquetaResultadoNombre = st;
    }

    private StaticText resultadoNombre = new StaticText();

    public StaticText getResultadoNombre() {
        return resultadoNombre;
    }

    public void setResultadoNombre(StaticText st) {
        this.resultadoNombre = st;
    }

    private StaticText etiquetaResultadoTelefono = new StaticText();

    public StaticText getEtiquetaResultadoTelefono() {
        return etiquetaResultadoTelefono;
    }

    public void setEtiquetaResultadoTelefono(StaticText st) {
        this.etiquetaResultadoTelefono = st;
    }

    private StaticText resultadoTelefono = new StaticText();

    public StaticText getResultadoTelefono() {
        return resultadoTelefono;
    }

    public void setResultadoTelefono(StaticText st) {
        this.resultadoTelefono = st;
    }

    private StaticText etiquetaResultadoEmail = new StaticText();

    public StaticText getEtiquetaResultadoEmail() {
        return etiquetaResultadoEmail;
    }

    public void setEtiquetaResultadoEmail(StaticText st) {
        this.etiquetaResultadoEmail = st;
    }

    private StaticText resultadoEmail = new StaticText();

    public StaticText getResultadoEmail() {
        return resultadoEmail;
    }

    public void setResultadoEmail(StaticText st) {
        this.resultadoEmail = st;
    }

    private LengthValidator longitudNombreValidador = new LengthValidator();

    public LengthValidator getLongitudNombreValidador() {
        return longitudNombreValidador;
    }

    public void setLongitudNombreValidador(LengthValidator lv) {
        this.longitudNombreValidador = lv;
    }

    private LengthValidator lengthValidator2 = new LengthValidator();

    public LengthValidator getLengthValidator2() {
        return lengthValidator2;
    }

    public void setLengthValidator2(LengthValidator lv) {
        this.lengthValidator2 = lv;
    }

    private LengthValidator lengthValidator3 = new LengthValidator();

    public LengthValidator getLengthValidator3() {
        return lengthValidator3;
    }

    public void setLengthValidator3(LengthValidator lv) {
        this.lengthValidator3 = lv;
    }
    
    // </editor-fold>


    /** 
     * <p>Construir una instancia de bean de p�gina.</p>
     */
    public Validacion() {
    }

    /** 
     * <p>Devolver una referencia al bean de datos con �mbito.</p>
     */
    protected ApplicationBean1 getApplicationBean1() {
        return (ApplicationBean1)getBean("ApplicationBean1");
    }


    /** 
     * <p>Devolver una referencia al bean de datos con �mbito.</p>
     */
    protected RequestBean1 getRequestBean1() {
        return (RequestBean1)getBean("RequestBean1");
    }


    /** 
     * <p>Devolver una referencia al bean de datos con �mbito.</p>
     */
    protected SessionBean1 getSessionBean1() {
        return (SessionBean1)getBean("SessionBean1");
    }


    /** 
     * <p>M�todo de devoluci�n de llamada al que se llama cuando se navega hasta esta p�gina,
     * ya sea directamente mediante un URL o de manera indirecta a trav�s de la navegaci�n de p�ginas.
     * Puede personalizar este m�todo para adquirir recursos que se necesitar�n
     * para los controladores de eventos y m�todos del proceso, sin tener en cuenta si esta
     * p�gina realiza procesamiento de devoluci�n de env�os.</p>
     * 
     * <p>Tenga en cuenta que si la petici�n actual es una devoluci�n de env�o, los valores
     * de propiedad de los componentes <strong>no</strong> representan ning�n
     * valor enviado con esta petici�n.  En su lugar, representan los
     * valores de propiedades que se guardaron para esta vista cuando se proces�.</p>
     */
    public void init() {
        // Realizar iniciaciones heredadas de la superclase
        super.init();
        // Realizar inicio de aplicaci�n que debe finalizar
        // *antes* de que se inicien los componentes administrados
        // TODO - Agregar c�digo de inicio propio aqu�

        // <editor-fold defaultstate="collapsed" desc="Inicio de componente administrado por el programa">
        // Iniciar componentes administrados autom�ticamente
        // *Nota* - esta l�gica NO debe modificarse
        try {
            _init();
        } catch (Exception e) {
            log("Page1 Initialization Failure", e);
            throw e instanceof FacesException ? (FacesException) e: new FacesException(e);
        }
        // </editor-fold>
        // Realizar inicio de aplicaci�n que debe finalizar
        // *despu�s* de que se inicien los componentes administrados
        // TODO - Agregar c�digo de inicio propio aqu�

    }

    /** 
     * <p>M�todo de devoluci�n de llamada al que se llama cuando el �rbol de componentes se ha
     * restaurado, pero antes de que se produzca el procesamiento de cualquier evento.  Este m�todo
     * <strong>s�lo</strong> se llamar� en una petici�n de devoluci�n de env�o que
     * est� procesando el env�o de un formulario.  Puede personalizar este m�todo para asignar
     * recursos necesarios para los controladores de eventos.</p>
     */
    public void preprocess() {
    }

    /** 
     * <p>M�todo de devoluci�n de llamada al que se llama justo antes del procesamiento.
     * <strong>S�lo</strong> se llamar� a este m�todo en la p�gina que
     * se procesa, no se llamar�, por ejemplo, en una p�gina que
     * ha procesado una devoluci�n de env�o y a continuaci�n ha navegado hasta otra p�gina.  Puede personalizar
     * este m�todo para asignar recursos necesarios para procesar
     * esta p�gina.</p>
     */
    public void prerender() {
    }

    /** 
     * <p>M�todo de devoluci�n de llamada al que se llama cuando se completa el procesamiento de
     * esta petici�n, si se llam� al m�todo <code>init()</code> (sin tener en cuenta
     * si se trata de la p�gina que se ha procesado o no).  Puede personalizar este
     * m�todo para liberar los recursos adquiridos en los m�todos <code>init()</code>,
     * <code>preprocess()</code> o <code>prerender()</code> (o
     * durante la ejecuci�n de un controlador de eventos).</p>
     */
    public void destroy() {
    }
}

