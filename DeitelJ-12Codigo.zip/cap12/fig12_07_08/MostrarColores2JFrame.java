// Fig. 12.7: MostrarColores2JFrame.java
// Selecci�n de colores con JColorChooser.
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JColorChooser;
import javax.swing.JPanel;

public class MostrarColores2JFrame extends JFrame 
{
   private JButton cambiarColorJButton;
   private Color color = Color.LIGHT_GRAY;
   private JPanel coloresJPanel;

   // establece la GUI
   public MostrarColores2JFrame()
   {
      super( "Uso de JColorChooser" );

      // crea objeto JPanel para mostrar color
      coloresJPanel = new JPanel();
      coloresJPanel.setBackground( color );

      // establece cambiarColorJButton y registra su manejador de eventos
      cambiarColorJButton = new JButton( "Cambiar color" );
      cambiarColorJButton.addActionListener(

         new ActionListener() // clase interna an�nima
         {
            // muestra JColorChooser cuando el usuario hace clic con el bot�n
            public void actionPerformed( ActionEvent evento )
            {
               color = JColorChooser.showDialog( 
                  MostrarColores2JFrame.this, "Seleccione un color", color );

               // establece el color predeterminado, si no se devuelve un color
               if ( color == null )
                  color = Color.LIGHT_GRAY;

               // cambia el color de fondo del panel de contenido
               coloresJPanel.setBackground( color );
            } // fin del m�todo actionPerformed
         } // fin de la clase interna an�nima
      ); // fin de la llamada a addActionListener
 
      add( coloresJPanel, BorderLayout.CENTER ); // agrega coloresJPanel
      add( cambiarColorJButton, BorderLayout.SOUTH ); // agrega bot�n

      setSize( 400, 130 ); // establece el tama�o del marco
      setVisible( true ); // muestra el marco
   } // fin del constructor de MostrarColores2JFrame
} // fin de la clase MostrarColores2JFrame

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/