// Fig. 12.15: MetricaJPanel.java
// M�todos de FontMetrics y Graphics �tiles para obtener la m�trica de los tipos de letra.
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import javax.swing.JPanel;

public class MetricaJPanel extends JPanel 
{
   // muestra la m�trica de los tipos de letra
   public void paintComponent( Graphics g )
   {
      super.paintComponent( g ); // llama al m�todo paintComponent de la superclase

      g.setFont( new Font( "SansSerif", Font.BOLD, 12 ) );
      FontMetrics metrica = g.getFontMetrics();
      g.drawString( "Tipo de letra actual: " + g.getFont(), 10, 40 );
      g.drawString( "Ascendente: " + metrica.getAscent(), 10, 55 );
      g.drawString( "Descendente: " + metrica.getDescent(), 10, 70 );
      g.drawString( "Altura: " + metrica.getHeight(), 10, 85 );
      g.drawString( "Interlineado: " + metrica.getLeading(), 10, 100 );

      Font tipoLetra = new Font( "Serif", Font.ITALIC, 14 );
      metrica = g.getFontMetrics( tipoLetra );
      g.setFont( tipoLetra );
      g.drawString( "Tipo de letra actual: " + tipoLetra, 10, 130 );
      g.drawString( "Ascendente: " + metrica.getAscent(), 10, 145 );
      g.drawString( "Descendente: " + metrica.getDescent(), 10, 160 );
      g.drawString( "Altura: " + metrica.getHeight(), 10, 175 );
      g.drawString( "Interlineado: " + metrica.getLeading(), 10, 190 );
   } // fin del m�todo paintComponent
} // fin de la clase MetricaJPanel

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/