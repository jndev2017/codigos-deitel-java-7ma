// Fig. 12.27: PoligonosJPanel.java
// Dibujo de pol�gonos.
import java.awt.Graphics;
import java.awt.Polygon;
import javax.swing.JPanel;

public class PoligonosJPanel extends JPanel 
{
   // dibuja pol�gonos y polil�neas
   public void paintComponent( Graphics g )
   {
      super.paintComponent( g ); // llama al m�todo paintComponent de la superclase

      // dibuja pol�gono con objeto pol�gono
      int valoresX[] = { 20, 40, 50, 30, 20, 15 };
      int valoresY[] = { 50, 50, 60, 80, 80, 60 };
      Polygon poligono1 = new Polygon( valoresX, valoresY, 6 );
      g.drawPolygon( poligono1 );

      // dibuja polil�neas con dos arreglos
      int valoresX2[] = { 70, 90, 100, 80, 70, 65, 60 };
      int valoresY2[] = { 100, 100, 110, 110, 130, 110, 90 };
      g.drawPolyline( valoresX2, valoresY2, 7 );

      // rellena pol�gono con dos arreglos
      int valoresX3[] = { 120, 140, 150, 190 };
      int valoresY3[] = { 40, 70, 80, 60 };
      g.fillPolygon( valoresX3, valoresY3, 4 );

      // dibuja pol�gono relleno con objeto Polygon
      Polygon poligono2= new Polygon();
      poligono2.addPoint( 165, 135 );
      poligono2.addPoint( 175, 150 );
      poligono2.addPoint( 270, 200 );
      poligono2.addPoint( 200, 220 );
      poligono2.addPoint( 130, 180 );
      g.fillPolygon( poligono2);
   } // fin del m�todo paintComponent
} // fin de la clase PoligonosJPanel

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
