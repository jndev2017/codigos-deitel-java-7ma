// Fig. 12.11: FontJPanel.java
// Muestra cadenas en distintos tipos de letra y colores.
import java.awt.Font;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

public class FontJPanel extends JPanel
{
   // muestra objetos String en distintos tipos de letra y colores
   public void paintComponent( Graphics g )
   {
      super.paintComponent( g ); // llama al m�todo paintComponent de la superclase

      // establece el tipo de letra a Serif (Times), negrita, 12 puntos y dibuja una cadena
      g.setFont( new Font( "Serif", Font.BOLD, 12 ) );
      g.drawString( "Serif 12 puntos, negrita.", 20, 50 );

      // establece el tipo de letra a Monospaced (Courier), cursiva, 24 puntos y dibuja una cadena
      g.setFont( new Font( "Monospaced", Font.ITALIC, 24 ) );
      g.drawString( "Monospaced 24 puntos, cursiva.", 20, 70 );

      // establece el tipo de letra a SansSerif (Helvetica), simple, 14 puntos y dibuja una cadena 
      g.setFont( new Font( "SansSerif", Font.PLAIN, 14 ) );
      g.drawString( "SansSerif 14 puntos, simple.", 20, 90 );

      // establece el tipo de letra a Serif (Times), negrita/cursiva, 18 puntos y dibuja una cadena
      g.setColor( Color.RED );
      g.setFont( new Font( "Serif", Font.BOLD + Font.ITALIC, 18 ) );
      g.drawString( g.getFont().getName() + " " + g.getFont().getSize() +
         " puntos, negrita cursiva.", 20, 110 );
   } // fin del m�todo paintComponent
} // fin de la clase FontJPanel

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
