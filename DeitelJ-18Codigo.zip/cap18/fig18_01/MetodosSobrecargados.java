// Fig. 18.1: MetodosSobrecargados.java
// Uso de m�todos sobrecargados para imprimir arreglos de distintos tipos.

public class MetodosSobrecargados 
{
   // m�todo imprimirArreglo para imprimir arreglo Integer
   public static void imprimirArreglo( Integer[] arregloEntrada )
   {
      // muestra los elementos del arreglo
      for ( Integer elemento : arregloEntrada )
         System.out.printf( "%s ", elemento );

      System.out.println();
   } // fin del m�todo imprimirArreglo

   // m�todo imprimirArreglo para imprimir arreglo Double
   public static void imprimirArreglo( Double[] arregloEntrada )
   {
      // muestra los elementos del arreglo
      for ( Double elemento : arregloEntrada )
         System.out.printf( "%s ", elemento );

      System.out.println();
   } // fin del m�todo imprimirArreglo

   // m�todo imprimirArreglo para imprimir arreglo Character
   public static void imprimirArreglo( Character[] arregloEntrada )
   {
      // muestra los elementos del arreglo
      for ( Character elemento : arregloEntrada )
         System.out.printf( "%s ", elemento );

      System.out.println();
   } // fin del m�todo imprimirArreglo

   public static void main( String args[] ) 
   {
      // crea arreglos de objetos Integer, Double y Character
      Integer[] arregloInteger = { 1, 2, 3, 4, 5, 6 };
      Double[] arregloDouble = { 1.1, 2.2, 3.3, 4.4, 5.5, 6.6, 7.7 };
      Character[] arregloCharacter = { 'H', 'O', 'L', 'A' };

      System.out.println( "El arreglo arregloInteger contiene:" );
      imprimirArreglo( arregloInteger ); // pasa un arreglo Integer
      System.out.println( "\nEl arreglo arregloDouble contiene:" );
      imprimirArreglo( arregloDouble ); // pasa un arreglo Double
      System.out.println( "\nEl arreglo arregloCharacter contiene:" );
      imprimirArreglo( arregloCharacter ); // pasa un arreglo Character
   } // fin de main
} // fin de la clase MetodosSobrecargados

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/