// Fig. 18.5: PruebaMaximo.java
// El m�todo gen�rico maximo devuelve el mayor de tres objetos.

public class PruebaMaximo
{
   // determina el mayor de tres objetos Comparable
   public static < T extends Comparable< T > > T maximo( T x, T y, T z )
   {
      T max = x; // asume que x es el mayor, en un principio 

      if ( y.compareTo( max ) > 0 )
         max = y; // y es el mayor hasta ahora

      if ( z.compareTo( max ) > 0 )
         max = z; // z es el mayor

      return max; // devuelve el objeto m�s grande
   } // fin del m�todo maximo

   public static void main( String args[] ) 
   {
      System.out.printf( "Maximo de %d, %d y %d es %d\n\n", 3, 4, 5, 
         maximo( 3, 4, 5 ) );
      System.out.printf( "Maximo de %.1f, %.1f y %.1f es %.1f\n\n", 
         6.6, 8.8, 7.7, maximo( 6.6, 8.8, 7.7 ) );
      System.out.printf( "Maximo de %s, %s y %s es %s\n", "pera", 
         "manzana", "naranja", maximo( "pera", "manzana", "naranja" ) );
   } // fin de main
} // fin de la clase PruebaMaximo


/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/