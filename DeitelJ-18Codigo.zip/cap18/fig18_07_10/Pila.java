// Fig. 18.7: Pila.java
// La clase gen�rica Pila.

public class Pila< E >  
{
   private final int tamanio; // n�mero de elementos en la pila
   private int superior; // ubicaci�n del elemento superior
   private E[] elementos; // arreglo que almacena los elementos de la pila

   // el constructor sin argumentos crea una pila del tama�o predeterminado
   public Pila()
   {
      this( 10 ); // tama�o predeterminado de la pila
   } // fin del constructor de Pila sin argumentos
   
   // constructor que crea una pila del n�mero especificado de elementos
   public Pila( int s )
   {
      tamanio = s > 0 ? s : 10; // establece el tama�o de la Pila
      superior = -1; // al principio, la Pila est� vac�a

      elementos = ( E[] ) new Object[ tamanio ]; // crea el arreglo 
   } // fin del constructor de Pila sin argumentos

   // mete un elemento a la pila; si tiene �xito, devuelve verdadero; 
   // en caso contrario, lanza excepci�n ExcepcionPilaLlena
   public void push( E valorAMeter )
   {
      if ( superior == tamanio - 1 ) // si la pila est� llena
         throw new ExcepcionPilaLlena( String.format( 
            "La Pila esta llena, no se puede meter %s", valorAMeter ) );

      elementos[ ++superior ] = valorAMeter; // coloca valorAMeter en la Pila
   } // fin del m�todo push

   // devuelve el elemento superior si no est� vac�a; de lo contrario lanza ExcepcionPilaVacia
   public E pop()
   {
      if ( superior == -1 ) // si la pila est� vac�a
         throw new ExcepcionPilaVacia( "La Pila esta vacia, no se puede sacar" );

      return elementos[ superior-- ]; // elimina y devuelve el elemento superior de la Pila
   } // fin del m�todo pop
} // fin de la clase Pila< E >

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/