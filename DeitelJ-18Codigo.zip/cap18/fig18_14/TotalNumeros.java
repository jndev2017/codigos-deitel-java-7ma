// Fig. 18.14: TotalNumeros.java
// Suma de los elementos de un objeto ArrayList.
import java.util.ArrayList;

public class TotalNumeros
{
   public static void main( String args[] ) 
   {
      // crea, inicializa y muestra en pantalla el objeto ArrayList de objetos Number 
      // que contiene objetos Integer y Double, despu�s muestra el total de los elementos 
      Number[] numeros = { 1, 2.4, 3, 4.1 }; // objetos Integer y Double
      ArrayList< Number > listaNumeros = new ArrayList< Number >();

      for ( Number elemento : numeros ) 
         listaNumeros.add( elemento ); // coloca cada n�mero en listaNumeros

      System.out.printf( "listaNumeros contiene: %s\n", listaNumeros );
      System.out.printf( "Total de los elementos en listaNumeros: %.1f\n", 
         sumar( listaNumeros ) );
   } // fin de main

   // calcula el total de los elementos de ArrayList
   public static double sumar( ArrayList< Number > lista )
   {
      double total = 0; // inicializa el total

      // calcula la suma
      for ( Number elemento : lista )
         total += elemento.doubleValue();

      return total;
   } // fin del m�todo sumar
} // fin de la clase TotalNumeros

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/