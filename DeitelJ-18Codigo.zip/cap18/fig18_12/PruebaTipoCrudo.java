// Fig. 18.12: PruebaTipoCrudo.java
// Programa de prueba de tipos crudos.

public class PruebaTipoCrudo 
{
   private Double[] elementosDouble = { 1.1, 2.2, 3.3, 4.4, 5.5, 6.6 };
   private Integer[] elementosInteger = 
      { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };

   // m�todo para evaluar Pilas con tipos crudos
   public void probarPilas()
   {
      // Pila de tipos crudos asignada a una variable Pila de tipos crudos
      Pila pilaTipoCrudo1 = new Pila( 5 ); 

      // Pila< Double > asignada a una variable Pila de tipos crudos
      Pila pilaTipoCrudo2 = new Pila< Double >( 5 );          

      // Pila de tipos crudos asignada a una variable Pila< Integer >
      Pila< Integer > pilaInteger = new Pila( 10 );            

      probarPush( "pilaTipoCrudo1", pilaTipoCrudo1, elementosDouble );
      probarPop( "pilaTipoCrudo1", pilaTipoCrudo1 );
      probarPush( "pilaTipoCrudo2", pilaTipoCrudo2, elementosDouble );
      probarPop( "pilaTipoCrudo2", pilaTipoCrudo2 );
      probarPush( "pilaInteger", pilaInteger, elementosInteger );
      probarPop( "pilaInteger", pilaInteger );
   } // fin del m�todo probarPilas

   // m�todo gen�rico que mete elementos a la pila
   public < T > void probarPush( String nombre, Pila< T > pila,
      T[] elementos )
   {
      // mete elementos a la pila 
      try
      {
         System.out.printf( "\nMetiendo elementos a %s\n", nombre );

         // mete elementos a la Pila            
         for ( T elemento : elementos )         
         {
            System.out.printf( "%s ", elemento );
            pila.push( elemento ); // mete elemento a la pila
         } // fin de for
      } // fin de try
      catch ( ExcepcionPilaLlena excepcionPilaLlena )
      {
         System.out.println();
         excepcionPilaLlena.printStackTrace();
      } // fin de catch ExcepcionPilaLlena
   } // fin del m�todo probarPush

   // m�todo gen�rico probarPop para sacar elementos de la pila
   public < T > void probarPop( String nombre, Pila< T > pila )
   {
      // saca elementos de la pila
      try
      {
         System.out.printf( "\nSacando elementos de %s\n", nombre );
         T valorASacar; // almacena el elemento eliminado de la pila

         // elimina elementos de la Pila
         while ( true )
         {
            valorASacar = pila.pop(); // pop from pila
            System.out.printf( "%s ", valorASacar );
         } // fin de while
      } // fin de try
      catch( ExcepcionPilaVacia excepcionPilaVacia )
      {
         System.out.println();
         excepcionPilaVacia.printStackTrace();
      } // fin de catch ExcepcionPilaVacia
   } // fin del m�todo probarPop

   public static void main( String args[] ) 
   {
      PruebaTipoCrudo aplicacion = new PruebaTipoCrudo();
      aplicacion.probarPilas();
   } // fin de main
} // fin de la clase PruebaTipoCrudo

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/