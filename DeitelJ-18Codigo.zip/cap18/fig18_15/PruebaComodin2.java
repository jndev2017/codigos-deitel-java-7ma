// Fig. 18.15: PruebaComodin.java
// Programa de prueba de comodines.
import java.util.ArrayList;

public class PruebaComodin2 
{
   public static void main( String args[] ) 
   {
      // crea, inicializa e imprime en pantalla un objeto ArrayList de objetos Integer, 
      // y despu�s muestra el total de los elementos
      Integer[] enteros = { 1, 2, 3, 4, 5 };
      ArrayList< Integer > listaEnteros = new ArrayList< Integer >();

      // inserta elementos en listaEnteros
      for ( Integer elemento : enteros )
         listaEnteros.add( elemento );

      System.out.printf( "listaEnteros contiene: %s\n", listaEnteros );
      System.out.printf( "Total de los elementos en listaEnteros: %.0f\n\n",
         sumar( listaEnteros ) );

      // crea, inicializa e imprime en pantalla un objeto ArrayList de objetos Doubles, 
      // y despu�s muestra el total de los elementos 
      Double[] valoresDouble = { 1.1, 3.3, 5.5 };
      ArrayList< Double > listaDouble = new ArrayList< Double >();

      // inserta elementos en listaDouble
      for ( Double elemento : valoresDouble )
         listaDouble.add( elemento );

      System.out.printf( "listaDouble contiene: %s\n", listaDouble );
      System.out.printf( "Total de los elementos en listaDouble: %.1f\n\n", 
         sumar( listaDouble ) );

      // crea, inicializa e imprime en pantalla un objeto ArrayList de objetos Number  
      // que contiene objetos Integer y Double, despu�s muestra el total de los elementos 
      Number[] numeros = { 1, 2.4, 3, 4.1 }; // objetos Integer y Double
      ArrayList< Number > listaNumeros = new ArrayList< Number >();

      // inserta elementos en listaNumeros
      for ( Number elemento : numeros )
         listaNumeros.add( elemento );

      System.out.printf( "listaNumeros contiene: %s\n", listaNumeros );
      System.out.printf( "Total de los elementos en listaNumeros: %.1f\n", 
         sumar( listaNumeros ) );
   } // fin de main


   // calcula el total de los elementos de la pila
   public static <T extends Number> double sumar( ArrayList< T > lista )
   {
      double total = 0; // inicializa el total

      // calcula la suma
      for ( T elemento : lista )
         total += elemento.doubleValue();

      return total;
   } // fin del m�todo sumar
} // fin de la clase PruebaComodin2

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/