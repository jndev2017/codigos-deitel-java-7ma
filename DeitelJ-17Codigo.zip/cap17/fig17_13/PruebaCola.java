// Fig. 17.14: PruebaCola.java
// La clase PruebaCola.
import com.deitel.jhtp7.cap17.Cola;
import com.deitel.jhtp7.cap17.ExcepcionListaVacia;

public class PruebaCola 
{
   public static void main( String args[] )
   {
      Cola cola = new Cola();  

      // usa el m�todo enqueue
      cola.enqueue( -1 );
      cola.imprimir();
      cola.enqueue( 0 );
      cola.imprimir();
      cola.enqueue( 1 );
      cola.imprimir();
      cola.enqueue( 5 );
      cola.imprimir();

      // elimina objetos de la col
      try 
      {
         Object objetoEliminado = null;

         while ( true ) 
         {
            objetoEliminado = cola.dequeue(); // usa el m�todo dequeue
            System.out.printf( "%s se elimino de la cola\n", objetoEliminado );
            cola.imprimir();
         } // fin de while
      } // fin de try
      catch ( ExcepcionListaVacia excepcionListaVacia ) 
      {
         excepcionListaVacia.printStackTrace();
      } // fin de catch
   } // fin de main
} // fin de la clase PruebaCola


/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
