// Fig. 17.17: Arbol.java
// Definici�n de las clases NodoArbol y Arbol.
package com.deitel.jhtp7.cap17;

// definici�n de la clase NodoArbol
class NodoArbol 
{
   // miembros de acceso del paquete
   NodoArbol nodoIzq; // nodo izquierdo 
   int datos; // valor del nodo
   NodoArbol nodoDer; // nodo derecho

   // el constructor inicializa los datos y hace de este nodo un nodo ra�z
   public NodoArbol( int datosNodo )
   { 
      datos = datosNodo;              
      nodoIzq = nodoDer = null; // el nodo no tiene hijos
   } // fin del constructor de NodoArbol

   // localiza el punto de inserci�n e inserta un nuevo nodo; ignora los valores duplicados
   public void insertar( int valorInsertar )
   {
      // inserta en el sub�rbol izquierdo
      if ( valorInsertar < datos ) 
      {
         // inserta nuevo NodoArbol
         if ( nodoIzq == null )
            nodoIzq = new NodoArbol( valorInsertar );
         else // contin�a recorriendo el sub�rbol izquierdo
            nodoIzq.insertar( valorInsertar ); 
      } // fin de if
      else if ( valorInsertar > datos ) // inserta en el sub�rbol derecho
      {
         // inserta nuevo NodoArbol
         if ( nodoDer == null )
            nodoDer = new NodoArbol( valorInsertar );
         else // contin�a recorriendo el sub�rbol derecho
            nodoDer.insertar( valorInsertar ); 
      } // fin de else if
   } // fin del m�todo insertar
} // fin de la clase NodoArbol

// definici�n de la clase Arbol
public class Arbol 
{
   private NodoArbol raiz;

   // el constructor inicializa un Arbol vac�o de enteros
   public Arbol() 
   { 
      raiz = null; 
   } // fin del constructor de Arbol sin argumentos

   // inserta un nuevo nodo en el �rbol de b�squeda binaria
   public void insertarNodo( int valorInsertar )
   {
      if ( raiz == null )
         raiz = new NodoArbol( valorInsertar ); // crea el nodo ra�z aqu�
      else
         raiz.insertar( valorInsertar ); // llama al m�todo insertar
   } // fin del m�todo insertarNodo

   // comienza el recorrido preorden
   public void recorridoPreorden()
   { 
      ayudantePreorden( raiz ); 
   } // fin del m�todo recorridoPreorden

   // m�todo recursivo para realizar el recorrido preorden
   private void ayudantePreorden( NodoArbol nodo )
   {
      if ( nodo == null )
         return;

      System.out.printf( "%d ", nodo.datos ); // imprime los datos del nodo
      ayudantePreorden( nodo.nodoIzq );       // recorre el sub�rbol izquierdo
      ayudantePreorden( nodo.nodoDer );      // recorre el sub�rbol derecho
   } // fin del m�todo ayudantePreorden

   // comienza recorrido inorden
   public void recorridoInorden()
   { 
      ayudanteInorden( raiz ); 
   } // fin del m�todo recorridoInorden

   // m�todo recursivo para realizar el recorrido inorden
   private void ayudanteInorden( NodoArbol nodo )
   {
      if ( nodo == null )
         return;

      ayudanteInorden( nodo.nodoIzq );        // recorre el sub�rbol izquierdo
      System.out.printf( "%d ", nodo.datos ); // imprime los datos del nodo
      ayudanteInorden( nodo.nodoDer );       // recorre el sub�rbol derecho
   } // fin del m�todo ayudanteInorden

   // comienza recorrido postorden
   public void recorridoPostorden()
   { 
      ayudantePostorden( raiz ); 
   } // fin del m�todo recorridoPostorden

   // m�todo recursivo para realizar el recorrido postorden
   private void ayudantePostorden( NodoArbol nodo )
   {
      if ( nodo == null )
         return;
  
      ayudantePostorden( nodo.nodoIzq );      // recorre el sub�rbol izquierdo
      ayudantePostorden( nodo.nodoDer );     // recorre el sub�rbol derecho
      System.out.printf( "%d ", nodo.datos ); // imprime los datos del nodo
   } // fin del m�todo ayudantePostorden
} // fin de la clase Arbol

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/
