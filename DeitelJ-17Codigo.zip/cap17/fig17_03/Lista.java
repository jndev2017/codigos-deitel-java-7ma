// Fig. 17.3: Lista.java
// Definiciones de las clases NodoLista y Lista.
package com.deitel.jhtp7.cap17;

// clase para representar un nodo en una lista
class NodoLista 
{
   // miembros de acceso del paquete; Lista puede acceder a ellos directamente
   Object datos; // los datos para este nodo
   NodoLista siguienteNodo; // referencia al siguiente nodo en la lista

   // el constructor crea un objeto NodoLista que hace referencia al objeto
   NodoLista( Object objeto ) 
   { 
      this( objeto, null ); 
   } // fin del constructor de NodoLista con un argumento 

   // el constructor crea un objeto NodoLista que hace referencia a 
   // un objeto Object y al siguiente objeto NodoLista
   NodoLista( Object objeto, NodoLista nodo )
   {
      datos = objeto;    
      siguienteNodo = nodo;  
   } // fin del constructor de NodoLista con dos argumentos

   // devuelve la referencia a datos en el nodo
   Object obtenerObject() 
   { 
      return datos; // devuelve el objeto Object en este nodo
   } // fin del m�todo obtenerObject

   // devuelve la referencia al siguiente nodo en la lista
   NodoLista obtenerSiguiente() 
   { 
      return siguienteNodo; // obtiene el siguiente nodo
   } // fin del m�todo obtenerSiguiente
} // fin de la clase NodoLista

// definici�n de la clase Lista
public class Lista 
{
   private NodoLista primerNodo;
   private NodoLista ultimoNodo;
   private String nombre; // cadena como "lista", utilizada para imprimir

   // el constructor crea una Lista vac�a con el nombre "lista"
   public Lista() 
   { 
      this( "lista" ); 
   } // fin del constructor de Lista sin argumentos

   // el constructor crea una Lista vac�a con un nombre
   public Lista( String nombreLista )
   {
      nombre = nombreLista;
      primerNodo = ultimoNodo = null;
   } // fin del constructor de Lista con un argumento

   // inserta objeto Object al frente de la Lista
   public void insertarAlFrente( Object elementoInsertar )
   {
      if ( estaVacia() ) // primerNodo y ultimoNodo hacen referencia al mismo objeto
         primerNodo = ultimoNodo = new NodoLista( elementoInsertar );
      else // primerNodo hace referencia al nuevo nodo
         primerNodo = new NodoLista( elementoInsertar, primerNodo );
   } // fin del m�todo insertarAlFrente

   // inserta objeto Object al final del la Lista
   public void insertarAlFinal( Object elementoInsertar )
   {
      if ( estaVacia() ) // primerNodo y ultimoNodo hacen referencia al mismo objeto
         primerNodo = ultimoNodo = new NodoLista( elementoInsertar );
      else // el siguienteNodo de ultimoNodo hace referencia al nuevo nodo
         ultimoNodo = ultimoNodo.siguienteNodo = new NodoLista( elementoInsertar );
   } // fin del m�todo insertarAlFinal

   // elimina el primer nodo de la Lista
   public Object eliminarDelFrente() throws ExcepcionListaVacia
   {
      if ( estaVacia() ) // lanza excepci�n si la Lista est� vac�a
         throw new ExcepcionListaVacia( nombre );

      Object elementoEliminado = primerNodo.datos; // obtiene los datos que se van a eliminar

      // actualiza las referencias primerNodo y ultimoNodo 
      if ( primerNodo == ultimoNodo )
         primerNodo = ultimoNodo = null;
      else
         primerNodo = primerNodo.siguienteNodo;

      return elementoEliminado; // devuelve los datos del nodo eliminado
   } // fin del m�todo eliminarDelFrente

   // elimina el �ltimo nodo de la Lista
   public Object eliminarDelFinal() throws ExcepcionListaVacia
   {
      if ( estaVacia() ) // lanza excepci�n si la Lista est� vac�a
         throw new ExcepcionListaVacia( nombre );

      Object elementoEliminado = ultimoNodo.datos; // obtiene los datos que se van a eliminar

      // actualiza las referencias primerNodo y ultimoNodo
      if ( primerNodo == ultimoNodo )
         primerNodo = ultimoNodo = null;
      else // localiza el nuevo �ltimo nodo
      { 
         NodoLista actual = primerNodo;

         // itera mientras el nodo actual no haga referencia a ultimoNodo
         while ( actual.siguienteNodo != ultimoNodo )
            actual = actual.siguienteNodo;
   
         ultimoNodo = actual; // actual el nuevo ultimoNodo
         actual.siguienteNodo = null;
      } // fin de else

      return elementoEliminado; // devuelve los datos del nodo eliminado
   } // fin del m�todo eliminarDelFinal

   // determina si la lista est� vac�a
   public boolean estaVacia()
   { 
      return primerNodo == null; // devuelve true si la lista est� vac�a
   } // fin del m�todo estaVacia

   // imprime el contenido de la lista
   public void imprimir()
   {
      if ( estaVacia() ) 
      {
         System.out.printf( "%s vacia\n", nombre );
         return;
      } // fin de if

      System.out.printf( "La %s es: ", nombre );
      NodoLista actual = primerNodo;

      // mientras no est� al final de la lista, imprime los datos del nodo actual
      while ( actual != null ) 
      {
         System.out.printf( "%s ", actual.datos );
         actual = actual.siguienteNodo;
      } // fin de while

      System.out.println( "\n" );
   } // fin del m�todo imprimir
} // fin de la clase Lista

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/