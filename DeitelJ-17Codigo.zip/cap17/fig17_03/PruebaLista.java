// Fig. 17.5: PruebaLista.java
// Clase PruebaLista para demostrar las capacidades de Lista.
import com.deitel.jhtp7.cap17.Lista;
import com.deitel.jhtp7.cap17.ExcepcionListaVacia;

public class PruebaLista 
{
   public static void main( String args[] )
   {
      Lista lista = new Lista(); // crea el contenedor de Lista

      // inserta enteros en lista
      lista.insertarAlFrente( -1 );
      lista.imprimir();
      lista.insertarAlFrente( 0 );
      lista.imprimir();
      lista.insertarAlFinal( 1 );
      lista.imprimir();
      lista.insertarAlFinal( 5 );
      lista.imprimir();

      // elimina objetos de lista; imprime despu�s de cada eliminaci�n
      try 
      { 
         Object objetoEliminado = lista.eliminarDelFrente();
         System.out.printf( "%s eliminado\n", objetoEliminado );
         lista.imprimir();

         objetoEliminado = lista.eliminarDelFrente();
         System.out.printf( "%s eliminado\n", objetoEliminado );
         lista.imprimir();

         objetoEliminado = lista.eliminarDelFinal();
         System.out.printf( "%s eliminado\n", objetoEliminado );
         lista.imprimir();

         objetoEliminado = lista.eliminarDelFinal();
         System.out.printf( "%s eliminado\n", objetoEliminado );
         lista.imprimir();
      } // fin de try
      catch ( ExcepcionListaVacia excepcionListaVacia ) 
      {
         excepcionListaVacia.printStackTrace();
      } // fin de catch
   } // fin de main
} // fin de la clase PruebaLista


/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/