// Fig. 17.12: PruebaComposicionPila.java
// La clase PruebaComposicionPila.
import com.deitel.jhtp7.cap17.ComposicionPila;
import com.deitel.jhtp7.cap17.ExcepcionListaVacia;

public class PruebaComposicionPila 
{
   public static void main( String args[] )
   {
      ComposicionPila pila = new ComposicionPila();  

      // usa el m�todo push
      pila.push( -1 );
      pila.imprimir();
      pila.push( 0 );
      pila.imprimir();
      pila.push( 1 );
      pila.imprimir();
      pila.push( 5 );
      pila.imprimir();

      // elimina elementos de la pila
      try 
      {
         Object objetoEliminado = null;

         while ( true ) 
         {
            objetoEliminado = pila.pop(); // usa el m�todo pop
            System.out.printf( "%s se saco\n", objetoEliminado );
            pila.imprimir();
         } // fin de while
      } // fin de try
      catch ( ExcepcionListaVacia excepcionListaVacia ) 
      {
         excepcionListaVacia.printStackTrace();
      } // fin de catch
   } // fin de main
} // fin de la clase PruebaComposicionPila



/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/