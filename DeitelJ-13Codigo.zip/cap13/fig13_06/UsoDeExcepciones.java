// Fig. 13.6: UsoDeExcepciones.java
// Demostraci�n de la limpieza de la pila.

public class UsoDeExcepciones 
{
   public static void main( String args[] )
   {
      try // llama a lanzaExcepcion para demostrar la limpieza de la pila
      { 
         lanzaExcepcion();
      } // fin de try
      catch ( Exception excepcion ) // excepci�n lanzada en lanzaExcepcion
      {
         System.err.println( "La excepcion se manejo en main" );
      } // fin de catch
   } // fin de main

   // lanzaExcepcion lanza la excepci�n que no se atrapa en este m�todo
   public static void lanzaExcepcion() throws Exception
   {
      try // lanza una excepci�n y la atrapa en main
      { 
         System.out.println( "Metodo lanzaExcepcion" );
         throw new Exception(); // genera la excepci�n
      } // fin de try
      catch ( RuntimeException runtimeException ) // atrapa el tipo incorrecto
      {
         System.err.println( 
            "La excepcion se manejo en el metodo lanzaExcepcion" );
      } // fin de catch
      finally // el bloque finally siempre se ejecuta
      { 
         System.err.println( "Finally siempre se ejecuta" );
      } // fin de finally
   } // fin del m�todo lanzaExcepcion
} // fin de la clase UsoDeExcepciones

/**************************************************************************
 * (C) Copyright 1992-2007 por Deitel & Associates, Inc. y                *
 * Pearson Education, Inc. Todos los derechos reservados.                 *
 *                                                                        *
 * RENUNCIA: Los autores y el editor de este libro han realizado su mejor *
 * esfuerzo para preparar este libro. Esto incluye el desarrollo, la      *
 * investigaci�n y prueba de las teor�as y programas para determinar su   *
 * efectividad. Los autores y el editor no hacen ninguna garant�a de      *
 * ning�n tipo, expresa o impl�cita, en relaci�n con estos programas o    *
 * con la documentaci�n contenida en estos libros. Los autores y el       *
 * editor no ser�n responsables en ning�n caso por los da�os consecuentes *
 * en conexi�n con, o que surjan de, el suministro, desempe�o o uso de    *
 * estos programas.                                                       *
 *************************************************************************/